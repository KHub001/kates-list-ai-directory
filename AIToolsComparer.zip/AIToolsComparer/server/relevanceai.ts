import { storage } from "./storage";

interface RelevanceAIResponse {
  data: {
    tools?: Array<{
      name: string;
      description: string;
      website_url: string;
      category: string;
      pricing_model: string;
      features: string[];
      has_api: boolean;
      has_free_version: boolean;
      country?: string;
      launch_date?: string;
    }>;
  };
}

export class RelevanceAIService {
  private apiKey: string;
  private projectId: string;
  private baseUrl = 'https://api-d954c8.stack.tryrelevance.com';

  constructor() {
    this.apiKey = process.env.RELEVANCE_AI_API_KEY!;
    this.projectId = process.env.RELEVANCE_AI_PROJECT_ID!;
    
    if (!this.apiKey || !this.projectId) {
      throw new Error('Relevance AI credentials not found');
    }
  }

  async fetchLatestAITools(): Promise<void> {
    try {
      console.log('Fetching latest AI tools from Relevance AI...');
      
      const response = await fetch(`${this.baseUrl}/v1/${this.projectId}/agents/run_async`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: "Find the latest AI tools that have been released in the past month, including their descriptions, categories, pricing models, and features. Focus on tools that solve real problems for users.",
          agent_id: "ai-tools-researcher" // This would be configured in your Relevance AI dashboard
        })
      });

      if (!response.ok) {
        throw new Error(`Relevance AI API error: ${response.status}`);
      }

      const data: RelevanceAIResponse = await response.json();
      
      if (data.data?.tools) {
        await this.processAndStoreTools(data.data.tools);
        console.log(`Successfully processed ${data.data.tools.length} tools`);
      }
    } catch (error) {
      console.error('Error fetching from Relevance AI:', error);
      throw error;
    }
  }

  private async processAndStoreTools(tools: any[]): Promise<void> {
    for (const tool of tools) {
      try {
        // Check if tool already exists
        const existingTools = await storage.getAllTools({ search: tool.name, limit: 1 });
        if (existingTools.tools.length > 0) {
          console.log(`Tool ${tool.name} already exists, skipping...`);
          continue;
        }

        // Create new tool entry
        await storage.createTool({
          name: tool.name,
          description: tool.description,
          websiteUrl: tool.website_url,
          logoUrl: `/api/logo/${new URL(tool.website_url).hostname}`,
          category: this.mapCategory(tool.category),
          pricingModel: this.mapPricingModel(tool.pricing_model),
          country: tool.country || null,
          launchDate: tool.launch_date ? new Date(tool.launch_date) : null,
          hasApi: tool.has_api || false,
          hasFreeVersion: tool.has_free_version || false,
          features: tool.features || [],
          isActive: true,
        });

        console.log(`Added new tool: ${tool.name}`);
      } catch (error) {
        console.error(`Error processing tool ${tool.name}:`, error);
      }
    }
  }

  private mapCategory(category: string): any {
    const categoryMap: Record<string, string> = {
      'writing': 'writing-assistants',
      'image': 'image-generation',
      'video': 'video-creation',
      'audio': 'audio-generation',
      'code': 'code-assistants',
      'productivity': 'productivity',
      'research': 'research-analysis',
      'hr': 'hr-recruitment',
      'marketing': 'marketing-sales',
      'finance': 'finance-accounting',
      'education': 'education-training',
      'healthcare': 'healthcare-medical',
      'legal': 'legal-compliance',
      'customer service': 'customer-service',
      'translation': 'translation-language',
    };

    const lowerCategory = category.toLowerCase();
    return categoryMap[lowerCategory] || 'productivity';
  }

  private mapPricingModel(pricing: string): any {
    const pricingMap: Record<string, string> = {
      'free': 'free',
      'freemium': 'freemium',
      'paid': 'paid',
      'enterprise': 'enterprise',
      'subscription': 'paid',
      'one-time': 'paid',
    };

    const lowerPricing = pricing.toLowerCase();
    return pricingMap[lowerPricing] || 'freemium';
  }

  async scheduleRegularUpdates(): Promise<void> {
    // Run updates every 24 hours
    setInterval(async () => {
      try {
        await this.fetchLatestAITools();
      } catch (error) {
        console.error('Scheduled update failed:', error);
      }
    }, 24 * 60 * 60 * 1000); // 24 hours
  }
}

export const relevanceAI = new RelevanceAIService();