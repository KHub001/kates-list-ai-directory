import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useDebounce } from "@/hooks/useDebounce";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star, Users, TrendingUp, AlertCircle, RefreshCw } from "lucide-react";
import ToolCard from "@/components/ToolCard";
import ToolCardSkeleton from "@/components/ToolCardSkeleton";
import CategoryFilter from "@/components/CategoryFilter";

export default function Landing() {
  const [filters, setFilters] = useState({
    category: "",
    pricingModel: "",
    search: "",
    sortBy: "popularity" as "popularity" | "rating" | "recent" | "alphabetical",
  });
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [page, setPage] = useState(0);
  const pageSize = 16; // Optimized page size

  // Debounce search to reduce API calls
  const debouncedSearch = useDebounce(filters.search, 300);
  
  // Use debounced search in query
  const searchFilters = { ...filters, search: debouncedSearch };

  const { data: toolsData, isLoading: toolsLoading, error: toolsError, refetch: refetchTools } = useQuery({
    queryKey: ["/api/tools", { ...searchFilters, limit: pageSize, offset: page * pageSize }],
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
    refetchOnWindowFocus: false, // Prevent unnecessary refetches
  });

  const { data: featuredTool, error: featuredError } = useQuery({
    queryKey: ["/api/tools/featured"],
    staleTime: 10 * 60 * 1000, // Cache featured tool for 10 minutes
    refetchOnWindowFocus: false,
  });

  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    staleTime: 15 * 60 * 1000, // Cache categories for 15 minutes
    refetchOnWindowFocus: false,
  });

  const handleFilterChange = (newFilters: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setPage(0);
  };

  const loadMore = () => {
    setPage(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header onSearch={(search) => handleFilterChange({ search })} />
      
      {/* Hero Section */}
      <section className="gradient-bg py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold text-white mb-4">
            The AI Directory
          </h1>
          <p className="text-lg text-white/90 mb-6 max-w-2xl mx-auto">
            Explore {toolsData?.total || 175}+ AI tools across all categories. Find the perfect solution for your needs.
          </p>
          <Link href="/auth">
            <Button 
              size="lg" 
              className="bg-white text-primary-600 hover:bg-gray-50"
            >
              Join the Community
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Category Filter */}
      <CategoryFilter 
        filters={filters}
        onFilterChange={handleFilterChange}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
      />

      {/* Featured Tool */}
      {featuredError ? (
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="p-6 bg-slate-50 border-slate-200">
              <CardContent className="p-0 text-center">
                <AlertCircle className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                <p className="text-slate-600 text-sm">Unable to load featured tool</p>
              </CardContent>
            </Card>
          </div>
        </section>
      ) : featuredTool && (
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Featured AI Tool</h2>
            <div className="bg-gradient-to-r from-primary/10 to-blue-50 rounded-xl p-6 border border-primary/20">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0">
                  {featuredTool.logoUrl ? (
                    <img
                      src={featuredTool.logoUrl}
                      alt={featuredTool.name}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                      <i className="fas fa-robot text-primary text-xl"></i>
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{featuredTool.name}</h3>
                  <p className="text-slate-600 mb-4">{featuredTool.description}</p>
                  <div className="flex items-center space-x-4">
                    <Button size="sm" asChild>
                      <a href={`/tool/${featuredTool.id}`}>View Details</a>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <a href={featuredTool.websiteUrl} target="_blank" rel="noopener noreferrer">
                        Visit Website
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Main Tools Section */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Browse AI Tools</h2>
            <p className="text-slate-600">
              Discover the latest and most popular AI platforms across all categories
            </p>
          </div>

          {/* Tools Grid */}
          {toolsLoading ? (
            <div className={viewMode === "grid" 
              ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              : "space-y-4"
            }>
              {Array.from({ length: 8 }).map((_, i) => (
                <ToolCardSkeleton key={i} viewMode={viewMode} />
              ))}
            </div>
          ) : toolsError ? (
            <Card className="p-8 text-center">
              <CardContent className="p-0">
                <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  Unable to Load AI Tools
                </h3>
                <p className="text-slate-600 mb-4">
                  There was an error loading the AI tools. Please try again.
                </p>
                <Button onClick={() => refetchTools()} className="inline-flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className={viewMode === "grid" 
                ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 sm:gap-6 mb-8"
                : "space-y-4 mb-8"
              }>
                {toolsData?.tools?.map((tool: any) => (
                  <ToolCard key={tool.id} tool={tool} viewMode={viewMode} />
                ))}
              </div>

              {/* Load More Button */}
              {toolsData?.tools?.length < toolsData?.total && (
                <div className="text-center">
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={loadMore}
                  >
                    Load More Tools
                  </Button>
                </div>
              )}

              {/* No Results */}
              {toolsData?.tools?.length === 0 && (
                <Card className="p-12 text-center">
                  <CardContent className="p-0">
                    <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Star className="h-8 w-8 text-slate-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-slate-900 mb-2">
                      No AI tools found
                    </h3>
                    <p className="text-slate-600 mb-6 max-w-md mx-auto">
                      {filters.search ? 
                        `No results for "${filters.search}". Try different keywords or browse categories.` :
                        "Try adjusting your search criteria or browse all categories"
                      }
                    </p>
                    <div className="flex flex-wrap gap-3 justify-center">
                      <Button 
                        variant="outline"
                        onClick={() => handleFilterChange({ category: "", search: "", pricingModel: "" })}
                      >
                        Clear All Filters
                      </Button>
                      {filters.search && (
                        <Button 
                          variant="outline"
                          onClick={() => handleFilterChange({ search: "" })}
                        >
                          Clear Search
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">{toolsData?.total || 103}+</h3>
              <p className="text-slate-600">AI Tools Listed</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">127</h3>
              <p className="text-slate-600">Community Members</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Star className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-3xl font-bold text-slate-900 mb-2">89</h3>
              <p className="text-slate-600">Reviews & Ratings</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">
              Why Choose Kate's List?
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              We provide comprehensive insights to help you make informed decisions about AI tools
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-search text-blue-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Smart Discovery</h3>
                <p className="text-slate-600">
                  Advanced search and filtering to find AI tools that match your exact needs and use cases.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-balance-scale text-green-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Side-by-Side Comparison</h3>
                <p className="text-slate-600">
                  Compare up to 4 AI platforms simultaneously with detailed feature breakdowns and pricing.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-users text-purple-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Community Reviews</h3>
                <p className="text-slate-600">
                  Real user reviews with multi-criteria ratings for authentic insights from actual users.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-star text-yellow-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Daily Featured Tools</h3>
                <p className="text-slate-600">
                  Discover trending AI platforms chosen by our community with detailed daily spotlights.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-heart text-red-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Personal Collections</h3>
                <p className="text-slate-600">
                  Save your favorite tools and create custom lists for different projects and use cases.
                </p>
              </CardContent>
            </Card>

            <Card className="p-6 border-0 shadow-sm">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <i className="fas fa-chart-line text-indigo-600 text-xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-3">Market Insights</h3>
                <p className="text-slate-600">
                  Stay updated with AI tool trends, pricing changes, and new feature releases.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Ready to Find Your Perfect AI Tool?
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            Join our community and start discovering the AI tools that will transform your workflow.
          </p>
          <Link href="/auth">
            <Button 
              size="lg" 
              className="bg-primary-600 hover:bg-primary-700"
            >
              Join Kate's List
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
