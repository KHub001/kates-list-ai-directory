#!/bin/bash
set -e

echo "Building frontend..."
npm run build:client

echo "Building backend..."
npm run build:server

echo "Build completed successfully!"