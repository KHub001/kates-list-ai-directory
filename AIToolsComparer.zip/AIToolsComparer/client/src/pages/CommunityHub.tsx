import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Users, MessageCircle, Star, TrendingUp, Calendar, Award, Plus, UserPlus } from "lucide-react";
import CommunityRegistrationForm from "@/components/CommunityRegistrationForm";
import ContactForm from "@/components/ContactForm";
import CommunityReviewForm from "@/components/CommunityReviewForm";

export default function CommunityHub() {
  const [activeTab, setActiveTab] = useState("overview");
  const [showRegistration, setShowRegistration] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [showReviewDemo, setShowReviewDemo] = useState(false);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">Join Kate's List Community</h1>
        <p className="text-xl text-gray-600 mb-6">
          Connect with AI enthusiasts, share insights, and discover the latest tools together
        </p>
        <div className="flex justify-center gap-4 mb-8">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">Growing</div>
            <div className="text-sm text-gray-600">Community Members</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">Real</div>
            <div className="text-sm text-gray-600">User Reviews</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">Active</div>
            <div className="text-sm text-gray-600">Discussions</div>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="join">Join Community</TabsTrigger>
          <TabsTrigger value="reviews">Write Reviews</TabsTrigger>
          <TabsTrigger value="contact">Contact Us</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-600" />
                  Community Benefits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    Share honest tool reviews
                  </li>
                  <li className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4 text-green-500" />
                    Direct communication with admin
                  </li>
                  <li className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-purple-500" />
                    Access to curated tool insights
                  </li>
                  <li className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-orange-500" />
                    Build your AI expertise profile
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5 text-green-600" />
                  Getting Started
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="font-medium text-sm">1. Join the Community</div>
                    <div className="text-xs text-gray-600">Register with your details and interests</div>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="font-medium text-sm">2. Share Your Experience</div>
                    <div className="text-xs text-gray-600">Write reviews for AI tools you've used</div>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <div className="font-medium text-sm">3. Connect & Learn</div>
                    <div className="text-xs text-gray-600">Engage with other community members</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5 text-purple-600" />
                  Get In Touch
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 border border-blue-200 rounded-lg">
                    <div className="font-medium text-sm">General Questions</div>
                    <div className="text-xs text-gray-600">Ask us anything about the platform</div>
                  </div>
                  <div className="p-3 border border-green-200 rounded-lg">
                    <div className="font-medium text-sm">Tool Submissions</div>
                    <div className="text-xs text-gray-600">Suggest new AI tools to feature</div>
                  </div>
                  <div className="p-3 border border-purple-200 rounded-lg">
                    <div className="font-medium text-sm">Partnership Ideas</div>
                    <div className="text-xs text-gray-600">Collaborate with us</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Why Join Our Community?</CardTitle>
              <CardDescription>Real benefits for AI enthusiasts and professionals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">For AI Beginners</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Discover tools perfect for your skill level</li>
                    <li>• Learn from experienced community members</li>
                    <li>• Get personalized recommendations</li>
                    <li>• Access beginner-friendly tutorials</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">For AI Professionals</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Share your expertise through detailed reviews</li>
                    <li>• Influence tool development with feedback</li>
                    <li>• Network with industry peers</li>
                    <li>• Stay ahead of emerging trends</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="join">
          <CommunityRegistrationForm 
            onSuccess={() => setShowRegistration(false)}
          />
        </TabsContent>

        <TabsContent value="reviews">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Share Your AI Tool Experience</CardTitle>
                <CardDescription>
                  Help the community by writing honest, detailed reviews of AI tools you've used
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-6">
                  <Star className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Ready to Write a Review?</h3>
                  <p className="text-gray-600 mb-6">
                    Choose any AI tool from our directory and share your experience
                  </p>
                  <div className="flex gap-4 justify-center">
                    <Button onClick={() => window.location.href = '/'}>
                      Browse AI Tools
                    </Button>
                    <Dialog open={showReviewDemo} onOpenChange={setShowReviewDemo}>
                      <DialogTrigger asChild>
                        <Button variant="outline">
                          See Review Form
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <CommunityReviewForm
                          toolId={1}
                          toolName="Demo Tool"
                          onSuccess={() => setShowReviewDemo(false)}
                          onCancel={() => setShowReviewDemo(false)}
                        />
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Review Guidelines</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 text-green-600">What Makes a Great Review</h4>
                    <ul className="space-y-2 text-sm">
                      <li>✓ Specific use cases and examples</li>
                      <li>✓ Honest pros and cons</li>
                      <li>✓ Who should (and shouldn't) use it</li>
                      <li>✓ Comparison with similar tools</li>
                      <li>✓ Value for money assessment</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 text-red-600">Please Avoid</h4>
                    <ul className="space-y-2 text-sm">
                      <li>✗ Generic or vague statements</li>
                      <li>✗ Reviews based on limited testing</li>
                      <li>✗ Promotional or biased content</li>
                      <li>✗ Reviews of tools you haven't used</li>
                      <li>✗ Inappropriate or offensive language</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contact">
          <ContactForm onSuccess={() => setShowContact(false)} />
        </TabsContent>
      </Tabs>

      <div className="text-center mt-12">
        <div className="flex justify-center gap-4">
          <Dialog open={showRegistration} onOpenChange={setShowRegistration}>
            <DialogTrigger asChild>
              <Button size="lg">
                <Users className="mr-2 h-5 w-5" />
                Join Community
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <CommunityRegistrationForm onSuccess={() => setShowRegistration(false)} />
            </DialogContent>
          </Dialog>

          <Dialog open={showContact} onOpenChange={setShowContact}>
            <DialogTrigger asChild>
              <Button variant="outline" size="lg">
                <MessageCircle className="mr-2 h-5 w-5" />
                Contact Us
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <ContactForm onSuccess={() => setShowContact(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}