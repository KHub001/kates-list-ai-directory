import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Users, Mail, Briefcase, Star } from "lucide-react";

const communityRegistrationSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  company: z.string().optional(),
  jobTitle: z.string().optional(),
  interests: z.array(z.string()).min(1, "Please select at least one area of interest"),
  experience: z.string().min(1, "Please select your experience level"),
  bio: z.string().optional(),
});

type CommunityRegistrationForm = z.infer<typeof communityRegistrationSchema>;

const aiCategories = [
  "chatbots", "image-generation", "video-creation", "writing-assistance", 
  "code-generation", "data-analysis", "productivity", "research",
  "design-tools", "automation", "voice-ai", "business-intelligence"
];

const experienceLevels = [
  { value: "beginner", label: "Beginner - New to AI tools" },
  { value: "intermediate", label: "Intermediate - Some experience with AI" },
  { value: "expert", label: "Expert - Extensive AI experience" },
  { value: "professional", label: "Professional - Work with AI daily" }
];

interface CommunityRegistrationFormProps {
  onSuccess?: () => void;
}

export default function CommunityRegistrationForm({ onSuccess }: CommunityRegistrationFormProps) {
  const { toast } = useToast();
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const form = useForm<CommunityRegistrationForm>({
    resolver: zodResolver(communityRegistrationSchema),
    defaultValues: {
      email: "",
      firstName: "",
      lastName: "",
      company: "",
      jobTitle: "",
      interests: [],
      experience: "",
      bio: "",
    },
  });

  const registrationMutation = useMutation({
    mutationFn: async (data: CommunityRegistrationForm) => {
      return await apiRequest("/api/community/join", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      toast({
        title: "Welcome to the community!",
        description: "You've successfully joined Kate's List community. We'll be in touch soon!",
      });
      form.reset();
      onSuccess?.();
    },
    onError: (error: Error) => {
      if (error.message.includes("409")) {
        toast({
          title: "Already registered",
          description: "This email is already registered in our community.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Registration failed",
          description: "There was an error registering. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  const onSubmit = (data: CommunityRegistrationForm) => {
    registrationMutation.mutate({
      ...data,
      interests: selectedInterests,
    });
  };

  const handleInterestToggle = (interest: string) => {
    const newInterests = selectedInterests.includes(interest)
      ? selectedInterests.filter(i => i !== interest)
      : [...selectedInterests, interest];
    
    setSelectedInterests(newInterests);
    form.setValue("interests", newInterests);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
          <Users className="w-6 h-6 text-blue-600" />
        </div>
        <CardTitle className="text-2xl font-bold">Join Kate's List Community</CardTitle>
        <CardDescription>
          Connect with AI enthusiasts, share insights, and stay updated on the latest tools
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input placeholder="john.doe@example.com" className="pl-10" {...field} />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company (Optional)</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input placeholder="Your Company" className="pl-10" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="jobTitle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Job Title (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Software Engineer" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>AI Experience Level</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your experience level" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {experienceLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <FormLabel className="text-base font-medium">Areas of Interest</FormLabel>
              <p className="text-sm text-gray-600 mb-3">Select the AI categories you're most interested in</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {aiCategories.map((category) => (
                  <div key={category} className="flex items-center space-x-2">
                    <Checkbox
                      id={category}
                      checked={selectedInterests.includes(category)}
                      onCheckedChange={() => handleInterestToggle(category)}
                    />
                    <label
                      htmlFor={category}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                    >
                      {category.replace('-', ' ')}
                    </label>
                  </div>
                ))}
              </div>
              {form.formState.errors.interests && (
                <p className="text-sm font-medium text-destructive mt-2">
                  {form.formState.errors.interests.message}
                </p>
              )}
            </div>

            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bio (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Tell us a bit about yourself and your interest in AI..."
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />



            <Button 
              type="submit" 
              className="w-full" 
              disabled={registrationMutation.isPending}
            >
              {registrationMutation.isPending ? (
                <>
                  <Star className="mr-2 h-4 w-4 animate-spin" />
                  Joining Community...
                </>
              ) : (
                <>
                  <Users className="mr-2 h-4 w-4" />
                  Join Community
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}