import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Grid3X3, List, Filter, Star } from "lucide-react";

interface CategoryFilterProps {
  filters: {
    category: string;
    pricingModel: string;
    search: string;
    minRating: string;
    hasApi: string;
    hasFreeVersion: string;
    sortBy: "popularity" | "rating" | "recent" | "alphabetical";
  };
  onFilterChange: (filters: Partial<typeof filters>) => void;
  viewMode: "grid" | "list";
  onViewModeChange: (mode: "grid" | "list") => void;
}

export default function CategoryFilter({ 
  filters, 
  onFilterChange, 
  viewMode, 
  onViewModeChange 
}: CategoryFilterProps) {
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  const categoryDisplayNames: { [key: string]: string } = {
    "text-generation": "Text Generation",
    "image-generation": "Image Generation",
    "code-assistance": "Code Assistance", 
    "video-creation": "Video Creation",
    "audio-processing": "Audio Processing",
    "chatbots": "Chatbots",
    "data-analysis": "Data Analysis",
    "design-creative": "Design & Creative",
    "productivity": "Productivity",
    "research-academic": "Research & Academic",
    "developer-tools": "Developer Tools",
    "marketing-content": "Marketing & Content",
    "translation": "Translation",
    "voice-speech": "Voice & Speech",
    "computer-vision": "Computer Vision",
    "machine-learning": "Machine Learning",
    "no-code": "No-Code",
    "writing-assistants": "Writing Assistants",
    "education": "Education",
    "healthcare": "Healthcare",
    "finance": "Finance",
  };

  const topCategories = [
    "text-generation",
    "image-generation", 
    "productivity",
    "video-creation",
    "data-analysis"
  ];

  return (
    <section className="bg-white border-b border-slate-200 py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Mobile-first responsive layout */}
        <div className="space-y-4 lg:space-y-0 lg:flex lg:items-center lg:justify-between lg:gap-6">
          <div className="space-y-3 lg:space-y-0 lg:flex lg:items-center lg:space-x-6">
            <div className="space-y-3 lg:space-y-0 lg:flex lg:items-center lg:space-x-4">
              <span className="text-slate-900 font-medium hidden sm:block">Browse by Category:</span>
              <span className="text-slate-900 font-medium text-sm sm:hidden">Categories:</span>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={filters.category === "" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onFilterChange({ category: "" })}
                  className="text-xs sm:text-sm"
                >
                  All Tools
                </Button>
                {topCategories.map((category) => (
                  <Button
                    key={category}
                    variant={filters.category === category ? "default" : "outline"}
                    size="sm"
                    onClick={() => onFilterChange({ category })}
                    className="text-xs sm:text-sm"
                  >
                    {categoryDisplayNames[category]}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
            {/* Advanced Filters */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Advanced Filters
                  {(filters.minRating || filters.hasApi || filters.hasFreeVersion) && (
                    <Badge variant="secondary" className="ml-1 px-1.5 py-0.5 text-xs">
                      {[filters.minRating, filters.hasApi, filters.hasFreeVersion].filter(Boolean).length}
                    </Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-4" align="start">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Minimum Rating</Label>
                    <Select value={filters.minRating} onValueChange={(value) => onFilterChange({ minRating: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any rating" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any rating</SelectItem>
                        <SelectItem value="4">4+ Stars</SelectItem>
                        <SelectItem value="3">3+ Stars</SelectItem>
                        <SelectItem value="2">2+ Stars</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Has API</Label>
                    <Switch 
                      checked={filters.hasApi === "true"} 
                      onCheckedChange={(checked) => onFilterChange({ hasApi: checked ? "true" : "" })}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Free Version Available</Label>
                    <Switch 
                      checked={filters.hasFreeVersion === "true"} 
                      onCheckedChange={(checked) => onFilterChange({ hasFreeVersion: checked ? "true" : "" })}
                    />
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => onFilterChange({ minRating: "", hasApi: "", hasFreeVersion: "" })}
                  >
                    Clear Advanced Filters
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            <Select 
              value={filters.sortBy} 
              onValueChange={(value) => onFilterChange({ sortBy: value as any })}
            >
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popularity">Sort by Popularity</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="recent">Recently Added</SelectItem>
                <SelectItem value="alphabetical">A-Z</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex border border-slate-300 rounded-lg">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewModeChange("grid")}
                className="rounded-r-none"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewModeChange("list")}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
