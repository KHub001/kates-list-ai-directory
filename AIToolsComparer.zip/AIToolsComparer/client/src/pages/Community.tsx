import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import StarRating from "@/components/StarRating";
import { MessageCircle, TrendingUp, Star, Users, Calendar } from "lucide-react";

export default function Community() {
  const { data: trendingTools } = useQuery({
    queryKey: ["/api/tools/trending"],
  });

  const { data: categoriesData } = useQuery({
    queryKey: ["/api/categories"],
  });

  const categoryDisplayNames: { [key: string]: string } = {
    "content-creation": "Content Creation",
    "design": "Design",
    "productivity": "Productivity",
    "video-creation": "Video Creation",
    "image-generation": "Image Generation",
    "code-assistant": "Code Assistant",
    "chatbots": "Chatbots",
    "research": "Research",
    "writing": "Writing",
    "audio": "Audio"
  };

  const mockRecentDiscussions = [
    {
      id: 1,
      title: "Best AI tools for video editing in 2024?",
      author: "Sarah Chen",
      replies: 23,
      lastActivity: "2 hours ago",
      category: "video-creation"
    },
    {
      id: 2,
      title: "How to integrate ChatGPT with my workflow",
      author: "Mike Johnson",
      replies: 15,
      lastActivity: "4 hours ago",
      category: "productivity"
    },
    {
      id: 3,
      title: "Comparison: Midjourney vs DALL-E 3",
      author: "Alex Rivera",
      replies: 31,
      lastActivity: "6 hours ago",
      category: "image-generation"
    },
    {
      id: 4,
      title: "Free alternatives to premium AI writing tools",
      author: "Emma Davis",
      replies: 18,
      lastActivity: "8 hours ago",
      category: "writing"
    }
  ];

  const mockTopContributors = [
    {
      id: 1,
      name: "David Kim",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=david",
      contributions: 47,
      badge: "Expert"
    },
    {
      id: 2,
      name: "Lisa Wang",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=lisa",
      contributions: 32,
      badge: "Contributor"
    },
    {
      id: 3,
      name: "James Wilson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=james",
      contributions: 28,
      badge: "Helper"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Community</h1>
          <p className="text-slate-600">Connect with AI enthusiasts, share experiences, and discover new tools together.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Discussions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Recent Discussions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockRecentDiscussions.map((discussion) => (
                    <div key={discussion.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-slate-900 hover:text-primary-600 transition-colors">
                          {discussion.title}
                        </h3>
                        <Badge variant="secondary" className="text-xs">
                          {categoryDisplayNames[discussion.category] || discussion.category}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm text-slate-600">
                        <div className="flex items-center space-x-4">
                          <span>by {discussion.author}</span>
                          <span className="flex items-center">
                            <MessageCircle className="w-4 h-4 mr-1" />
                            {discussion.replies} replies
                          </span>
                        </div>
                        <span>{discussion.lastActivity}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 text-center">
                  <Button variant="outline">View All Discussions</Button>
                </div>
              </CardContent>
            </Card>

            {/* Trending Tools */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Trending in Community
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trendingTools && Array.isArray(trendingTools) ? trendingTools.slice(0, 4).map((tool: any) => (
                    <div key={tool.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer">
                      <div className="flex items-center space-x-3 mb-3">
                        {tool.logoUrl ? (
                          <img
                            src={tool.logoUrl}
                            alt={tool.name}
                            className="w-10 h-10 rounded object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-slate-200 rounded flex items-center justify-center">
                            <span className="text-slate-600 font-semibold text-sm">
                              {tool.name?.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                        <div>
                          <h4 className="font-semibold text-slate-900">{tool.name}</h4>
                          <p className="text-sm text-slate-600 truncate max-w-[200px]">{tool.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="text-xs">
                          Trending
                        </Badge>
                        <Button size="sm" variant="outline">
                          View Tool
                        </Button>
                      </div>
                    </div>
                  )) : (
                    <div className="col-span-2 text-center text-slate-500 py-8">
                      No trending tools available
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Community Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  Community Stats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Total Members</span>
                  <span className="font-semibold text-slate-900">127</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">AI Tools Listed</span>
                  <span className="font-semibold text-slate-900">175</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Reviews Posted</span>
                  <span className="font-semibold text-slate-900">89</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Active Today</span>
                  <span className="font-semibold text-slate-900">23</span>
                </div>
              </CardContent>
            </Card>

            {/* Top Contributors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="w-5 h-5 mr-2" />
                  Top Contributors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockTopContributors.map((contributor) => (
                    <div key={contributor.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={contributor.avatar} alt={contributor.name} />
                          <AvatarFallback>
                            {contributor.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-slate-900">{contributor.name}</p>
                          <p className="text-sm text-slate-600">{contributor.contributions} contributions</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {contributor.badge}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" variant="outline">
                  Start New Discussion
                </Button>
                <Button className="w-full" variant="outline">
                  Submit AI Tool
                </Button>
                <Button className="w-full" variant="outline">
                  Write Review
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}