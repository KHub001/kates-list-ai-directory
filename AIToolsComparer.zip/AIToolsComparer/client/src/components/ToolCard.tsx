import { useState, memo } from "react";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import StarRating from "./StarRating";
import LazyImage from "./LazyImage";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Heart, ExternalLink, Plus, Check } from "lucide-react";

interface ToolCardProps {
  tool: any;
  viewMode?: "grid" | "list";
  onToggleComparison?: (toolId: number) => void;
  isSelected?: boolean;
}

function ToolCard({ tool, viewMode = "grid", onToggleComparison, isSelected = false }: ToolCardProps) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isFavorite, setIsFavorite] = useState(false);

  const categoryDisplayNames: { [key: string]: string } = {
    "text-generation": "Text Generation",
    "image-generation": "Image Generation", 
    "code-assistance": "Code Assistance",
    "video-creation": "Video Creation",
    "audio-processing": "Audio Processing",
    // Add more mappings as needed
  };

  const pricingDisplayNames: { [key: string]: string } = {
    "free": "Free",
    "freemium": "Freemium",
    "paid": "Paid",
    "enterprise": "Enterprise",
  };

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      if (isFavorite) {
        await apiRequest("DELETE", `/api/tools/${tool.id}/favorite`);
      } else {
        await apiRequest("POST", `/api/tools/${tool.id}/favorite`);
      }
    },
    onSuccess: () => {
      setIsFavorite(!isFavorite);
      toast({
        title: isFavorite ? "Removed from favorites" : "Added to favorites",
        description: isFavorite 
          ? "Tool removed from your favorites list" 
          : "Tool saved to your favorites list",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive",
      });
    },
  });

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to save tools to your favorites",
      });
      return;
    }
    favoriteMutation.mutate();
  };

  const handleComparisonClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onToggleComparison) {
      onToggleComparison(tool.id);
    }
  };

  if (viewMode === "list") {
    return (
      <Card className="hover:shadow-md card-hover">
        <CardContent className="p-6">
          <div className="flex items-center space-x-6">
            {tool.logoUrl && (
              <img
                src={tool.logoUrl}
                alt={`${tool.name} logo`}
                className="w-16 h-16 rounded-lg object-cover flex-shrink-0"
              />
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <Link href={`/tool/${tool.id}`}>
                    <h3 className="text-xl font-semibold text-slate-900 hover:text-primary cursor-pointer">
                      {tool.name}
                    </h3>
                  </Link>
                  <p className="text-slate-600 mt-1 line-clamp-2">{tool.description}</p>
                  <div className="flex items-center space-x-4 mt-3">
                    <Badge variant="secondary" className="category-chip">
                      {categoryDisplayNames[tool.category] || tool.category}
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className={`
                        ${tool.pricingModel === 'free' ? 'bg-green-50 text-green-700 border-green-200' : ''}
                        ${tool.pricingModel === 'freemium' ? 'bg-blue-50 text-blue-700 border-blue-200' : ''}
                        ${tool.pricingModel === 'paid' ? 'bg-orange-50 text-orange-700 border-orange-200' : ''}
                        ${tool.pricingModel === 'enterprise' ? 'bg-purple-50 text-purple-700 border-purple-200' : ''}
                      `}
                    >
                      {pricingDisplayNames[tool.pricingModel] || tool.pricingModel}
                    </Badge>
                    <div className="flex items-center space-x-2">
                      <StarRating rating={tool.ratings?.overall || 0} readonly size="sm" />
                      <span className="text-slate-600 text-sm">
                        {tool.ratings?.overall ? tool.ratings.overall.toFixed(1) : "0.0"} 
                        ({tool.ratings?.totalRatings || 0})
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleFavoriteClick}
                    disabled={favoriteMutation.isPending}
                    className={isFavorite ? "text-red-500" : "text-slate-400 hover:text-red-500"}
                  >
                    <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
                  </Button>
                  {onToggleComparison && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleComparisonClick}
                      className={isSelected ? "text-primary bg-primary/10" : "text-slate-400 hover:text-primary"}
                    >
                      {isSelected ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    </Button>
                  )}
                  <Button asChild variant="outline" size="sm">
                    <a href={tool.websiteUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Visit
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-slate-200 hover:shadow-md card-hover p-6">
      <div className="flex items-start justify-between mb-4">
        {tool.logoUrl ? (
          <LazyImage
            src={tool.logoUrl}
            alt={`${tool.name} logo`}
            className="w-12 h-12 rounded-lg object-cover"
            fallback={`data:image/svg+xml,${encodeURIComponent(`
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
                <rect width="48" height="48" fill="#f1f5f9" rx="8"/>
                <text x="24" y="28" text-anchor="middle" fill="#64748b" font-size="14" font-family="Arial">
                  ${tool.name.charAt(0).toUpperCase()}
                </text>
              </svg>
            `)}`}
          />
        ) : (
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
            <i className="fas fa-robot text-primary text-xl"></i>
          </div>
        )}
        <div className="flex items-center space-x-1">
          {onToggleComparison && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleComparisonClick}
              className={isSelected ? "text-primary bg-primary/10" : "text-slate-400 hover:text-primary"}
            >
              {isSelected ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleFavoriteClick}
            disabled={favoriteMutation.isPending}
            className={isFavorite ? "text-red-500" : "text-slate-400 hover:text-red-500"}
          >
            <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
          </Button>
        </div>
      </div>

      <Link href={`/tool/${tool.id}`}>
        <h3 className="text-lg font-semibold text-slate-900 mb-2 hover:text-primary cursor-pointer">
          {tool.name}
        </h3>
      </Link>
      
      <p className="text-slate-600 text-sm mb-4 line-clamp-3">{tool.description}</p>
      
      <div className="flex items-center mb-3">
        <StarRating rating={tool.ratings?.overall || 0} readonly size="sm" />
        <span className="text-slate-600 text-sm ml-2">
          {tool.ratings?.overall ? tool.ratings.overall.toFixed(1) : "0.0"} 
          ({tool.ratings?.totalRatings || 0})
        </span>
      </div>
      
      <div className="flex flex-wrap gap-1 mb-4">
        <Badge 
          variant="outline" 
          className={
            tool.pricingModel === "free" 
              ? "bg-green-100 text-green-700 border-green-200" 
              : tool.pricingModel === "freemium"
              ? "bg-blue-100 text-blue-700 border-blue-200"
              : tool.pricingModel === "paid"
              ? "bg-orange-100 text-orange-700 border-orange-200"
              : "bg-purple-100 text-purple-700 border-purple-200"
          }
        >
          {pricingDisplayNames[tool.pricingModel] || tool.pricingModel}
        </Badge>
        {tool.hasApi && (
          <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
            API
          </Badge>
        )}
      </div>
      
      <Link href={`/tool/${tool.id}`}>
        <Button className="w-full" size="sm">
          View Details
        </Button>
      </Link>
    </Card>
  );
}

export default memo(ToolCard);
