import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ToolCard from "@/components/ToolCard";
import { Brain, Zap, Target, TrendingUp, Filter, Search, Star, Users } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface UserProfile {
  interests: string[];
  experienceLevel: 'beginner' | 'intermediate' | 'expert';
  primaryUseCase: string;
  industryFocus: string[];
}

export default function AIToolDiscovery() {
  const [activeTab, setActiveTab] = useState("discover");
  const [searchQuery, setSearchQuery] = useState("");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [discoveryMode, setDiscoveryMode] = useState<'trending' | 'personalized' | 'similar'>('trending');
  const queryClient = useQueryClient();

  // Get user session for tracking
  const [sessionId] = useState(() => {
    let id = localStorage.getItem('userSessionId');
    if (!id) {
      id = Math.random().toString(36).substring(2) + Date.now().toString(36);
      localStorage.setItem('userSessionId', id);
    }
    return id;
  });

  // Fetch personalized recommendations
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery({
    queryKey: ['/api/recommendations', sessionId, discoveryMode],
    enabled: !!sessionId,
  });

  // Fetch trending tools
  const { data: trendingTools } = useQuery({
    queryKey: ['/api/tools/trending'],
  });

  // Fetch user behavior analytics
  const { data: userAnalytics } = useQuery({
    queryKey: ['/api/analytics/user-behavior', sessionId],
    enabled: !!sessionId,
  });

  // Track tool interaction
  const trackInteraction = useMutation({
    mutationFn: async (data: { toolId: number; action: string; context?: string }) => {
      return apiRequest('/api/analytics/track-interaction', {
        method: 'POST',
        body: {
          ...data,
          sessionId,
          timestamp: new Date().toISOString()
        }
      });
    },
  });

  // Update user preferences
  const updatePreferences = useMutation({
    mutationFn: async (preferences: Partial<UserProfile>) => {
      return apiRequest('/api/user-preferences/update', {
        method: 'POST',
        body: {
          sessionId,
          preferences,
          timestamp: new Date().toISOString()
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
    }
  });

  const handleToolClick = (tool: any) => {
    trackInteraction.mutate({
      toolId: tool.id,
      action: 'view',
      context: `discovery_${discoveryMode}`
    });
  };

  const handleToolFavorite = (tool: any) => {
    trackInteraction.mutate({
      toolId: tool.id,
      action: 'favorite',
      context: 'discovery'
    });
  };

  const DiscoveryStats = () => (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Tools Discovered</p>
              <p className="text-2xl font-bold">{userAnalytics?.toolsDiscovered || 0}</p>
            </div>
            <Search className="h-8 w-8 text-primary/60" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Categories Explored</p>
              <p className="text-2xl font-bold">{userAnalytics?.categoriesExplored || 0}</p>
            </div>
            <Filter className="h-8 w-8 text-primary/60" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Recommendation Score</p>
              <p className="text-2xl font-bold">{userAnalytics?.recommendationScore || 0}%</p>
            </div>
            <Target className="h-8 w-8 text-primary/60" />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600">Match Accuracy</p>
              <p className="text-2xl font-bold">{userAnalytics?.matchAccuracy || 0}%</p>
            </div>
            <Brain className="h-8 w-8 text-primary/60" />
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const ProfileSetup = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Personalize Your Discovery Experience
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium">Experience Level</label>
          <div className="flex gap-2 mt-2">
            {['beginner', 'intermediate', 'expert'].map((level) => (
              <Button
                key={level}
                variant={userProfile?.experienceLevel === level ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  const newProfile = { ...userProfile, experienceLevel: level as any };
                  setUserProfile(newProfile);
                  updatePreferences.mutate(newProfile);
                }}
              >
                {level.charAt(0).toUpperCase() + level.slice(1)}
              </Button>
            ))}
          </div>
        </div>
        
        <div>
          <label className="text-sm font-medium">Primary Use Case</label>
          <Input
            placeholder="e.g., Content creation, Data analysis, Automation"
            value={userProfile?.primaryUseCase || ""}
            onChange={(e) => setUserProfile(prev => ({ ...prev, primaryUseCase: e.target.value }))}
            className="mt-2"
          />
        </div>
        
        <div>
          <label className="text-sm font-medium">Industries of Interest</label>
          <div className="flex flex-wrap gap-2 mt-2">
            {['Technology', 'Marketing', 'Healthcare', 'Education', 'Finance', 'Creative'].map((industry) => (
              <Badge
                key={industry}
                variant={userProfile?.industryFocus?.includes(industry) ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => {
                  const current = userProfile?.industryFocus || [];
                  const updated = current.includes(industry)
                    ? current.filter(i => i !== industry)
                    : [...current, industry];
                  const newProfile = { ...userProfile, industryFocus: updated };
                  setUserProfile(newProfile);
                  updatePreferences.mutate(newProfile);
                }}
              >
                {industry}
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const SmartRecommendations = () => {
    const getRecommendationTitle = () => {
      switch (discoveryMode) {
        case 'trending': return 'Trending Tools';
        case 'personalized': return 'Recommended for You';
        case 'similar': return 'Similar Tools';
        default: return 'Discover Tools';
      }
    };

    const tools = discoveryMode === 'trending' ? trendingTools : recommendations;

    return (
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">{getRecommendationTitle()}</h2>
          <div className="flex gap-2">
            {['trending', 'personalized', 'similar'].map((mode) => (
              <Button
                key={mode}
                variant={discoveryMode === mode ? "default" : "outline"}
                size="sm"
                onClick={() => setDiscoveryMode(mode as any)}
              >
                {mode === 'trending' && <TrendingUp className="h-4 w-4 mr-1" />}
                {mode === 'personalized' && <Target className="h-4 w-4 mr-1" />}
                {mode === 'similar' && <Users className="h-4 w-4 mr-1" />}
                {mode.charAt(0).toUpperCase() + mode.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        {recommendationsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-slate-200 h-48 rounded-lg"></div>
              </div>
            ))}
          </div>
        ) : tools?.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool: any) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                onClick={() => handleToolClick(tool)}
                onFavorite={() => handleToolFavorite(tool)}
                showMatchScore={discoveryMode === 'personalized'}
              />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <Brain className="h-16 w-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-medium mb-2">No recommendations yet</h3>
              <p className="text-slate-600 mb-4">
                Interact with more tools to get personalized recommendations
              </p>
              <Button onClick={() => setActiveTab("profile")}>
                Set Up Your Profile
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const DiscoveryInsights = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Your Discovery Journey</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Profile Completeness</span>
                <span className="text-sm text-slate-600">
                  {userAnalytics?.profileCompleteness || 0}%
                </span>
              </div>
              <Progress value={userAnalytics?.profileCompleteness || 0} />
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Category Coverage</span>
                <span className="text-sm text-slate-600">
                  {userAnalytics?.categoryCoverage || 0}%
                </span>
              </div>
              <Progress value={userAnalytics?.categoryCoverage || 0} />
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Engagement Level</span>
                <span className="text-sm text-slate-600">
                  {userAnalytics?.engagementLevel || 0}%
                </span>
              </div>
              <Progress value={userAnalytics?.engagementLevel || 0} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Personalization Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              "Rate more tools to improve recommendations",
              "Explore different categories to broaden your profile",
              "Complete your preferences for better matching",
              "Save tools to favorites to teach the AI your preferences"
            ].map((tip, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-medium text-primary">{index + 1}</span>
                </div>
                <p className="text-sm text-slate-600">{tip}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">AI Tool Discovery</h1>
        <p className="text-slate-600">
          Discover AI tools tailored to your needs with intelligent recommendations
        </p>
      </div>

      <DiscoveryStats />

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          <SmartRecommendations />
        </TabsContent>

        <TabsContent value="profile" className="space-y-6">
          <ProfileSetup />
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <DiscoveryInsights />
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Discovery History</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600">Track your tool discovery journey over time</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}