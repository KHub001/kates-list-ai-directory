import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import ToolCard from "@/components/ToolCard";
import { Brain, TrendingUp, Target, Users, Sparkles } from "lucide-react";

interface SmartRecommendationsProps {
  currentTool?: any;
  userBehavior?: {
    viewedCategories: string[];
    searchQueries: string[];
    favoriteTools: number[];
    comparedTools: number[];
  };
  onToolClick?: (tool: any) => void;
}

export default function SmartRecommendations({ 
  currentTool, 
  userBehavior,
  onToolClick 
}: SmartRecommendationsProps) {
  const [sessionId] = useState(() => {
    // Get or create session ID for tracking
    let id = localStorage.getItem('userSessionId');
    if (!id) {
      id = Math.random().toString(36).substring(2) + Date.now().toString(36);
      localStorage.setItem('userSessionId', id);
    }
    return id;
  });

  // Fetch AI-powered recommendations
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery({
    queryKey: ['/api/recommendations', sessionId],
    enabled: !!sessionId,
  });

  // Fetch trending tools
  const { data: trendingTools } = useQuery({
    queryKey: ['/api/tools/trending'],
  });

  // Fetch similar tools if viewing a specific tool
  const { data: similarTools } = useQuery({
    queryKey: ['/api/tools/similar', currentTool?.id],
    enabled: !!currentTool?.id,
  });

  // Track user interactions
  useEffect(() => {
    if (currentTool && sessionId) {
      // Track tool view for recommendation engine
      fetch('/api/analytics/track-view', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId: currentTool.id,
          sessionId,
          timestamp: new Date().toISOString(),
          context: 'recommendation_view'
        })
      }).catch(console.error);
    }
  }, [currentTool, sessionId]);

  const updateUserPreferences = (viewedTools: number[], categories: string[]) => {
    if (!sessionId) return;
    
    fetch('/api/user-preferences/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId,
        viewedTools,
        categories,
        timestamp: new Date().toISOString()
      })
    }).catch(console.error);
  };

  const RecommendationSection = ({ 
    title, 
    tools, 
    icon: Icon, 
    description,
    isLoading = false 
  }: {
    title: string;
    tools: any[];
    icon: any;
    description: string;
    isLoading?: boolean;
  }) => (
    <Card className="h-full">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Icon className="h-5 w-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <p className="text-sm text-slate-600 mt-1">{description}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-slate-200 rounded-lg"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : tools && tools.length > 0 ? (
          <div className="space-y-3">
            {tools.slice(0, 3).map((tool) => (
              <div
                key={tool.id}
                className="flex items-center space-x-3 p-3 rounded-lg border border-slate-200 hover:border-primary/30 hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => onToolClick?.(tool)}
              >
                {tool.logoUrl ? (
                  <img
                    src={tool.logoUrl}
                    alt={tool.name}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                    <Brain className="h-6 w-6 text-primary" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-slate-900 truncate">{tool.name}</h4>
                  <p className="text-sm text-slate-600 line-clamp-2">{tool.description}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary" className="text-xs">
                      {tool.category}
                    </Badge>
                    {tool.ratings && (
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-amber-500">★</span>
                        <span className="text-xs text-slate-600">
                          {tool.ratings.overallExperience?.toFixed(1) || "0.0"}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {tools.length > 3 && (
              <Button variant="outline" size="sm" className="w-full mt-3">
                View All {tools.length} Recommendations
              </Button>
            )}
          </div>
        ) : (
          <div className="text-center py-6 text-slate-500">
            <Icon className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No recommendations available yet</p>
            <p className="text-xs mt-1">Browse more tools to get personalized suggestions</p>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Personalization Score */}
      {userBehavior && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg">
                  <Target className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg">Personalization Status</CardTitle>
                  <p className="text-sm text-slate-600">Your recommendation accuracy improves with usage</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-primary">
                  {Math.min(85, (userBehavior.viewedCategories.length * 15) + (userBehavior.searchQueries.length * 5))}%
                </div>
                <p className="text-xs text-slate-600">Accuracy</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Categories Explored</span>
                <span className="text-sm font-medium">{userBehavior.viewedCategories.length}/10</span>
              </div>
              <Progress 
                value={(userBehavior.viewedCategories.length / 10) * 100} 
                className="h-2"
              />
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Tools Interactions</span>
                <span className="text-sm font-medium">
                  {userBehavior.favoriteTools.length + userBehavior.comparedTools.length}/20
                </span>
              </div>
              <Progress 
                value={((userBehavior.favoriteTools.length + userBehavior.comparedTools.length) / 20) * 100} 
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* AI-Powered Recommendations */}
        <RecommendationSection
          title="For You"
          description="AI-curated tools based on your preferences"
          icon={Sparkles}
          tools={recommendations || []}
          isLoading={recommendationsLoading}
        />

        {/* Similar Tools */}
        {currentTool && (
          <RecommendationSection
            title="Similar Tools"
            description={`Tools similar to ${currentTool.name}`}
            icon={Target}
            tools={similarTools || []}
          />
        )}

        {/* Trending Tools */}
        <RecommendationSection
          title="Trending Now"
          description="Popular tools in the community"
          icon={TrendingUp}
          tools={trendingTools || []}
        />

        {/* Community Picks */}
        <RecommendationSection
          title="Community Favorites"
          description="Highly rated by the community"
          icon={Users}
          tools={[]} // This would come from community ratings
        />
      </div>

      {/* Learning Banner */}
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/20 rounded-full">
              <Brain className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-slate-900">Improving Your Recommendations</h3>
              <p className="text-sm text-slate-600 mt-1">
                The more you explore and interact with tools, the better our AI becomes at suggesting 
                relevant solutions for your specific needs.
              </p>
            </div>
            <Button variant="outline" size="sm">
              Learn More
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}