import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Target, Award, Globe } from "lucide-react";

export default function About() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const stats = [
    { label: "AI Tools Listed", value: "175", icon: Globe },
    { label: "Categories", value: "17", icon: Target },
    { label: "Community Members", value: "127", icon: Users },
    { label: "User Reviews", value: "89", icon: Award }
  ];



  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            About <span className="text-purple-600">Kate's List</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-4xl mx-auto leading-relaxed">
            We're building the world's most comprehensive platform for discovering, comparing, and reviewing AI tools. 
            Our mission is to help individuals and businesses navigate the rapidly evolving AI landscape with confidence and clarity.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-100 rounded-lg mb-4">
                    <IconComponent className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900 mb-2">{stat.value}</div>
                  <div className="text-slate-600">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Mission Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-8">Our Mission</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Globe className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Democratize AI Access</h3>
                <p className="text-slate-600">
                  Make AI tools accessible to everyone, regardless of technical background or budget constraints.
                </p>
              </CardContent>
            </Card>
            
            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Target className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Provide Clarity</h3>
                <p className="text-slate-600">
                  Cut through the noise with honest reviews, detailed comparisons, and practical guidance.
                </p>
              </CardContent>
            </Card>
            
            <Card className="p-6">
              <CardContent className="p-0">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Build Community</h3>
                <p className="text-slate-600">
                  Foster a community where users share experiences and help each other succeed with AI.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Story Section */}
        <div className="mb-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-slate-900 text-center mb-8">Our Story</h2>
            <div className="prose prose-lg mx-auto text-slate-600">
              <p className="text-lg leading-relaxed mb-6">
                Kate's List was born out of frustration. As AI tools proliferated at breakneck speed, 
                we found ourselves spending countless hours researching, testing, and comparing different platforms. 
                The information was scattered, biased, or simply outdated.
              </p>
              <p className="text-lg leading-relaxed mb-6">
                We realized that thousands of others were facing the same challenge. Business owners struggling 
                to choose the right AI writing tool. Developers trying to find the best code assistant. 
                Content creators overwhelmed by video generation options.
              </p>
              <p className="text-lg leading-relaxed">
                So we decided to build the resource we wished existed: a comprehensive, unbiased platform 
                where anyone could discover the perfect AI tools for their needs, backed by real user reviews 
                and expert analysis.
              </p>
            </div>
          </div>
        </div>


      </main>

      <Footer />
    </div>
  );
}