import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

interface SidebarProps {
  onFilterChange: (filters: any) => void;
}

export default function Sidebar({ onFilterChange }: SidebarProps) {
  return null;
}
