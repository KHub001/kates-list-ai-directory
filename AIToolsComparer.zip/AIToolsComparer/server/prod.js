const express = require('express');
const http = require('http');

const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', (req, res) => {
  res.json([
    { category: "ai-writing", count: 25 },
    { category: "image-generation", count: 18 }
  ]);
});

app.get('/api/tools', (req, res) => {
  res.json({
    tools: [{
      id: 1,
      name: "ChatGPT",
      description: "AI chatbot",
      websiteUrl: "https://chatgpt.com",
      category: "chatbots",
      pricingModel: "freemium"
    }],
    total: 1
  });
});

app.get('/api/tools/featured', (req, res) => {
  res.json({
    id: 1,
    name: "ChatGPT",
    description: "AI chatbot",
    category: "chatbots"
  });
});

app.get('/api/logo/:domain', (req, res) => {
  res.redirect('https://logo.clearbit.com/' + req.params.domain);
});

app.get('*', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Kate's List - AI Directory</title>
        <meta charset="utf-8">
      </head>
      <body>
        <h1>Kate's List - AI Directory</h1>
        <p>AI tools platform is running</p>
      </body>
    </html>
  `);
});

const port = process.env.PORT || 5000;
http.createServer(app).listen(port, () => {
  console.log('Production server running on port ' + port);
});