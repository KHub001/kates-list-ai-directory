import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Sparkles, 
  Star, 
  TrendingUp, 
  Brain,
  ArrowRight,
  Eye,
  Heart
} from "lucide-react";

interface AiTool {
  id: number;
  name: string;
  description: string;
  category: string;
  websiteUrl: string;
  logoUrl?: string;
  pricingModel: string;
  hasFreeTier: boolean;
  features: string[];
}

interface AIRecommendationsProps {
  sessionId?: string;
  className?: string;
  maxRecommendations?: number;
}

export default function AIRecommendations({ 
  sessionId, 
  className = "",
  maxRecommendations = 6 
}: AIRecommendationsProps) {
  const [userSessionId, setUserSessionId] = useState<string>(sessionId || '');

  // Generate session ID if not provided
  useEffect(() => {
    if (!sessionId) {
      const newSessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      setUserSessionId(newSessionId);
    }
  }, [sessionId]);

  const { data: recommendations, isLoading, error } = useQuery({
    queryKey: ["/api/recommendations", userSessionId],
    enabled: !!userSessionId,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: trendingTools } = useQuery({
    queryKey: ["/api/tools/trending"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const trackToolView = async (toolId: number) => {
    if (!userSessionId) return;
    
    try {
      await fetch('/api/track/view', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId,
          sessionId: userSessionId,
          userAgent: navigator.userAgent,
          referrer: document.referrer
        })
      });
    } catch (error) {
      console.error('Failed to track tool view:', error);
    }
  };

  const displayTools = recommendations?.recommendations || trendingTools?.tools || [];
  const limitedTools = displayTools.slice(0, maxRecommendations);

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-purple-600" />
            <CardTitle>AI Recommendations</CardTitle>
          </div>
          <CardDescription>
            Personalized AI tools based on your interests
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-20 w-full" />
                <div className="flex space-x-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-20" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !limitedTools.length) {
    return (
      <Card className={className}>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-blue-600" />
            <CardTitle>Discover AI Tools</CardTitle>
          </div>
          <CardDescription>
            Explore trending AI tools in our directory
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">
              Start exploring AI tools to get personalized recommendations
            </p>
            <Link to="/tools">
              <Button>
                Browse All Tools
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasPersonalizedData = recommendations?.recommendations?.length > 0;

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {hasPersonalizedData ? (
              <Sparkles className="h-5 w-5 text-purple-600" />
            ) : (
              <TrendingUp className="h-5 w-5 text-blue-600" />
            )}
            <CardTitle>
              {hasPersonalizedData ? 'AI Recommendations' : 'Trending Tools'}
            </CardTitle>
          </div>
          {hasPersonalizedData && (
            <Badge variant="secondary" className="bg-purple-100 text-purple-700">
              <Brain className="h-3 w-3 mr-1" />
              Powered by AI
            </Badge>
          )}
        </div>
        <CardDescription>
          {hasPersonalizedData 
            ? 'Personalized suggestions based on your activity'
            : 'Popular AI tools trending in our community'
          }
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {limitedTools.map((tool: AiTool) => (
            <div
              key={tool.id}
              className="group border rounded-lg p-4 hover:shadow-md transition-all duration-200 hover:border-purple-200"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {tool.logoUrl ? (
                    <img 
                      src={tool.logoUrl} 
                      alt={`${tool.name} logo`}
                      className="w-8 h-8 rounded object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-white text-sm font-bold">
                      {tool.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <h3 className="font-semibold text-sm group-hover:text-purple-600 transition-colors">
                      {tool.name}
                    </h3>
                    <Badge variant="outline" className="text-xs">
                      {tool.category}
                    </Badge>
                  </div>
                </div>
                {tool.hasFreeTier && (
                  <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                    Free
                  </Badge>
                )}
              </div>

              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                {tool.description}
              </p>

              {tool.features && tool.features.length > 0 && (
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    {tool.features.slice(0, 2).map((feature, index) => (
                      <span 
                        key={index}
                        className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded"
                      >
                        {feature}
                      </span>
                    ))}
                    {tool.features.length > 2 && (
                      <span className="text-xs text-gray-500">
                        +{tool.features.length - 2} more
                      </span>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 text-xs text-gray-500">
                  <div className="flex items-center">
                    <Eye className="h-3 w-3 mr-1" />
                    <span>View</span>
                  </div>
                  <div className="flex items-center">
                    <Heart className="h-3 w-3 mr-1" />
                    <span>Save</span>
                  </div>
                </div>
                <Link 
                  to={`/tool/${tool.id}`}
                  onClick={() => trackToolView(tool.id)}
                >
                  <Button 
                    size="sm" 
                    variant="ghost"
                    className="group-hover:bg-purple-50 group-hover:text-purple-600"
                  >
                    Learn More
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {limitedTools.length >= maxRecommendations && (
          <div className="mt-6 text-center">
            <Link to={hasPersonalizedData ? "/recommendations" : "/tools"}>
              <Button variant="outline">
                {hasPersonalizedData ? 'View All Recommendations' : 'Explore More Tools'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        )}

        {hasPersonalizedData && (
          <div className="mt-4 p-3 bg-purple-50 rounded-lg">
            <div className="flex items-center space-x-2 text-sm text-purple-700">
              <Sparkles className="h-4 w-4" />
              <span className="font-medium">AI-Powered Suggestions</span>
            </div>
            <p className="text-xs text-purple-600 mt-1">
              These recommendations improve as you explore more AI tools in our directory.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}