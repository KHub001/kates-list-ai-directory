import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireAuth } from "./auth";
import { relevanceAI } from "./relevanceai";
import { db } from "./db";

// Admin-only middleware - restricts access to only the platform owner
function requireAdminAuth(req: any, res: any, next: any) {
  // First check if user is authenticated
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  // Check if this is you (the platform owner) - replace with your actual user ID
  const adminUserId = process.env.ADMIN_USER_ID; // You'll need to set this
  const currentUserId = req.user.id;
  
  if (!adminUserId || currentUserId !== adminUserId) {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  next();
}
import { insertRatingSchema, insertReviewSchema, insertAiToolSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for deployment debugging
  app.get('/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      env: process.env.NODE_ENV,
      database: !!process.env.DATABASE_URL
    });
  });



  // Auth middleware with error handling
  try {
    setupAuth(app);
  } catch (error) {
    console.error("Auth setup failed:", error);
    // Continue without auth in case of setup failure
  }
  
  // Local authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      const { username, email, firstName, lastName, password } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // Create new user with hashed password
      const newUser = await storage.createUser({
        id: email, // Using email as ID for local auth
        email,
        password: password, // Store password (in production, hash this)
        firstName,
        lastName,
        profileImageUrl: null,
      });
      
      // Set session for the user (simplified session management)
      req.session = req.session || {};
      (req.session as any).userId = newUser.id;
      
      res.json(newUser);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });
  
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Find user by email (using username field as email)
      const user = await storage.getUserByEmail(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // For now, accept any password (you can add proper password hashing later)
      // Set session for the user
      req.session = req.session || {};
      (req.session as any).userId = user.id;
      
      res.json(user);
    } catch (error) {
      console.error("Login error:", error);
      res.status(401).json({ message: "Login failed" });
    }
  });
  
  app.post("/api/logout", async (req, res) => {
    // Clear session data
    if (req.session) {
      (req.session as any).userId = null;
    }
    res.json({ message: "Logged out successfully" });
  });
  
  app.get("/api/user", async (req, res) => {
    try {
      // Check if session exists and is properly initialized
      if (!req.session) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = (req.session as any)?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        // Clear invalid session
        if (req.session) {
          req.session.destroy(() => {});
        }
        return res.status(401).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      // Clear potentially corrupted session
      if (req.session) {
        req.session.destroy(() => {});
      }
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // Configure multer for file uploads
  const uploadDir = path.join(process.cwd(), 'uploads');
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const upload = multer({
    storage: multer.diskStorage({
      destination: uploadDir,
      filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'profile-' + uniqueSuffix + path.extname(file.originalname));
      }
    }),
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB limit
    },
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed'));
      }
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));

  // User profile routes
  app.put("/api/user/profile", requireAuth, upload.single('profileImage'), async (req: any, res) => {
    try {
      const { firstName, lastName, email } = req.body;
      let profileImageUrl = req.user.profileImageUrl;

      // If a new image was uploaded, update the URL
      if (req.file) {
        profileImageUrl = `/uploads/${req.file.filename}`;
      }

      const updatedUser = await storage.updateUserProfile(req.user.id, {
        email,
        firstName,
        lastName,
        profileImageUrl,
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.get("/api/user/favorites", requireAuth, async (req: any, res) => {
    try {
      const favorites = await storage.getUserFavorites(req.user.id);
      res.json(favorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  // AI Tools routes
  app.get('/api/tools', async (req, res) => {
    try {
      const {
        category,
        pricingModel,
        search,
        minRating,
        hasApi,
        hasFreeVersion,
        sortBy = 'popularity',
        limit = 20,
        offset = 0
      } = req.query;

      const filters = {
        category: category as string,
        pricingModel: pricingModel as string,
        search: search as string,
        minRating: minRating as string,
        hasApi: hasApi as string,
        hasFreeVersion: hasFreeVersion as string,
        sortBy: sortBy as "popularity" | "rating" | "recent" | "alphabetical",
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      };

      const result = await storage.getAllTools(filters);
      
      // Return tools with minimal rating data for performance
      const toolsWithRatings = result.tools.map(tool => ({
        ...tool,
        ratings: { overallExperience: 0, valueForMoney: 0, qualityOfOutput: 0, totalRatings: 0 }
      }));
      
      res.json({ tools: toolsWithRatings, total: result.total });
    } catch (error) {
      console.error("Error fetching tools:", error);
      res.status(500).json({ message: "Failed to fetch tools" });
    }
  });

  // Featured tool rotation schedule endpoint for admin/testing (must be before general featured route)
  app.get('/api/tools/featured/schedule', async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 7;
      const tools = await storage.getAllTools({ limit: 1000 });
      const activeTools = tools.tools.filter(t => t.isActive).sort((a, b) => a.id - b.id);
      
      if (activeTools.length === 0) {
        return res.json({ schedule: [], totalActiveTools: 0 });
      }
      
      const schedule = [];
      const today = new Date();
      
      for (let i = 0; i < days; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        
        const daysSinceEpoch = Math.floor(date.getTime() / (1000 * 60 * 60 * 24));
        const featuredIndex = daysSinceEpoch % activeTools.length;
        const featuredTool = activeTools[featuredIndex];
        
        schedule.push({
          date: date.toISOString().split('T')[0],
          tool: {
            id: featuredTool.id,
            name: featuredTool.name,
            category: featuredTool.category
          }
        });
      }
      
      res.json({ 
        schedule,
        totalActiveTools: activeTools.length,
        rotationCycle: `${activeTools.length} days`
      });
    } catch (error) {
      console.error("Error generating featured tool schedule:", error);
      res.status(500).json({ message: "Failed to generate schedule" });
    }
  });

  app.get('/api/tools/featured', async (req, res) => {
    try {
      const featuredTool = await storage.getFeaturedTool();
      if (!featuredTool) {
        return res.status(404).json({ message: "No featured tool found" });
      }
      
      // Get ratings for the featured tool
      const ratings = await storage.getToolAverageRatings(featuredTool.id);
      
      res.json({ ...featuredTool, ratings });
    } catch (error) {
      console.error("Error fetching featured tool:", error);
      res.status(500).json({ message: "Failed to fetch featured tool" });
    }
  });

  app.get('/api/tools/trending', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const trendingTools = await storage.getTrendingTools(limit);
      
      // Add rating data to each trending tool
      const toolsWithRatings = await Promise.all(
        trendingTools.map(async (tool) => {
          const ratings = await storage.getToolAverageRatings(tool.id);
          return { ...tool, ratings };
        })
      );
      
      res.json(toolsWithRatings);
    } catch (error) {
      console.error("Error fetching trending tools:", error);
      res.status(500).json({ message: "Failed to fetch trending tools" });
    }
  });

  // Generic tool by ID route (must be last among /api/tools routes)
  app.get('/api/tools/:id', async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      if (isNaN(toolId)) {
        return res.status(400).json({ message: "Invalid tool ID" });
      }
      const tool = await storage.getToolById(toolId);
      
      if (!tool) {
        return res.status(404).json({ message: "Tool not found" });
      }
      
      // Get additional data
      const [ratings, reviews] = await Promise.all([
        storage.getToolAverageRatings(toolId),
        storage.getToolReviews(toolId, { limit: 10 })
      ]);
      
      res.json({ ...tool, ratings, reviews });
    } catch (error) {
      console.error("Error fetching tool:", error);
      res.status(500).json({ message: "Failed to fetch tool" });
    }
  });

  app.post('/api/tools', requireAuth, async (req: any, res) => {
    try {
      const toolData = insertAiToolSchema.parse(req.body);
      const tool = await storage.createTool(toolData);
      res.status(201).json(tool);
    } catch (error) {
      console.error("Error creating tool:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create tool" });
    }
  });

  // Categories route
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Ratings routes
  app.get('/api/tools/:id/ratings', async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const ratings = await storage.getToolAverageRatings(toolId);
      res.json(ratings);
    } catch (error) {
      console.error("Error fetching ratings:", error);
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });

  app.post('/api/tools/:id/ratings', requireAuth, async (req: any, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const ratingData = insertRatingSchema.parse({
        ...req.body,
        userId,
        toolId
      });
      
      const rating = await storage.createOrUpdateRating(ratingData);
      res.json(rating);
    } catch (error) {
      console.error("Error creating rating:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create rating" });
    }
  });

  // Reviews routes
  app.get('/api/tools/:id/reviews', async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const { sortBy, limit = 10, offset = 0 } = req.query;
      
      const reviews = await storage.getToolReviews(toolId, {
        sortBy: sortBy as "recent" | "helpful" | "rating",
        limit: parseInt(limit as string),
        offset: parseInt(offset as string),
      });
      
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/tools/:id/reviews', requireAuth, async (req: any, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId,
        toolId
      });
      
      const review = await storage.createReview(reviewData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.post('/api/reviews/:id/helpful', requireAuth, async (req: any, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const userId = req.user.id;
      const { isHelpful } = req.body;
      
      await storage.markReviewHelpful(userId, reviewId, isHelpful);
      res.json({ message: "Review helpfulness updated" });
    } catch (error) {
      console.error("Error updating review helpfulness:", error);
      res.status(500).json({ message: "Failed to update review helpfulness" });
    }
  });

  // Favorites routes
  app.get('/api/favorites', requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const favorites = await storage.getUserFavorites(userId);
      res.json(favorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  app.post('/api/tools/:id/favorite', requireAuth, async (req: any, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const favorite = await storage.addToFavorites(userId, toolId);
      res.status(201).json(favorite);
    } catch (error) {
      console.error("Error adding to favorites:", error);
      res.status(500).json({ message: "Failed to add to favorites" });
    }
  });

  app.delete('/api/tools/:id/favorite', requireAuth, async (req: any, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = req.user.id;
      
      await storage.removeFromFavorites(userId, toolId);
      res.json({ message: "Removed from favorites" });
    } catch (error) {
      console.error("Error removing from favorites:", error);
      res.status(500).json({ message: "Failed to remove from favorites" });
    }
  });

  app.get('/api/tools/:id/favorite', requireAuth, async (req: any, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = req.user.id;
      
      const isFavorite = await storage.isFavorite(userId, toolId);
      res.json({ isFavorite });
    } catch (error) {
      console.error("Error checking favorite status:", error);
      res.status(500).json({ message: "Failed to check favorite status" });
    }
  });

  // Logo proxy endpoint for high-quality company logos
  app.get('/api/logo/:domain', async (req, res) => {
    try {
      const domain = req.params.domain.replace(/^https?:\/\//, '');
      
      // Try Clearbit Logo API first (high quality logos)
      const clearbitUrl = `https://logo.clearbit.com/${domain}?size=150`;
      const clearbitResponse = await fetch(clearbitUrl);
      
      if (clearbitResponse.ok) {
        const logoBuffer = await clearbitResponse.arrayBuffer();
        res.setHeader('Content-Type', 'image/png');
        res.setHeader('Cache-Control', 'public, max-age=86400');
        res.send(Buffer.from(logoBuffer));
        return;
      }
      
      // Fallback: Generate a branded placeholder
      const companyName = domain.split('.')[0];
      const initial = companyName.charAt(0).toUpperCase();
      
      const svg = `<svg width="150" height="150" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#7c3aed;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#6b46c1;stop-opacity:1" />
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#grad)" rx="20"/>
        <text x="50%" y="50%" text-anchor="middle" dy=".3em" 
              font-family="Arial, sans-serif" font-size="60" 
              font-weight="bold" fill="white">
          ${initial}
        </text>
      </svg>`;
      
      res.setHeader('Content-Type', 'image/svg+xml');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      res.send(svg);
      
    } catch (error) {
      console.error('Error fetching logo:', error);
      
      // Error fallback
      const domain = req.params.domain.replace(/^https?:\/\//, '');
      const companyName = domain.split('.')[0];
      const initial = companyName.charAt(0).toUpperCase();
      
      const svg = `<svg width="150" height="150" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#7c3aed" rx="20"/>
        <text x="50%" y="50%" text-anchor="middle" dy=".3em" 
              font-family="Arial, sans-serif" font-size="60" 
              font-weight="bold" fill="white">
          ${initial}
        </text>
      </svg>`;
      
      res.setHeader('Content-Type', 'image/svg+xml');
      res.send(svg);
    }
  });

  // AI-powered recommendations
  app.get('/api/recommendations/:sessionId', async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      const mode = req.query.mode || 'personalized';
      
      let recommendations = [];
      
      if (mode === 'personalized') {
        recommendations = await storage.getRecommendationsForUser(sessionId);
      } else {
        const trending = await storage.getTrendingTools(16);
        recommendations = trending;
      }
      
      res.json(recommendations);
    } catch (error) {
      console.error("Error fetching recommendations:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  // Trending tools endpoint
  app.get('/api/tools/trending', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const trending = await storage.getTrendingTools(limit);
      res.json(trending);
    } catch (error) {
      console.error("Error fetching trending tools:", error);
      res.status(500).json({ message: "Failed to fetch trending tools" });
    }
  });

  // User behavior tracking
  app.post('/api/analytics/track-interaction', async (req, res) => {
    try {
      const { toolId, sessionId, action, context, timestamp } = req.body;
      
      await storage.trackToolView(toolId, sessionId, req.get('User-Agent'), req.get('Referer'));
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking interaction:", error);
      res.status(500).json({ message: "Failed to track interaction" });
    }
  });

  // Update user preferences
  app.post('/api/user-preferences/update', async (req, res) => {
    try {
      const { sessionId, preferences, viewedTools, categories } = req.body;
      
      if (viewedTools && categories) {
        await storage.updateUserPreferences(sessionId, viewedTools, categories);
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // User analytics
  app.get('/api/analytics/user-behavior/:sessionId', async (req, res) => {
    try {
      const sessionId = req.params.sessionId;
      
      const userSession = await storage.getOrCreateUserSession(sessionId);
      
      const analytics = {
        toolsDiscovered: userSession.viewedToolsCount || 0,
        categoriesExplored: userSession.categoriesExplored?.length || 0,
        recommendationScore: Math.min(95, (userSession.viewedToolsCount || 0) * 2),
        matchAccuracy: Math.min(90, ((userSession.categoriesExplored?.length || 0) * 15) + 10),
        profileCompleteness: userSession.preferencesSet ? 85 : 25,
        categoryCoverage: Math.min(100, (userSession.categoriesExplored?.length || 0) * 10),
        engagementLevel: Math.min(100, (userSession.viewedToolsCount || 0) * 3)
      };
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching user analytics:", error);
      res.status(500).json({ message: "Failed to fetch user analytics" });
    }
  });

  // Newsletter subscription routes
  app.post('/api/newsletter/subscribe', async (req, res) => {
    try {
      const { email, source = 'website' } = req.body;
      
      if (!email || !email.includes('@')) {
        return res.status(400).json({ message: "Valid email address is required" });
      }
      
      // Check if already subscribed
      const existingSubscription = await storage.getNewsletterSubscription(email);
      if (existingSubscription && existingSubscription.status === 'active') {
        return res.status(200).json({ message: "Already subscribed", subscription: existingSubscription });
      }
      
      // Subscribe or reactivate
      const subscription = await storage.subscribeToNewsletter(email, source);
      res.status(201).json({ message: "Successfully subscribed", subscription });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });

  app.post('/api/newsletter/unsubscribe', async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email address is required" });
      }
      
      await storage.unsubscribeFromNewsletter(email);
      res.json({ message: "Successfully unsubscribed" });
    } catch (error) {
      console.error("Error unsubscribing from newsletter:", error);
      res.status(500).json({ message: "Failed to unsubscribe from newsletter" });
    }
  });

  // Relevance AI data update routes
  app.post("/api/admin/update-tools", requireAuth, async (req, res) => {
    try {
      await relevanceAI.fetchLatestAITools();
      res.json({ message: "Successfully updated AI tools data" });
    } catch (error) {
      console.error("Error updating tools:", error);
      res.status(500).json({ message: "Failed to update tools data" });
    }
  });

  app.get("/api/admin/sync-status", requireAuth, async (req, res) => {
    try {
      const stats = await storage.getAllTools({ limit: 1 });
      res.json({ 
        message: "Relevance AI sync service is active",
        totalTools: stats.total,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error checking sync status:", error);
      res.status(500).json({ message: "Failed to check sync status" });
    }
  });

  // Helper route to get your user ID for admin setup
  app.get("/api/my-user-id", requireAuth, async (req: any, res) => {
    try {
      res.json({ 
        userId: req.user.id,
        message: "Use this ID as ADMIN_USER_ID in your environment variables"
      });
    } catch (error) {
      console.error("Error fetching user ID:", error);
      res.status(500).json({ message: "Failed to fetch user ID" });
    }
  });

  // Analytics API routes (admin-only access)
  app.get("/api/analytics/overview", requireAuth, requireAdminAuth, async (req: any, res) => {
    try {
      const timeRange = req.query.range as string || "7d";
      const data = await storage.getAnalyticsOverview(timeRange);
      res.json(data);
    } catch (error) {
      console.error("Error fetching analytics overview:", error);
      res.status(500).json({ message: "Failed to fetch analytics overview" });
    }
  });

  app.get("/api/analytics/tool-views", requireAuth, requireAdminAuth, async (req: any, res) => {
    try {
      const timeRange = req.query.range as string || "7d";
      const data = await storage.getToolViewsAnalytics(timeRange);
      res.json(data);
    } catch (error) {
      console.error("Error fetching tool views analytics:", error);
      res.status(500).json({ message: "Failed to fetch tool views analytics" });
    }
  });

  app.get("/api/analytics/searches", requireAuth, requireAdminAuth, async (req: any, res) => {
    try {
      const timeRange = req.query.range as string || "7d";
      const data = await storage.getSearchAnalytics(timeRange);
      res.json(data);
    } catch (error) {
      console.error("Error fetching search analytics:", error);
      res.status(500).json({ message: "Failed to fetch search analytics" });
    }
  });

  app.get("/api/analytics/user-behavior", requireAuth, requireAdminAuth, async (req: any, res) => {
    try {
      const timeRange = req.query.range as string || "7d";
      const data = await storage.getUserBehaviorAnalytics(timeRange);
      res.json(data);
    } catch (error) {
      console.error("Error fetching user behavior analytics:", error);
      res.status(500).json({ message: "Failed to fetch user behavior analytics" });
    }
  });

  app.get("/api/analytics/top-tools", requireAuth, requireAdminAuth, async (req: any, res) => {
    try {
      const timeRange = req.query.range as string || "7d";
      const data = await storage.getTopToolsAnalytics(timeRange);
      res.json(data);
    } catch (error) {
      console.error("Error fetching top tools analytics:", error);
      res.status(500).json({ message: "Failed to fetch top tools analytics" });
    }
  });

  // AI Recommendations API
  app.get("/api/recommendations/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const recommendations = await storage.getRecommendationsForUser(sessionId);
      res.json({ recommendations });
    } catch (error) {
      console.error("Error fetching recommendations:", error);
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.post("/api/track/view", async (req, res) => {
    try {
      const { toolId, sessionId, userAgent, referrer } = req.body;
      await storage.trackToolView(toolId, sessionId, userAgent, referrer);
      
      // Update user preferences for AI recommendations
      await storage.updateUserPreferences(sessionId, [toolId], []);
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking tool view:", error);
      res.status(500).json({ message: "Failed to track tool view" });
    }
  });

  app.post("/api/track/search", async (req, res) => {
    try {
      const { query, category, resultsCount, sessionId } = req.body;
      await storage.trackSearchQuery(query, category, resultsCount, sessionId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking search:", error);
      res.status(500).json({ message: "Failed to track search" });
    }
  });

  // Tool Integrations API
  app.get("/api/tools/:id/integrations", async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const integrations = await storage.getToolIntegrations(toolId);
      res.json({ integrations });
    } catch (error) {
      console.error("Error fetching tool integrations:", error);
      res.status(500).json({ message: "Failed to fetch tool integrations" });
    }
  });

  app.get("/api/tools/:id/partners", async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const partners = await storage.getIntegrationPartners(toolId);
      res.json({ partners });
    } catch (error) {
      console.error("Error fetching integration partners:", error);
      res.status(500).json({ message: "Failed to fetch integration partners" });
    }
  });

  app.post("/api/tools/:id/integrations", async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const integrationData = {
        ...req.body,
        toolId,
      };
      const integration = await storage.addToolIntegration(integrationData);
      res.json({ integration });
    } catch (error) {
      console.error("Error adding tool integration:", error);
      res.status(500).json({ message: "Failed to add tool integration" });
    }
  });

  // Development route to add sample ratings data
  app.post('/api/dev/sample-ratings', async (req, res) => {
    try {
      if (process.env.NODE_ENV !== 'development') {
        return res.status(403).json({ message: "Not available in production" });
      }
      
      // Get all tools
      const tools = await storage.getAllTools({ limit: 20 });
      
      // Add sample ratings for each tool
      const sampleRatings = [];
      for (const tool of tools.tools) {
        // Generate 3-10 random ratings per tool
        const numRatings = Math.floor(Math.random() * 8) + 3;
        
        for (let i = 0; i < numRatings; i++) {
          const baseRating = 3.5 + Math.random() * 1.5; // 3.5 to 5.0 range
          sampleRatings.push({
            toolId: tool.id,
            userId: `sample-user-${i}`,
            overallExperience: Math.min(5, Math.max(1, Math.round(baseRating + (Math.random() - 0.5) * 0.5))),
            valueForMoney: Math.min(5, Math.max(1, Math.round(baseRating + (Math.random() - 0.5) * 0.6))),
            qualityOfOutput: Math.min(5, Math.max(1, Math.round(baseRating + (Math.random() - 0.5) * 0.5))),
          });
        }
      }
      
      // Insert sample ratings
      for (const rating of sampleRatings) {
        await storage.createOrUpdateRating(rating);
      }
      
      res.json({ 
        message: `Added ${sampleRatings.length} sample ratings for ${tools.tools.length} tools`,
        ratingsAdded: sampleRatings.length 
      });
    } catch (error) {
      console.error("Error adding sample ratings:", error);
      res.status(500).json({ message: "Failed to add sample ratings" });
    }
  });

  // Community member registration
  app.post('/api/community/join', async (req, res) => {
    try {
      const memberData = req.body;
      
      // Check if member already exists
      const existingMember = await storage.getCommunityMember(memberData.email);
      if (existingMember) {
        return res.status(409).json({ message: 'User already registered' });
      }

      const member = await storage.createCommunityMember(memberData);
      res.json(member);
    } catch (error) {
      console.error('Community registration error:', error);
      res.status(500).json({ message: 'Failed to register community member' });
    }
  });

  // Contact/messaging system
  app.post('/api/contact', async (req, res) => {
    try {
      const messageData = req.body;
      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error('Failed to send message:', error);
      res.status(500).json({ message: 'Failed to send message' });
    }
  });

  // Community reviews
  app.post('/api/tools/:toolId/community-reviews', async (req, res) => {
    try {
      const { toolId } = req.params;
      const reviewData = {
        ...req.body,
        toolId: parseInt(toolId),
      };
      
      const review = await storage.createCommunityReview(reviewData);
      res.json(review);
    } catch (error) {
      console.error('Failed to create community review:', error);
      res.status(500).json({ message: 'Failed to create review' });
    }
  });

  // Get community reviews for a tool
  app.get('/api/tools/:toolId/community-reviews', async (req, res) => {
    try {
      const { toolId } = req.params;
      const { sortBy, limit, offset } = req.query;
      
      const options = {
        sortBy: sortBy as "recent" | "helpful" | "rating",
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      };
      
      const reviews = await storage.getCommunityReviews(parseInt(toolId), options);
      res.json(reviews);
    } catch (error) {
      console.error('Failed to fetch community reviews:', error);
      res.status(500).json({ message: 'Failed to fetch reviews' });
    }
  });

  // Admin routes for community management
  app.get('/api/admin/community/members', async (req, res) => {
    try {
      const { limit, offset, isActive } = req.query;
      const options = {
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
        isActive: isActive ? isActive === 'true' : undefined,
      };
      
      const result = await storage.getAllCommunityMembers(options);
      res.json(result);
    } catch (error) {
      console.error('Failed to fetch community members:', error);
      res.status(500).json({ message: 'Failed to fetch community members' });
    }
  });

  app.get('/api/admin/messages', async (req, res) => {
    try {
      const { isRead, category, priority, limit, offset } = req.query;
      const options = {
        isRead: isRead ? isRead === 'true' : undefined,
        category: category as string,
        priority: priority as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      };
      
      const result = await storage.getAllMessages(options);
      res.json(result);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
      res.status(500).json({ message: 'Failed to fetch messages' });
    }
  });

  app.patch('/api/admin/messages/:id/read', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markMessageAsRead(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to mark message as read:', error);
      res.status(500).json({ message: 'Failed to mark message as read' });
    }
  });

  // Admin community reviews endpoint
  app.get('/api/admin/community-reviews', async (req, res) => {
    try {
      const { sortBy, limit, offset } = req.query;
      const options = {
        sortBy: sortBy as "recent" | "helpful" | "rating",
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      };
      
      const result = await storage.getAllCommunityReviews(options);
      res.json(result);
    } catch (error) {
      console.error('Failed to fetch community reviews:', error);
      res.status(500).json({ message: 'Failed to fetch community reviews' });
    }
  });

  app.patch('/api/admin/community-reviews/:id/approve', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.approveCommunityReview(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to approve review:', error);
      res.status(500).json({ message: 'Failed to approve review' });
    }
  });

  app.patch('/api/admin/community-reviews/:id/verify', async (req, res) => {
    try {
      const { id } = req.params;
      await storage.verifyCommunityReview(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to verify review:', error);
      res.status(500).json({ message: 'Failed to verify review' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
