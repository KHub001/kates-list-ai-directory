import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import StarRating from "@/components/StarRating";
import ReviewForm from "@/components/ReviewForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Heart, ExternalLink, Calendar, Globe, Code, DollarSign } from "lucide-react";
import type { AiTool } from "@shared/schema";

export default function ToolDetail() {
  const { id } = useParams();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showReviewForm, setShowReviewForm] = useState(false);

  // Scroll to top when component mounts or ID changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  const { data: tool, isLoading } = useQuery<AiTool & { ratings?: any; reviews?: any[] }>({
    queryKey: [`/api/tools/${id}`],
  });

  const { data: favoriteStatus } = useQuery<{ isFavorite: boolean }>({
    queryKey: [`/api/tools/${id}/favorite`],
    enabled: isAuthenticated,
  });

  const favoriteMutation = useMutation({
    mutationFn: async () => {
      if (favoriteStatus && typeof favoriteStatus === 'object' && 'isFavorite' in favoriteStatus && favoriteStatus.isFavorite) {
        await apiRequest("DELETE", `/api/tools/${id}/favorite`);
      } else {
        await apiRequest("POST", `/api/tools/${id}/favorite`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tools/${id}/favorite`] });
      const isFavorite = favoriteStatus && typeof favoriteStatus === 'object' && 'isFavorite' in favoriteStatus && favoriteStatus.isFavorite;
      toast({
        title: isFavorite ? "Removed from favorites" : "Added to favorites",
        description: isFavorite 
          ? "Tool removed from your favorites list" 
          : "Tool saved to your favorites list",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update favorites",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded mb-4 w-1/3"></div>
            <div className="h-4 bg-slate-200 rounded mb-8 w-2/3"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="h-64 bg-slate-200 rounded-xl"></div>
              </div>
              <div className="h-96 bg-slate-200 rounded-xl"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!tool) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Tool Not Found</h1>
            <p className="text-slate-600">The AI tool you're looking for doesn't exist.</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const categoryDisplayNames: { [key: string]: string } = {
    "text-generation": "Text Generation",
    "image-generation": "Image Generation",
    "code-assistance": "Code Assistance",
    "video-creation": "Video Creation",
    "audio-processing": "Audio Processing",
    // Add more mappings as needed
  };

  const pricingDisplayNames: { [key: string]: string } = {
    "free": "Free",
    "freemium": "Freemium",
    "paid": "Paid",
    "enterprise": "Enterprise",
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Tool Header */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 mb-8">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center space-x-4">
                  {tool.logoUrl && (
                    <img
                      src={tool.logoUrl}
                      alt={`${tool.name} logo`}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                  )}
                  <div>
                    <h1 className="text-3xl font-bold text-slate-900 mb-2">{tool.name}</h1>
                    <div className="flex items-center space-x-4">
                      <Badge variant="secondary" className="category-chip">
                        {categoryDisplayNames[tool.category] || tool.category}
                      </Badge>
                      {tool.ratings && typeof tool.ratings.overallExperience === 'number' && tool.ratings.overallExperience > 0 && (
                        <div className="flex items-center space-x-2">
                          <StarRating rating={tool.ratings.overallExperience} readonly size="sm" />
                          <span className="text-slate-600 text-sm">
                            {tool.ratings.overallExperience.toFixed(1)} ({tool.ratings.totalRatings || 0} reviews)
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  {isAuthenticated && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => favoriteMutation.mutate()}
                      disabled={favoriteMutation.isPending}
                      className={favoriteStatus?.isFavorite ? "text-red-500 border-red-200" : ""}
                    >
                      <Heart 
                        className={`w-4 h-4 mr-2 ${favoriteStatus?.isFavorite ? "fill-current" : ""}`} 
                      />
                      {favoriteStatus?.isFavorite ? "Saved" : "Save"}
                    </Button>
                  )}
                  <Button asChild>
                    <a href={tool.websiteUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Visit Platform
                    </a>
                  </Button>
                </div>
              </div>

              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                {tool.description}
              </p>

              {/* Tool Features */}
              {tool.features && tool.features.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-slate-900 mb-3">Key Features</h3>
                  <div className="flex flex-wrap gap-2">
                    {tool.features.map((feature: string, index: number) => (
                      <Badge key={index} variant="outline">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Tool Metadata */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-slate-200">
                <div className="flex items-center space-x-2 text-sm text-slate-600">
                  <DollarSign className="w-4 h-4" />
                  <span>{pricingDisplayNames[tool.pricingModel] || tool.pricingModel}</span>
                </div>
                {tool.hasApi && (
                  <div className="flex items-center space-x-2 text-sm text-slate-600">
                    <Code className="w-4 h-4" />
                    <span>API Available</span>
                  </div>
                )}
                {tool.country && (
                  <div className="flex items-center space-x-2 text-sm text-slate-600">
                    <Globe className="w-4 h-4" />
                    <span>{tool.country}</span>
                  </div>
                )}
                {tool.launchDate && (
                  <div className="flex items-center space-x-2 text-sm text-slate-600">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(tool.launchDate).getFullYear()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="reviews" className="space-y-6">
              <TabsList className="bg-white border border-slate-200">
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="ratings">Detailed Ratings</TabsTrigger>
              </TabsList>
              
              <TabsContent value="reviews" className="space-y-6">
                {/* Reviews Header */}
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-slate-900">User Reviews</h3>
                  {isAuthenticated && (
                    <Button onClick={() => setShowReviewForm(true)}>
                      Write a Review
                    </Button>
                  )}
                </div>

                {/* Review Form */}
                {showReviewForm && (
                  <ReviewForm
                    toolId={parseInt(id!)}
                    onSuccess={() => {
                      setShowReviewForm(false);
                      queryClient.invalidateQueries({ queryKey: [`/api/tools/${id}`] });
                    }}
                    onCancel={() => setShowReviewForm(false)}
                  />
                )}

                {/* Reviews List */}
                <div className="space-y-4">
                  {tool.reviews && tool.reviews.length > 0 ? (
                    tool.reviews.map((review: any) => (
                      <Card key={review.id}>
                        <CardHeader className="pb-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-sm text-slate-600">
                                By {review.user?.firstName || "Anonymous"} • {new Date(review.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                            {review.helpfulCount > 0 && (
                              <Badge variant="outline">
                                {review.helpfulCount} found helpful
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-slate-700">{review.content}</p>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8 text-slate-600">
                      <p>No reviews yet. Be the first to review this tool!</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="ratings">
                {tool.ratings ? (
                  <Card>
                    <CardHeader>
                      <CardTitle>Detailed Ratings Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex justify-between items-center">
                          <span>Overall Experience</span>
                          <div className="flex items-center space-x-2">
                            <StarRating rating={tool.ratings.overallExperience || 0} readonly size="sm" />
                            <span className="text-sm font-medium">{(tool.ratings.overallExperience || 0).toFixed(1)}</span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Value for Money</span>
                          <div className="flex items-center space-x-2">
                            <StarRating rating={tool.ratings.valueForMoney || 0} readonly size="sm" />
                            <span className="text-sm font-medium">{(tool.ratings.valueForMoney || 0).toFixed(1)}</span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Quality of Output</span>
                          <div className="flex items-center space-x-2">
                            <StarRating rating={tool.ratings.qualityOfOutput || 0} readonly size="sm" />
                            <span className="text-sm font-medium">{(tool.ratings.qualityOfOutput || 0).toFixed(1)}</span>
                          </div>
                        </div>
                      </div>
                      <div className="pt-4 border-t border-slate-200 text-center">
                        <p className="text-sm text-slate-600">
                          Based on {tool.ratings.totalRatings} user ratings
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="text-center py-8 text-slate-600">
                    <p>No ratings available yet.</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Similar Tools */}
            <Card>
              <CardHeader>
                <CardTitle>Similar Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">
                  Discover more tools in the {categoryDisplayNames[tool.category] || tool.category} category.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}
