import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Brain, Zap, Target, ArrowRight, CheckCircle, Clock, AlertCircle, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface WorkflowStep {
  id: string;
  toolId: number;
  tool: any;
  action: string;
  inputs: Record<string, any>;
  outputs: Record<string, any>;
  dependencies: string[];
  estimatedTime: number;
  status: 'pending' | 'running' | 'completed' | 'failed';
}

interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  steps: WorkflowStep[];
  estimatedDuration: number;
  complexity: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
}

export default function AIWorkflowAssistant() {
  const [activeTab, setActiveTab] = useState("generate");
  const [userPrompt, setUserPrompt] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState("");
  const [workflowGoal, setWorkflowGoal] = useState("");
  const [currentWorkflow, setCurrentWorkflow] = useState<WorkflowTemplate | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  // Fetch workflow templates
  const { data: templates } = useQuery({
    queryKey: ['/api/workflows/templates'],
  });

  // Fetch user's workflows
  const { data: userWorkflows } = useQuery({
    queryKey: ['/api/workflows/user'],
  });

  // Generate workflow mutation
  const generateWorkflow = useMutation({
    mutationFn: async (params: { prompt: string; industry?: string; goal?: string }) => {
      return apiRequest('/api/workflows/generate', {
        method: 'POST',
        body: params
      });
    },
    onSuccess: (data) => {
      setCurrentWorkflow(data);
      setIsGenerating(false);
    },
    onError: () => {
      setIsGenerating(false);
    }
  });

  // Execute workflow mutation
  const executeWorkflow = useMutation({
    mutationFn: async (workflowId: string) => {
      return apiRequest('/api/workflows/execute', {
        method: 'POST',
        body: { workflowId }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/workflows/user'] });
    }
  });

  const handleGenerateWorkflow = () => {
    if (!userPrompt.trim()) return;
    
    setIsGenerating(true);
    generateWorkflow.mutate({
      prompt: userPrompt,
      industry: selectedIndustry,
      goal: workflowGoal
    });
  };

  const WorkflowGenerator = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Workflow Generator
          </CardTitle>
          <p className="text-sm text-slate-600">
            Describe what you want to accomplish, and I'll create an intelligent workflow using the best AI tools
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">What do you want to accomplish?</label>
            <Textarea
              placeholder="e.g., Create a marketing campaign for a new product, analyze customer feedback data, generate content for social media..."
              value={userPrompt}
              onChange={(e) => setUserPrompt(e.target.value)}
              className="min-h-24"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Industry (Optional)</label>
              <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                <SelectTrigger>
                  <SelectValue placeholder="Select industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Primary Goal (Optional)</label>
              <Select value={workflowGoal} onValueChange={setWorkflowGoal}>
                <SelectTrigger>
                  <SelectValue placeholder="Select goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automation">Automation</SelectItem>
                  <SelectItem value="analysis">Analysis</SelectItem>
                  <SelectItem value="creation">Content Creation</SelectItem>
                  <SelectItem value="optimization">Optimization</SelectItem>
                  <SelectItem value="research">Research</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button 
            onClick={handleGenerateWorkflow}
            disabled={!userPrompt.trim() || isGenerating}
            className="w-full"
          >
            {isGenerating ? (
              <>
                <Brain className="h-4 w-4 mr-2 animate-spin" />
                Generating Workflow...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate AI Workflow
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {currentWorkflow && (
        <WorkflowPreview workflow={currentWorkflow} />
      )}
    </div>
  );

  const WorkflowPreview = ({ workflow }: { workflow: WorkflowTemplate }) => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Generated Workflow: {workflow.name}</span>
          <Badge variant="outline" className="capitalize">
            {workflow.complexity}
          </Badge>
        </CardTitle>
        <p className="text-sm text-slate-600">{workflow.description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4 text-sm text-slate-600">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {workflow.estimatedDuration} minutes
          </div>
          <div className="flex items-center gap-1">
            <Target className="h-4 w-4" />
            {workflow.steps.length} steps
          </div>
        </div>
        
        <div className="space-y-3">
          {workflow.steps.map((step, index) => (
            <div key={step.id} className="flex items-start gap-4 p-4 border rounded-lg">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-sm font-medium text-primary">{index + 1}</span>
              </div>
              
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-medium">{step.tool?.name || 'Unknown Tool'}</h4>
                    <p className="text-sm text-slate-600">{step.action}</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {step.tool?.logoUrl && (
                      <img
                        src={step.tool.logoUrl}
                        alt={step.tool.name}
                        className="w-6 h-6 rounded object-cover"
                      />
                    )}
                    <Badge variant="secondary" className="text-xs">
                      {step.estimatedTime}min
                    </Badge>
                  </div>
                </div>
                
                {step.dependencies.length > 0 && (
                  <div className="text-xs text-slate-500">
                    Depends on: {step.dependencies.join(', ')}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="flex items-center gap-3 pt-4">
          <Button onClick={() => executeWorkflow.mutate(workflow.id)}>
            <Zap className="h-4 w-4 mr-2" />
            Execute Workflow
          </Button>
          <Button variant="outline">
            Save as Template
          </Button>
          <Button variant="outline">
            Customize Steps
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const WorkflowTemplates = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Popular Workflow Templates</h3>
        <Button variant="outline" size="sm">
          Browse All
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates?.map((template: WorkflowTemplate) => (
          <Card key={template.id} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <p className="text-sm text-slate-600 mt-1">{template.description}</p>
                </div>
                <Badge variant="outline" className="capitalize text-xs">
                  {template.complexity}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-4 text-sm text-slate-600">
                  <span>{template.steps.length} steps</span>
                  <span>{template.estimatedDuration}min</span>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  {template.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {template.tags.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{template.tags.length - 3}
                    </Badge>
                  )}
                </div>
                
                <Button size="sm" className="w-full">
                  Use Template
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const UserWorkflows = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Your Workflows</h3>
        <Button variant="outline" size="sm">
          Create New
        </Button>
      </div>
      
      {userWorkflows && userWorkflows.length > 0 ? (
        <div className="space-y-3">
          {userWorkflows.map((workflow: any) => (
            <Card key={workflow.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-start gap-4">
                    <div className="flex-1">
                      <h4 className="font-medium">{workflow.name}</h4>
                      <p className="text-sm text-slate-600">{workflow.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
                        <span>Created {workflow.createdAt}</span>
                        <span>Last run {workflow.lastExecuted || 'Never'}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        {workflow.status === 'completed' && (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        )}
                        {workflow.status === 'running' && (
                          <Clock className="h-4 w-4 text-blue-500" />
                        )}
                        {workflow.status === 'failed' && (
                          <AlertCircle className="h-4 w-4 text-red-500" />
                        )}
                        <span className="text-sm capitalize">{workflow.status}</span>
                      </div>
                      
                      {workflow.status === 'running' && (
                        <Progress value={workflow.progress || 0} className="w-20" />
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                    <Button size="sm">
                      Run
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-8">
            <Brain className="h-12 w-12 mx-auto mb-4 text-slate-300" />
            <h3 className="font-medium mb-2">No workflows yet</h3>
            <p className="text-sm text-slate-600 mb-4">
              Create your first AI workflow to automate your tasks
            </p>
            <Button>Create First Workflow</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">AI Workflow Assistant</h1>
        <p className="text-slate-600">
          Build intelligent workflows that connect multiple AI tools to accomplish complex tasks automatically
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="generate">Generate</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="my-workflows">My Workflows</TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-6">
          <WorkflowGenerator />
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <WorkflowTemplates />
        </TabsContent>

        <TabsContent value="my-workflows" className="space-y-6">
          <UserWorkflows />
        </TabsContent>
      </Tabs>
    </div>
  );
}