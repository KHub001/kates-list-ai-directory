import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Star, ThumbsUp, ThumbsDown, Flag, MessageSquare } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Review {
  id: number;
  userId: string;
  toolId: number;
  rating: number;
  title: string;
  content: string;
  helpfulCount: number;
  verificationStatus: string;
  createdAt: string;
  user?: {
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
}

interface ReviewsSectionProps {
  toolId: number;
  className?: string;
}

export default function ReviewsSection({ toolId, className }: ReviewsSectionProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({
    rating: 5,
    title: "",
    content: "",
  });

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ["/api/tools", toolId, "reviews"],
  });

  const { data: userRating } = useQuery({
    queryKey: ["/api/tools", toolId, "user-rating"],
    enabled: !!user,
  });

  const createReviewMutation = useMutation({
    mutationFn: async (reviewData: any) => {
      return apiRequest(`/api/tools/${toolId}/reviews`, {
        method: "POST",
        body: JSON.stringify(reviewData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tools", toolId, "reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tools", toolId, "user-rating"] });
      setShowReviewForm(false);
      setNewReview({ rating: 5, title: "", content: "" });
      toast({
        title: "Review submitted",
        description: "Thank you for sharing your experience!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit review",
        variant: "destructive",
      });
    },
  });

  const markHelpfulMutation = useMutation({
    mutationFn: async ({ reviewId, isHelpful }: { reviewId: number; isHelpful: boolean }) => {
      return apiRequest(`/api/reviews/${reviewId}/helpful`, {
        method: "POST",
        body: JSON.stringify({ isHelpful }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tools", toolId, "reviews"] });
    },
  });

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Login required",
        description: "Please log in to submit a review",
        variant: "destructive",
      });
      return;
    }
    createReviewMutation.mutate(newReview);
  };

  const renderStars = (rating: number, interactive = false, onChange?: (rating: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating
                ? "fill-yellow-400 text-yellow-400"
                : "text-slate-300"
            } ${interactive ? "cursor-pointer hover:text-yellow-400" : ""}`}
            onClick={interactive && onChange ? () => onChange(star) : undefined}
          />
        ))}
      </div>
    );
  };

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum: number, review: Review) => sum + review.rating, 0) / reviews.length
    : 0;

  return (
    <div className={className}>
      {/* Reviews Summary */}
      <div className="mb-6">
        <div className="flex items-center gap-4 mb-4">
          <h3 className="text-xl font-semibold">Community Reviews</h3>
          <div className="flex items-center gap-2">
            {renderStars(Math.round(averageRating))}
            <span className="text-sm text-slate-600">
              {averageRating.toFixed(1)} ({reviews.length} reviews)
            </span>
          </div>
        </div>

        {user && !userRating && (
          <Button
            onClick={() => setShowReviewForm(!showReviewForm)}
            variant="outline"
            size="sm"
            className="mb-4"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Write a Review
          </Button>
        )}
      </div>

      {/* Review Form */}
      {showReviewForm && (
        <Card className="mb-6">
          <CardHeader>
            <h4 className="font-semibold">Share Your Experience</h4>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitReview} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Rating</label>
                {renderStars(newReview.rating, true, (rating) =>
                  setNewReview(prev => ({ ...prev, rating }))
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Title</label>
                <input
                  type="text"
                  value={newReview.title}
                  onChange={(e) => setNewReview(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Summarize your experience"
                  className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Review</label>
                <Textarea
                  value={newReview.content}
                  onChange={(e) => setNewReview(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Share details about your experience with this AI tool"
                  rows={4}
                  required
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={createReviewMutation.isPending}>
                  {createReviewMutation.isPending ? "Submitting..." : "Submit Review"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowReviewForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Reviews List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8">Loading reviews...</div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            No reviews yet. Be the first to share your experience!
          </div>
        ) : (
          reviews.map((review: Review) => (
            <Card key={review.id}>
              <CardContent className="pt-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-primary-700">
                        {review.user?.firstName?.[0] || 'U'}
                      </span>
                    </div>
                    <div>
                      <div className="font-medium">
                        {review.user?.firstName} {review.user?.lastName}
                      </div>
                      <div className="flex items-center gap-2">
                        {renderStars(review.rating)}
                        <span className="text-sm text-slate-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {review.verificationStatus === 'verified' && (
                    <Badge variant="secondary" className="text-xs">
                      Verified
                    </Badge>
                  )}
                </div>

                <h4 className="font-medium mb-2">{review.title}</h4>
                <p className="text-slate-700 mb-3">{review.content}</p>

                <div className="flex items-center gap-4 text-sm">
                  <button
                    onClick={() => markHelpfulMutation.mutate({ reviewId: review.id, isHelpful: true })}
                    className="flex items-center gap-1 text-slate-500 hover:text-slate-700"
                  >
                    <ThumbsUp className="w-4 h-4" />
                    Helpful ({review.helpfulCount})
                  </button>
                  
                  <button className="flex items-center gap-1 text-slate-500 hover:text-slate-700">
                    <Flag className="w-4 h-4" />
                    Report
                  </button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}