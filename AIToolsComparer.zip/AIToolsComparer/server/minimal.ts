import express, { type Request, Response } from "express";
import { createServer } from "http";
import path from "path";
import fs from "fs";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development'
  });
});

// Basic API endpoints that always work
app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', (req, res) => {
  res.json([
    { category: "ai-writing", count: 25 },
    { category: "image-generation", count: 18 },
    { category: "code-generation", count: 15 },
    { category: "chatbots", count: 12 }
  ]);
});

app.get('/api/tools', (req, res) => {
  res.json({
    tools: [
      {
        id: 1,
        name: "ChatGPT",
        description: "Advanced AI chatbot for conversations and assistance",
        websiteUrl: "https://chatgpt.com",
        logoUrl: "/api/logo/chatgpt.com",
        category: "chatbots",
        pricingModel: "freemium",
        hasApi: true,
        hasFreeVersion: true,
        features: ["conversation", "writing", "coding"],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
      }
    ],
    total: 1
  });
});

app.get('/api/tools/featured', (req, res) => {
  res.json({
    id: 1,
    name: "ChatGPT",
    description: "Advanced AI chatbot for conversations and assistance",
    websiteUrl: "https://chatgpt.com",
    logoUrl: "/api/logo/chatgpt.com",
    category: "chatbots",
    pricingModel: "freemium",
    hasApi: true,
    hasFreeVersion: true,
    features: ["conversation", "writing", "coding"],
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
  });
});

// Logo proxy endpoint
app.get('/api/logo/:domain', (req, res) => {
  res.redirect(`https://logo.clearbit.com/${req.params.domain}`);
});

// Serve static files from client/dist if it exists, otherwise use Vite
const clientDistPath = path.join(process.cwd(), 'client', 'dist');
if (fs.existsSync(clientDistPath)) {
  app.use(express.static(clientDistPath));
  app.use('*', (req, res) => {
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
} else {
  // Fallback to a simple HTML response
  app.use('*', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Kate's List - AI Directory</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body>
          <h1>Kate's List - AI Directory</h1>
          <p>Loading...</p>
          <script>
            fetch('/api/tools')
              .then(r => r.json())
              .then(data => {
                document.body.innerHTML = '<h1>Kate\\'s List</h1><p>Tools loaded: ' + data.total + '</p>';
              })
              .catch(e => {
                document.body.innerHTML = '<h1>Kate\\'s List</h1><p>Service starting...</p>';
              });
          </script>
        </body>
      </html>
    `);
  });
}

const server = createServer(app);
const port = 5000;

server.listen(port, '0.0.0.0', () => {
  console.log(`Minimal server running on port ${port}`);
});