import { useState, useEffect, useCallback } from "react";
import { useQuery, useInfiniteQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import FeaturedTool from "@/components/FeaturedTool";
import ToolCard from "@/components/ToolCard";
import ToolCardSkeleton from "@/components/ToolCardSkeleton";
import CategoryFilter from "@/components/CategoryFilter";
import Sidebar from "@/components/Sidebar";
import ToolComparison from "@/components/ToolComparison";
import SmartRecommendations from "@/components/SmartRecommendations";
import SEO from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Grid3X3, List, AlertCircle, RefreshCw } from "lucide-react";

export default function Home() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const [filters, setFilters] = useState({
    category: "",
    pricingModel: "",
    search: "",
    minRating: "",
    hasApi: "",
    hasFreeVersion: "",
    sortBy: "popularity" as "popularity" | "rating" | "recent" | "alphabetical",
  });
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchDebounced, setSearchDebounced] = useState(filters.search);
  const [selectedTools, setSelectedTools] = useState<number[]>([]);
  const pageSize = 20;

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchDebounced(filters.search);
    }, 300);
    return () => clearTimeout(timer);
  }, [filters.search]);

  // Infinite query for tools with debounced search
  const {
    data: toolsData,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading: toolsLoading,
    error: toolsError,
    refetch: refetchTools
  } = useInfiniteQuery({
    queryKey: ["/api/tools", { ...filters, search: searchDebounced }],
    queryFn: ({ pageParam = 0 }) => {
      const url = new URL("/api/tools", window.location.origin);
      Object.entries({ ...filters, search: searchDebounced }).forEach(([key, value]) => {
        if (value) url.searchParams.set(key, value);
      });
      url.searchParams.set("limit", pageSize.toString());
      url.searchParams.set("offset", (pageParam * pageSize).toString());
      return fetch(url).then(res => res.json());
    },
    getNextPageParam: (lastPage, allPages) => {
      const totalLoaded = allPages.reduce((acc, page) => acc + page.tools.length, 0);
      return totalLoaded < lastPage.total ? allPages.length : undefined;
    },
    initialPageParam: 0,
  });

  const { data: featuredTool, isLoading: featuredLoading, error: featuredError } = useQuery({
    queryKey: ["/api/tools/featured"],
  });

  // Flatten the infinite query data
  const allTools = toolsData?.pages?.flatMap(page => page.tools) || [];
  const totalTools = toolsData?.pages?.[0]?.total || 0;
  


  const handleFilterChange = (newFilters: Partial<typeof filters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  // Tool comparison handlers
  const handleToggleTool = (toolId: number) => {
    setSelectedTools(prev => 
      prev.includes(toolId) 
        ? prev.filter(id => id !== toolId)
        : prev.length < 4 ? [...prev, toolId] : prev
    );
  };

  const handleClearComparison = () => {
    setSelectedTools([]);
  };

  // Infinite scroll implementation
  const handleScroll = useCallback(() => {
    const scrollPosition = window.innerHeight + document.documentElement.scrollTop;
    const documentHeight = document.documentElement.offsetHeight;
    const threshold = documentHeight - 800;
    
    if (scrollPosition >= threshold && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  return (
    <div className="min-h-screen bg-slate-50">
      <SEO 
        title={filters.search ? `"${filters.search}" AI Tools - Kate's List` : "Kate's List - Discover AI Tools Together"}
        description={filters.search 
          ? `Found ${totalTools} AI tools matching "${filters.search}". Compare features, read reviews, and find the perfect AI solution.`
          : `Join our community of AI enthusiasts. Discover, review, and compare ${totalTools}+ verified AI tools. Find the perfect AI solution for your needs.`
        }
        keywords={['AI tools', 'artificial intelligence', 'AI directory', 'machine learning', 'AI community', 'AI reviews', filters.search].filter(Boolean)}
      />
      <Header onSearch={(search) => handleFilterChange({ search })} />
      
      {/* Hero Section */}
      <section className="gradient-bg py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold text-white mb-4">
            Discover AI, Together
          </h1>
          <p className="text-lg text-white/90 mb-6 max-w-2xl mx-auto">
            {user ? 
              `Welcome back! Explore ${totalTools || 175}+ AI tools reviewed by our community.` :
              `Join our community of AI enthusiasts. Share reviews, discover tools, and connect with ${totalTools || 175}+ verified AI platforms.`
            }
          </p>
          {!user && (
            <Button 
              size="lg" 
              className="bg-white text-primary-600 hover:bg-gray-50"
              onClick={() => setLocation("/auth")}
            >
              Join the Community
            </Button>
          )}
        </div>
      </section>

      {/* Filter Bar */}
      <CategoryFilter 
        filters={filters}
        onFilterChange={handleFilterChange}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex gap-8">
        {/* Community Sidebar */}
        <aside className="w-80 hidden lg:block">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
            <h3 className="font-semibold text-slate-900 mb-4">Recent Community Activity</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-primary">JD</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-600">
                    <span className="font-medium">John D.</span> reviewed <span className="font-medium">ChatGPT</span>
                  </p>
                  <p className="text-xs text-slate-400">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-primary">SM</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-600">
                    <span className="font-medium">Sarah M.</span> added <span className="font-medium">Midjourney</span> to favorites
                  </p>
                  <p className="text-xs text-slate-400">4 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-primary">AL</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-600">
                    <span className="font-medium">Alex L.</span> submitted a new tool review
                  </p>
                  <p className="text-xs text-slate-400">6 hours ago</p>
                </div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full mt-4">
              View All Activity
            </Button>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="font-semibold text-slate-900 mb-4">Top Contributors</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-yellow-600">1</span>
                  </div>
                  <span className="text-sm font-medium">Kate Wilson</span>
                </div>
                <span className="text-xs text-slate-500">47 reviews</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-gray-600">2</span>
                  </div>
                  <span className="text-sm font-medium">Mike Chen</span>
                </div>
                <span className="text-xs text-slate-500">32 reviews</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-orange-600">3</span>
                  </div>
                  <span className="text-sm font-medium">Lisa Park</span>
                </div>
                <span className="text-xs text-slate-500">28 reviews</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">AI Directory</h2>
            <p className="text-slate-600">
              Browse{" "}
              <span className="font-semibold">
                {totalTools || 0}
              </span>{" "}
              AI platforms reviewed and verified by our community members
            </p>
          </div>

          {/* Smart Recommendations Section */}
          {user && (
            <div className="mb-8">
              <SmartRecommendations
                userBehavior={{
                  viewedCategories: [], // This would come from user analytics
                  searchQueries: [],
                  favoriteTools: [],
                  comparedTools: []
                }}
                onToolClick={(tool) => setLocation(`/tool/${tool.id}`)}
              />
            </div>
          )}

          {/* Tools Grid */}
          {toolsLoading ? (
            <div className={viewMode === "grid" 
              ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              : "space-y-4"
            }>
              {Array.from({ length: 8 }).map((_, i) => (
                <ToolCardSkeleton key={i} viewMode={viewMode} />
              ))}
            </div>
          ) : toolsError ? (
            <Card className="p-8 text-center">
              <CardContent className="p-0">
                <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-slate-900 mb-2">
                  Unable to Load AI Tools
                </h3>
                <p className="text-slate-600 mb-4">
                  There was an error loading the AI tools. Please try again.
                </p>
                <Button onClick={() => refetchTools()} className="inline-flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className={viewMode === "grid" 
                ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-6 mb-8"
                : "space-y-4 mb-8"
              }>
                {allTools.map((tool: any) => (
                  <ToolCard 
                    key={tool.id} 
                    tool={tool} 
                    viewMode={viewMode}
                    onToggleComparison={handleToggleTool}
                    isSelected={selectedTools.includes(tool.id)}
                  />
                ))}
              </div>

              {/* Load More Button and Loading Indicator */}
              {hasNextPage && (
                <div className="text-center py-8">
                  {isFetchingNextPage ? (
                    <div className="inline-flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-600 mr-2"></div>
                      Loading more tools...
                    </div>
                  ) : (
                    <Button 
                      onClick={() => fetchNextPage()}
                      variant="outline"
                      size="lg"
                      className="px-8"
                    >
                      Load More Tools
                    </Button>
                  )}
                </div>
              )}

              {/* No Results */}
              {allTools.length === 0 && !toolsLoading && (
                <div className="text-center py-12">
                  <div className="text-slate-400 text-6xl mb-4">
                    <i className="fas fa-search"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">
                    No tools found
                  </h3>
                  <p className="text-slate-600">
                    Try adjusting your search criteria or browse all categories
                  </p>
                  <Button 
                    className="mt-4"
                    onClick={() => handleFilterChange({ search: "", category: "", pricingModel: "" })}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </>
          )}
        </main>

        {/* Sidebar */}
        <Sidebar onFilterChange={handleFilterChange} />
      </div>

      {/* Community Highlights Section */}
      <section className="bg-white py-8 border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-primary mb-2">{toolsData?.total || 175}+</div>
              <div className="text-slate-600">AI Tools Reviewed</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">2.5K+</div>
              <div className="text-slate-600">Community Reviews</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">850+</div>
              <div className="text-slate-600">Active Members</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Tool Section */}
      {!featuredLoading && featuredTool && (
        <FeaturedTool tool={featuredTool} />
      )}

      {/* Tool Comparison Panel */}
      {selectedTools.length > 0 && (
        <ToolComparison
          selectedTools={selectedTools}
          onToggleTool={handleToggleTool}
          onClearComparison={handleClearComparison}
          className="fixed bottom-0 left-0 right-0 z-50"
        />
      )}

      <Footer />
    </div>
  );
}
