import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Scale, Star, ExternalLink, Check, Minus } from "lucide-react";
import { OptimizedImage } from "@/components/ui/optimized-image";

interface Tool {
  id: number;
  name: string;
  description: string;
  logoUrl?: string;
  websiteUrl: string;
  pricingModel: string;
  hasFreeTier: boolean;
  hasApi: boolean;
  features: string[];
  category: string;
  ratings?: {
    overallExperience: number;
    valueForMoney: number;
    qualityOfOutput: number;
    totalRatings: number;
  };
}

interface ToolComparisonProps {
  selectedTools: number[];
  onToggleTool: (toolId: number) => void;
  onClearComparison: () => void;
  className?: string;
}

export default function ToolComparison({
  selectedTools,
  onToggleTool,
  onClearComparison,
  className
}: ToolComparisonProps) {
  const [showComparison, setShowComparison] = useState(false);

  const { data: tools = [] } = useQuery({
    queryKey: ["/api/tools/compare", selectedTools],
    enabled: selectedTools.length > 0,
  });

  const comparisonFeatures = [
    'Free Tier Available',
    'API Access',
    'Team Collaboration',
    'Custom Training',
    'Enterprise Support',
    'Data Export',
    'Third-party Integrations',
    'Mobile App',
  ];

  if (selectedTools.length === 0) return null;

  return (
    <div className={className}>
      {/* Comparison Toggle */}
      <div className="fixed bottom-6 right-6 z-50">
        <Card className="shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Scale className="w-5 h-5 text-primary-600" />
              <span className="font-medium">
                {selectedTools.length} tool{selectedTools.length > 1 ? 's' : ''} selected
              </span>
              <Button
                size="sm"
                onClick={() => setShowComparison(true)}
                disabled={selectedTools.length < 2}
              >
                Compare
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={onClearComparison}
              >
                Clear
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Comparison Modal */}
      {showComparison && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold">Tool Comparison</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowComparison(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="overflow-auto p-6">
              {tools.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr>
                        <th className="text-left p-4 min-w-48">Feature</th>
                        {tools.map((tool: Tool) => (
                          <th key={tool.id} className="text-center p-4 min-w-64">
                            <div className="space-y-3">
                              <OptimizedImage
                                src={tool.logoUrl || '/api/placeholder/64/64'}
                                alt={tool.name}
                                width={64}
                                height={64}
                                className="mx-auto rounded-lg"
                              />
                              <div>
                                <h3 className="font-semibold">{tool.name}</h3>
                                <Badge variant="secondary" className="mt-1">
                                  {tool.category}
                                </Badge>
                              </div>
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>

                    <tbody>
                      {/* Description */}
                      <tr className="border-t">
                        <td className="p-4 font-medium">Description</td>
                        {tools.map((tool: Tool) => (
                          <td key={tool.id} className="p-4 text-sm text-center">
                            {tool.description.slice(0, 100)}...
                          </td>
                        ))}
                      </tr>

                      {/* Pricing */}
                      <tr className="border-t bg-slate-50">
                        <td className="p-4 font-medium">Pricing</td>
                        {tools.map((tool: Tool) => (
                          <td key={tool.id} className="p-4 text-center">
                            <Badge
                              variant={tool.pricingModel === 'free' ? 'secondary' : 'outline'}
                            >
                              {tool.pricingModel}
                            </Badge>
                          </td>
                        ))}
                      </tr>

                      {/* Rating */}
                      <tr className="border-t">
                        <td className="p-4 font-medium">Overall Rating</td>
                        {tools.map((tool: Tool) => (
                          <td key={tool.id} className="p-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <div className="flex">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    className={`w-4 h-4 ${
                                      star <= (tool.ratings?.overallExperience || 0)
                                        ? "fill-yellow-400 text-yellow-400"
                                        : "text-slate-300"
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="text-sm text-slate-600">
                                ({tool.ratings?.totalRatings || 0})
                              </span>
                            </div>
                          </td>
                        ))}
                      </tr>

                      {/* Features Comparison */}
                      {comparisonFeatures.map((feature) => (
                        <tr key={feature} className="border-t">
                          <td className="p-4 font-medium">{feature}</td>
                          {tools.map((tool: Tool) => (
                            <td key={tool.id} className="p-4 text-center">
                              {getFeatureStatus(tool, feature) ? (
                                <Check className="w-5 h-5 text-green-600 mx-auto" />
                              ) : (
                                <Minus className="w-5 h-5 text-slate-400 mx-auto" />
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}

                      {/* Actions */}
                      <tr className="border-t bg-slate-50">
                        <td className="p-4 font-medium">Actions</td>
                        {tools.map((tool: Tool) => (
                          <td key={tool.id} className="p-4 text-center">
                            <div className="space-y-2">
                              <Button
                                size="sm"
                                onClick={() => window.open(tool.websiteUrl, '_blank')}
                                className="w-full"
                              >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Visit Site
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => onToggleTool(tool.id)}
                                className="w-full"
                              >
                                Remove
                              </Button>
                            </div>
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Scale className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">
                    Loading comparison data...
                  </h3>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function getFeatureStatus(tool: Tool, feature: string): boolean {
  switch (feature) {
    case 'Free Tier Available':
      return tool.hasFreeTier;
    case 'API Access':
      return tool.hasApi;
    case 'Team Collaboration':
      return tool.features.some(f => f.toLowerCase().includes('team') || f.toLowerCase().includes('collaboration'));
    case 'Custom Training':
      return tool.features.some(f => f.toLowerCase().includes('custom') || f.toLowerCase().includes('training'));
    case 'Enterprise Support':
      return tool.features.some(f => f.toLowerCase().includes('enterprise') || f.toLowerCase().includes('support'));
    case 'Data Export':
      return tool.features.some(f => f.toLowerCase().includes('export') || f.toLowerCase().includes('download'));
    case 'Third-party Integrations':
      return tool.features.some(f => f.toLowerCase().includes('integration') || f.toLowerCase().includes('api'));
    case 'Mobile App':
      return tool.features.some(f => f.toLowerCase().includes('mobile') || f.toLowerCase().includes('app'));
    default:
      return false;
  }
}