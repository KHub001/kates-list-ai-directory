import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { 
  Users, 
  MessageCircle, 
  Star, 
  Filter, 
  Search, 
  Mail, 
  Calendar,
  CheckCircle,
  AlertTriangle,
  Clock,
  Award
} from "lucide-react";

export default function AdminCommunity() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("members");
  const [memberFilter, setMemberFilter] = useState({ search: "", isActive: "all", limit: 50 });
  const [messageFilter, setMessageFilter] = useState({ 
    search: "", 
    isRead: "all", 
    category: "all", 
    priority: "all", 
    limit: 50 
  });

  // Community Members Query
  const { data: membersData, isLoading: membersLoading } = useQuery({
    queryKey: ["/api/admin/community/members", memberFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      if (memberFilter.search) params.append("search", memberFilter.search);
      if (memberFilter.isActive !== "all") params.append("isActive", memberFilter.isActive);
      params.append("limit", memberFilter.limit.toString());
      return fetch(`/api/admin/community/members?${params}`).then(res => res.json());
    },
  });

  // Messages Query
  const { data: messagesData, isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/admin/messages", messageFilter],
    queryFn: () => {
      const params = new URLSearchParams();
      if (messageFilter.search) params.append("search", messageFilter.search);
      if (messageFilter.isRead !== "all") params.append("isRead", messageFilter.isRead);
      if (messageFilter.category !== "all") params.append("category", messageFilter.category);
      if (messageFilter.priority !== "all") params.append("priority", messageFilter.priority);
      params.append("limit", messageFilter.limit.toString());
      return fetch(`/api/admin/messages?${params}`).then(res => res.json());
    },
  });

  // Community Reviews Query
  const { data: reviewsData, isLoading: reviewsLoading } = useQuery({
    queryKey: ["/api/admin/community-reviews"],
    queryFn: () => fetch("/api/admin/community-reviews").then(res => res.json()),
  });

  // Mark Message as Read Mutation
  const markAsReadMutation = useMutation({
    mutationFn: (messageId: number) => 
      fetch(`/api/admin/messages/${messageId}/read`, { method: "PATCH" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/messages"] });
      toast({
        title: "Message marked as read",
        description: "The message status has been updated.",
      });
    },
  });

  // Approve Review Mutation
  const approveReviewMutation = useMutation({
    mutationFn: (reviewId: number) => 
      fetch(`/api/admin/community-reviews/${reviewId}/approve`, { method: "PATCH" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/community-reviews"] });
      toast({
        title: "Review approved",
        description: "The review has been approved and is now visible.",
      });
    },
  });

  // Verify Review Mutation
  const verifyReviewMutation = useMutation({
    mutationFn: (reviewId: number) => 
      fetch(`/api/admin/community-reviews/${reviewId}/verify`, { method: "PATCH" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/community-reviews"] });
      toast({
        title: "Review verified",
        description: "The review has been marked as verified.",
      });
    },
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "destructive";
      case "high": return "orange";
      case "normal": return "secondary";
      case "low": return "outline";
      default: return "secondary";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Community Administration</h1>
        <p className="text-gray-600">
          Manage community members, messages, and reviews
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Members</p>
                <div className="text-2xl font-bold">
                  {membersData?.total || 0}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <MessageCircle className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Messages</p>
                <div className="text-2xl font-bold">
                  {messagesData?.total || 0}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Star className="h-8 w-8 text-yellow-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Reviews</p>
                <div className="text-2xl font-bold">
                  {reviewsData?.total || 0}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Unread Messages</p>
                <div className="text-2xl font-bold">
                  {messagesData?.messages?.filter((m: any) => !m.isRead).length || 0}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="members">Community Members</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Community Members ({membersData?.total || 0})
              </CardTitle>
              <CardDescription>
                View and manage all community members
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search members by name or email..."
                    value={memberFilter.search}
                    onChange={(e) => setMemberFilter({ ...memberFilter, search: e.target.value })}
                  />
                </div>
                <Select
                  value={memberFilter.isActive}
                  onValueChange={(value) => setMemberFilter({ ...memberFilter, isActive: value })}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Members</SelectItem>
                    <SelectItem value="true">Active</SelectItem>
                    <SelectItem value="false">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Experience</TableHead>
                      <TableHead>Interests</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {membersLoading ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          Loading members...
                        </TableCell>
                      </TableRow>
                    ) : membersData?.members?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">
                          No members found
                        </TableCell>
                      </TableRow>
                    ) : (
                      membersData?.members?.map((member: any) => (
                        <TableRow key={member.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">
                                {member.firstName} {member.lastName}
                              </div>
                              <div className="text-sm text-gray-500">{member.email}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">{member.company || "Not specified"}</div>
                              <div className="text-sm text-gray-500">{member.jobTitle || ""}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {member.experience}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {member.interests?.slice(0, 3).map((interest: string, index: number) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {interest.replace('-', ' ')}
                                </Badge>
                              ))}
                              {member.interests?.length > 3 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{member.interests.length - 3}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {formatDate(member.joinedAt)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={member.isActive ? "default" : "secondary"}>
                              {member.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="messages" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Messages ({messagesData?.total || 0})
              </CardTitle>
              <CardDescription>
                View and manage all community messages
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search messages..."
                    value={messageFilter.search}
                    onChange={(e) => setMessageFilter({ ...messageFilter, search: e.target.value })}
                  />
                </div>
                <Select
                  value={messageFilter.isRead}
                  onValueChange={(value) => setMessageFilter({ ...messageFilter, isRead: value })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="true">Read</SelectItem>
                    <SelectItem value="false">Unread</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={messageFilter.priority}
                  onValueChange={(value) => setMessageFilter({ ...messageFilter, priority: value })}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sender</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {messagesLoading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          Loading messages...
                        </TableCell>
                      </TableRow>
                    ) : messagesData?.messages?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          No messages found
                        </TableCell>
                      </TableRow>
                    ) : (
                      messagesData?.messages?.map((message: any) => (
                        <TableRow key={message.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{message.senderName}</div>
                              <div className="text-sm text-gray-500">{message.senderEmail}</div>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <div className="font-medium truncate">{message.subject}</div>
                            <div className="text-sm text-gray-500 truncate">{message.message}</div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {message.category.replace('-', ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={getPriorityColor(message.priority) as any}>
                              {message.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {formatDate(message.createdAt)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {message.isRead ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <Clock className="h-4 w-4 text-yellow-600" />
                              )}
                              <span className="text-sm">
                                {message.isRead ? "Read" : "Unread"}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {!message.isRead && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => markAsReadMutation.mutate(message.id)}
                                disabled={markAsReadMutation.isPending}
                              >
                                Mark Read
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Community Reviews ({reviewsData?.total || 0})
              </CardTitle>
              <CardDescription>
                Manage and moderate community reviews
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reviewer</TableHead>
                      <TableHead>Tool</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reviewsLoading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          Loading reviews...
                        </TableCell>
                      </TableRow>
                    ) : reviewsData?.reviews?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          No reviews found
                        </TableCell>
                      </TableRow>
                    ) : (
                      reviewsData?.reviews?.map((review: any) => (
                        <TableRow key={review.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{review.reviewerName}</div>
                              <div className="text-sm text-gray-500">{review.reviewerEmail}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">Tool #{review.toolId}</div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span>{review.rating}/5</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <div className="font-medium truncate">{review.title}</div>
                            <div className="text-sm text-gray-500 truncate">{review.content}</div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {formatDate(review.createdAt)}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              <Badge variant={review.isApproved ? "default" : "secondary"}>
                                {review.isApproved ? "Approved" : "Pending"}
                              </Badge>
                              {review.isVerified && (
                                <Badge variant="outline" className="text-xs">
                                  <Award className="h-3 w-3 mr-1" />
                                  Verified
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {!review.isApproved && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => approveReviewMutation.mutate(review.id)}
                                  disabled={approveReviewMutation.isPending}
                                >
                                  Approve
                                </Button>
                              )}
                              {!review.isVerified && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => verifyReviewMutation.mutate(review.id)}
                                  disabled={verifyReviewMutation.isPending}
                                >
                                  Verify
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}