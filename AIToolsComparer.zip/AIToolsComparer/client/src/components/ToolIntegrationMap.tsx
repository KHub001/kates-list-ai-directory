import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Network, GitBranch, Link2, Zap, ArrowRight, Plus, Search, Filter } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface Integration {
  id: number;
  fromToolId: number;
  toToolId: number;
  integrationType: 'api' | 'webhook' | 'export' | 'plugin' | 'native';
  difficultyLevel: 'easy' | 'medium' | 'hard';
  description: string;
  setupTime: string;
  fromTool: any;
  toTool: any;
}

interface WorkflowNode {
  id: string;
  toolId: number;
  tool: any;
  position: { x: number; y: number };
  connections: string[];
}

export default function ToolIntegrationMap() {
  const [selectedTool, setSelectedTool] = useState<any>(null);
  const [workflowNodes, setWorkflowNodes] = useState<WorkflowNode[]>([]);
  const [activeTab, setActiveTab] = useState("discover");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const queryClient = useQueryClient();

  // Fetch all tools for selection
  const { data: toolsData } = useQuery({
    queryKey: ["/api/tools", { limit: 100 }],
  });

  // Fetch integrations for selected tool
  const { data: integrations, isLoading: integrationsLoading } = useQuery({
    queryKey: ["/api/tools/integrations", selectedTool?.id],
    enabled: !!selectedTool?.id,
  });

  // Fetch integration partners
  const { data: integrationPartners } = useQuery({
    queryKey: ["/api/tools/integration-partners", selectedTool?.id],
    enabled: !!selectedTool?.id,
  });

  // Add integration mutation
  const addIntegration = useMutation({
    mutationFn: async (integration: Partial<Integration>) => {
      return apiRequest('/api/tools/integrations', {
        method: 'POST',
        body: integration
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tools/integrations"] });
    }
  });

  const IntegrationTypeIcon = ({ type }: { type: string }) => {
    switch (type) {
      case 'api': return <Network className="h-4 w-4" />;
      case 'webhook': return <Zap className="h-4 w-4" />;
      case 'export': return <ArrowRight className="h-4 w-4" />;
      case 'plugin': return <GitBranch className="h-4 w-4" />;
      case 'native': return <Link2 className="h-4 w-4" />;
      default: return <Network className="h-4 w-4" />;
    }
  };

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'easy': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'hard': return 'text-red-600 bg-red-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  const ToolSelector = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Select a Tool to Explore Integrations
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative">
            <Input
              placeholder="Search for AI tools..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
            {toolsData?.tools?.filter((tool: any) => 
              tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              tool.description.toLowerCase().includes(searchQuery.toLowerCase())
            ).map((tool: any) => (
              <div
                key={tool.id}
                className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                  selectedTool?.id === tool.id 
                    ? "border-primary bg-primary/5" 
                    : "border-slate-200 hover:border-slate-300"
                }`}
                onClick={() => setSelectedTool(tool)}
              >
                <div className="flex items-center space-x-3">
                  {tool.logoUrl ? (
                    <img
                      src={tool.logoUrl}
                      alt={tool.name}
                      className="w-10 h-10 rounded object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                      <Network className="h-5 w-5 text-primary" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-slate-900 truncate">{tool.name}</h3>
                    <p className="text-sm text-slate-600 truncate">{tool.category}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const IntegrationsList = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Available Integrations</h3>
        <div className="flex items-center gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="api">API</SelectItem>
              <SelectItem value="webhook">Webhook</SelectItem>
              <SelectItem value="export">Export</SelectItem>
              <SelectItem value="plugin">Plugin</SelectItem>
              <SelectItem value="native">Native</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {integrationsLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse bg-slate-200 h-24 rounded-lg"></div>
          ))}
        </div>
      ) : integrations && integrations.length > 0 ? (
        <div className="space-y-3">
          {integrations
            .filter((integration: Integration) => 
              filterType === 'all' || integration.integrationType === filterType
            )
            .map((integration: Integration) => (
            <Card key={integration.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="flex items-center space-x-2">
                      {integration.fromTool?.logoUrl && (
                        <img
                          src={integration.fromTool.logoUrl}
                          alt={integration.fromTool.name}
                          className="w-8 h-8 rounded object-cover"
                        />
                      )}
                      <ArrowRight className="h-4 w-4 text-slate-400" />
                      {integration.toTool?.logoUrl && (
                        <img
                          src={integration.toTool.logoUrl}
                          alt={integration.toTool.name}
                          className="w-8 h-8 rounded object-cover"
                        />
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-medium">
                          {integration.fromTool?.name} → {integration.toTool?.name}
                        </h4>
                        <Badge 
                          variant="outline" 
                          className="flex items-center gap-1"
                        >
                          <IntegrationTypeIcon type={integration.integrationType} />
                          {integration.integrationType.toUpperCase()}
                        </Badge>
                        <Badge 
                          variant="outline"
                          className={getDifficultyColor(integration.difficultyLevel)}
                        >
                          {integration.difficultyLevel}
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-slate-600 mb-2">
                        {integration.description}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-slate-500">
                        <span>Setup time: {integration.setupTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <Button size="sm" variant="outline">
                    View Guide
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-8">
            <Network className="h-12 w-12 mx-auto mb-4 text-slate-300" />
            <h3 className="font-medium mb-2">No integrations found</h3>
            <p className="text-sm text-slate-600 mb-4">
              This tool doesn't have documented integrations yet
            </p>
            <Button size="sm" variant="outline">
              Suggest Integration
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const WorkflowBuilder = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Build Your Workflow</h3>
        <Button size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Tool
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="min-h-96 border-2 border-dashed border-slate-200 rounded-lg flex items-center justify-center">
            {workflowNodes.length === 0 ? (
              <div className="text-center">
                <GitBranch className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                <h3 className="font-medium mb-2">Start Building Your Workflow</h3>
                <p className="text-sm text-slate-600 mb-4">
                  Drag and drop tools to create an integrated workflow
                </p>
                <Button>Add Your First Tool</Button>
              </div>
            ) : (
              <div className="w-full h-full">
                {/* Workflow visualization would go here */}
                <p className="text-center text-slate-600">Workflow visualization coming soon</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const IntegrationPartners = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Integration Partners</h3>
      
      {integrationPartners && integrationPartners.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {integrationPartners.map((partner: any) => (
            <Card key={partner.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3 mb-3">
                  {partner.logoUrl && (
                    <img
                      src={partner.logoUrl}
                      alt={partner.name}
                      className="w-10 h-10 rounded object-cover"
                    />
                  )}
                  <div>
                    <h4 className="font-medium">{partner.name}</h4>
                    <Badge variant="secondary" className="text-xs">
                      {partner.category}
                    </Badge>
                  </div>
                </div>
                
                <p className="text-sm text-slate-600 mb-3 line-clamp-2">
                  {partner.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {partner.hasApi && (
                      <Badge variant="outline" className="text-xs">API</Badge>
                    )}
                    {partner.hasFreeVersion && (
                      <Badge variant="outline" className="text-xs">Free</Badge>
                    )}
                  </div>
                  <Button size="sm" variant="outline">
                    Connect
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-8">
            <Link2 className="h-12 w-12 mx-auto mb-4 text-slate-300" />
            <h3 className="font-medium mb-2">No integration partners found</h3>
            <p className="text-sm text-slate-600">
              Select a tool to discover its integration ecosystem
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Tool Integration Map</h1>
        <p className="text-slate-600">
          Discover how AI tools connect and build powerful workflows
        </p>
      </div>

      {!selectedTool ? (
        <ToolSelector />
      ) : (
        <div className="space-y-6">
          {/* Selected Tool Header */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {selectedTool.logoUrl && (
                    <img
                      src={selectedTool.logoUrl}
                      alt={selectedTool.name}
                      className="w-12 h-12 rounded object-cover"
                    />
                  )}
                  <div>
                    <h2 className="text-xl font-semibold">{selectedTool.name}</h2>
                    <p className="text-slate-600">{selectedTool.description}</p>
                  </div>
                </div>
                <Button variant="outline" onClick={() => setSelectedTool(null)}>
                  Change Tool
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Integration Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="discover">Discover</TabsTrigger>
              <TabsTrigger value="partners">Partners</TabsTrigger>
              <TabsTrigger value="workflow">Build Workflow</TabsTrigger>
            </TabsList>

            <TabsContent value="discover" className="space-y-6">
              <IntegrationsList />
            </TabsContent>

            <TabsContent value="partners" className="space-y-6">
              <IntegrationPartners />
            </TabsContent>

            <TabsContent value="workflow" className="space-y-6">
              <WorkflowBuilder />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
}