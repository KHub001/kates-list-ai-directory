import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  Network, 
  ArrowRight, 
  CheckCircle, 
  ExternalLink,
  Zap,
  GitBranch,
  Layers,
  Settings
} from "lucide-react";

interface ToolIntegration {
  id: number;
  toolId: number;
  integratesWith: number;
  integrationType: string;
  description: string;
  isVerified: boolean;
  setupComplexity: string;
  documentationUrl?: string;
  createdAt: string;
}

interface AiTool {
  id: number;
  name: string;
  description: string;
  category: string;
  logoUrl?: string;
  websiteUrl: string;
}

interface ToolIntegrationsProps {
  toolId: number;
  className?: string;
}

export default function ToolIntegrations({ toolId, className = "" }: ToolIntegrationsProps) {
  const [activeTab, setActiveTab] = useState("integrations");

  const { data: integrations, isLoading: integrationsLoading } = useQuery({
    queryKey: ["/api/tools", toolId, "integrations"],
    staleTime: 5 * 60 * 1000,
  });

  const { data: partners, isLoading: partnersLoading } = useQuery({
    queryKey: ["/api/tools", toolId, "partners"],
    staleTime: 5 * 60 * 1000,
  });

  const getIntegrationTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'api': return 'bg-blue-100 text-blue-700';
      case 'webhook': return 'bg-green-100 text-green-700';
      case 'plugin': return 'bg-purple-100 text-purple-700';
      case 'workflow': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity.toLowerCase()) {
      case 'simple': return 'bg-green-100 text-green-700';
      case 'moderate': return 'bg-yellow-100 text-yellow-700';
      case 'complex': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (integrationsLoading || partnersLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Network className="h-5 w-5 text-blue-600" />
            <CardTitle>Tool Integrations</CardTitle>
          </div>
          <CardDescription>
            See how this tool connects with others
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <div className="flex space-x-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-20" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasIntegrations = integrations?.integrations?.length > 0;
  const hasPartners = partners?.partners?.length > 0;

  if (!hasIntegrations && !hasPartners) {
    return (
      <Card className={className}>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Network className="h-5 w-5 text-blue-600" />
            <CardTitle>Tool Integrations</CardTitle>
          </div>
          <CardDescription>
            Integration possibilities for this tool
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <GitBranch className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">
              No integrations available yet for this tool
            </p>
            <p className="text-sm text-gray-500">
              Check back later or explore the tool's documentation for integration options
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Network className="h-5 w-5 text-blue-600" />
            <CardTitle>Tool Integrations</CardTitle>
          </div>
          <Badge variant="secondary">
            {(integrations?.integrations?.length || 0) + (partners?.partners?.length || 0)} connections
          </Badge>
        </div>
        <CardDescription>
          Explore how this tool connects and works with other platforms
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="integrations">
              <Layers className="h-4 w-4 mr-2" />
              Integrations ({integrations?.integrations?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="partners">
              <Zap className="h-4 w-4 mr-2" />
              Partners ({partners?.partners?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="integrations" className="space-y-4 mt-6">
            {integrations?.integrations?.map((integration: ToolIntegration) => (
              <div 
                key={integration.id}
                className="border rounded-lg p-4 hover:shadow-sm transition-shadow"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                      <Settings className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">
                        {integration.integrationType.toUpperCase()} Integration
                      </h4>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge 
                          variant="secondary" 
                          className={getIntegrationTypeColor(integration.integrationType)}
                        >
                          {integration.integrationType}
                        </Badge>
                        <Badge 
                          variant="secondary"
                          className={getComplexityColor(integration.setupComplexity)}
                        >
                          {integration.setupComplexity} setup
                        </Badge>
                        {integration.isVerified && (
                          <Badge variant="secondary" className="bg-green-100 text-green-700">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Verified
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mb-3">
                  {integration.description}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    Added {new Date(integration.createdAt).toLocaleDateString()}
                  </span>
                  {integration.documentationUrl && (
                    <a 
                      href={integration.documentationUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                    >
                      View Docs
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  )}
                </div>
              </div>
            ))}

            {!hasIntegrations && (
              <div className="text-center py-6">
                <Settings className="h-8 w-8 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600">No direct integrations available</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="partners" className="space-y-4 mt-6">
            {partners?.partners?.map((partner: AiTool) => (
              <div 
                key={partner.id}
                className="border rounded-lg p-4 hover:shadow-sm transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    {partner.logoUrl ? (
                      <img 
                        src={partner.logoUrl} 
                        alt={`${partner.name} logo`}
                        className="w-10 h-10 rounded object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center text-white font-bold">
                        {partner.name.charAt(0)}
                      </div>
                    )}
                    <div>
                      <h4 className="font-medium">{partner.name}</h4>
                      <Badge variant="outline" className="text-xs">
                        {partner.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <a 
                      href={partner.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                    <Link to={`/tool/${partner.id}`}>
                      <Button size="sm" variant="outline">
                        View Tool
                        <ArrowRight className="ml-1 h-3 w-3" />
                      </Button>
                    </Link>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mt-2 ml-13">
                  {partner.description}
                </p>
              </div>
            ))}

            {!hasPartners && (
              <div className="text-center py-6">
                <Zap className="h-8 w-8 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600">No integration partners found</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {(hasIntegrations || hasPartners) && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-center space-x-2 text-sm text-blue-700">
              <Network className="h-4 w-4" />
              <span className="font-medium">Integration Ecosystem</span>
            </div>
            <p className="text-xs text-blue-600 mt-1">
              These connections help you build more powerful workflows by combining different AI tools.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}