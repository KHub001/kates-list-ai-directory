import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, Users, Eye, Search, Star, Calendar, Download, Filter } from "lucide-react";

interface AnalyticsDashboardProps {
  isAdmin?: boolean;
}

export default function AnalyticsDashboard({ isAdmin = false }: AnalyticsDashboardProps) {
  const [timeRange, setTimeRange] = useState("7d");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Fetch analytics data
  const { data: analyticsOverview } = useQuery({
    queryKey: ["/api/analytics/overview", timeRange],
  });

  const { data: toolViewsData } = useQuery({
    queryKey: ["/api/analytics/tool-views", timeRange],
  });

  const { data: searchAnalytics } = useQuery({
    queryKey: ["/api/analytics/search-queries", timeRange],
  });

  const { data: userBehavior } = useQuery({
    queryKey: ["/api/analytics/user-behavior", timeRange],
  });

  const { data: topTools } = useQuery({
    queryKey: ["/api/analytics/top-tools", timeRange],
  });

  const colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];

  const MetricCard = ({ 
    title, 
    value, 
    change, 
    icon: Icon, 
    trend 
  }: {
    title: string;
    value: string | number;
    change?: string;
    icon: any;
    trend?: "up" | "down" | "neutral";
  }) => (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-2xl font-bold text-slate-900">{value}</p>
            {change && (
              <p className={`text-sm flex items-center gap-1 mt-1 ${
                trend === "up" ? "text-green-600" : 
                trend === "down" ? "text-red-600" : "text-slate-600"
              }`}>
                {trend === "up" && <TrendingUp className="h-3 w-3" />}
                {change}
              </p>
            )}
          </div>
          <div className="p-3 bg-primary/10 rounded-lg">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            {isAdmin ? "Platform Analytics" : "Your Analytics"}
          </h1>
          <p className="text-slate-600">
            {isAdmin 
              ? "Comprehensive insights into platform usage and performance"
              : "Track your AI tool discovery journey and preferences"
            }
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1d">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 3 months</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Views"
          value={analyticsOverview?.totalViews?.toLocaleString() || "0"}
          change="+12% from last period"
          icon={Eye}
          trend="up"
        />
        <MetricCard
          title="Unique Users"
          value={analyticsOverview?.uniqueUsers?.toLocaleString() || "0"}
          change="+8% from last period"
          icon={Users}
          trend="up"
        />
        <MetricCard
          title="Search Queries"
          value={analyticsOverview?.searchQueries?.toLocaleString() || "0"}
          change="+15% from last period"
          icon={Search}
          trend="up"
        />
        <MetricCard
          title="Avg. Rating"
          value={analyticsOverview?.averageRating?.toFixed(1) || "0.0"}
          change="+0.2 from last period"
          icon={Star}
          trend="up"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tool Views Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Tool Views Over Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={toolViewsData?.chartData || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="views" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ fill: "#3b82f6" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Category Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analyticsOverview?.categoryDistribution || []}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {(analyticsOverview?.categoryDistribution || []).map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Search Queries */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Top Search Queries
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(searchAnalytics?.topQueries || []).map((query: any, index: number) => (
                <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div>
                    <p className="font-medium text-slate-900">{query.query}</p>
                    <p className="text-sm text-slate-600">{query.count} searches</p>
                  </div>
                  <Badge variant="secondary">{query.category || "All"}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* User Engagement */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              User Engagement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={userBehavior?.engagementData || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="metric" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Tools */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="h-5 w-5" />
            Top Performing Tools
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-medium text-slate-900">Tool</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-900">Category</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-900">Views</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-900">Rating</th>
                  <th className="text-left py-3 px-4 font-medium text-slate-900">Growth</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {(topTools?.tools || []).map((tool: any, index: number) => (
                  <tr key={tool.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-3">
                        <span className="text-sm text-slate-500">#{index + 1}</span>
                        {tool.logoUrl && (
                          <img
                            src={tool.logoUrl}
                            alt={tool.name}
                            className="w-8 h-8 rounded object-cover"
                          />
                        )}
                        <div>
                          <p className="font-medium text-slate-900">{tool.name}</p>
                          <p className="text-sm text-slate-600 truncate max-w-48">
                            {tool.description}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="secondary">{tool.category}</Badge>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium">{tool.views?.toLocaleString() || "0"}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span className="font-medium">
                          {tool.averageRating?.toFixed(1) || "0.0"}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`font-medium ${
                        tool.growth > 0 ? "text-green-600" : 
                        tool.growth < 0 ? "text-red-600" : "text-slate-600"
                      }`}>
                        {tool.growth > 0 ? "+" : ""}{tool.growth?.toFixed(1) || "0"}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {(analyticsOverview?.recentActivity || []).map((activity: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">{activity.action}</p>
                    <p className="text-xs text-slate-600">{activity.details}</p>
                  </div>
                </div>
                <span className="text-xs text-slate-500">{activity.timestamp}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}