import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  loading?: 'lazy' | 'eager';
  quality?: number;
  onLoad?: () => void;
  onError?: () => void;
}

export function OptimizedImage({
  src,
  alt,
  width,
  height,
  className,
  loading = 'lazy',
  quality = 75,
  onLoad,
  onError,
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const imgRef = useRef<HTMLImageElement>(null);

  // Generate optimized image URL with quality and size parameters
  const getOptimizedSrc = (originalSrc: string) => {
    if (!originalSrc) return '';
    
    // For external URLs, return as-is
    if (originalSrc.startsWith('http')) {
      return originalSrc;
    }
    
    // For local images, add optimization parameters
    const url = new URL(originalSrc, window.location.origin);
    if (quality !== 75) url.searchParams.set('q', quality.toString());
    if (width) url.searchParams.set('w', width.toString());
    if (height) url.searchParams.set('h', height.toString());
    
    return url.toString();
  };

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    onError?.();
  };

  // Intersection Observer for lazy loading
  useEffect(() => {
    if (loading === 'eager' || !imgRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          const actualSrc = img.dataset.src;
          if (actualSrc) {
            img.src = actualSrc;
            observer.unobserve(img);
          }
        }
      },
      { rootMargin: '50px' }
    );

    observer.observe(imgRef.current);

    return () => observer.disconnect();
  }, [loading]);

  if (hasError) {
    return (
      <div 
        className={cn(
          'bg-slate-100 flex items-center justify-center text-slate-400',
          className
        )}
        style={{ width, height }}
      >
        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
        </svg>
      </div>
    );
  }

  return (
    <div className="relative">
      {!isLoaded && (
        <div 
          className={cn(
            'absolute inset-0 bg-slate-100 animate-pulse',
            className
          )}
          style={{ width, height }}
        />
      )}
      <img
        ref={imgRef}
        src={loading === 'eager' ? getOptimizedSrc(src) : undefined}
        data-src={loading === 'lazy' ? getOptimizedSrc(src) : undefined}
        alt={alt}
        width={width}
        height={height}
        className={cn(
          'transition-opacity duration-300',
          isLoaded ? 'opacity-100' : 'opacity-0',
          className
        )}
        onLoad={handleLoad}
        onError={handleError}
        loading={loading}
      />
    </div>
  );
}