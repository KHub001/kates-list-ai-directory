import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Enums
export const pricingModelEnum = pgEnum("pricing_model", [
  "free",
  "freemium", 
  "paid",
  "enterprise"
]);

export const categoryEnum = pgEnum("category", [
  "text-generation",
  "image-generation", 
  "code-assistance",
  "video-creation",
  "audio-processing",
  "chatbots",
  "data-analysis",
  "design-creative",
  "productivity",
  "research-academic",
  "developer-tools",
  "marketing-content",
  "translation",
  "voice-speech",
  "computer-vision",
  "machine-learning",
  "no-code",
  "writing-assistants",
  "education",
  "healthcare",
  "finance",
  "social-media",
  "e-commerce",
  "gaming",
  "cybersecurity",
  "automation",
  "workflow-management",
  "customer-service",
  "sales-crm",
  "seo-optimization",
  "email-marketing",
  "presentation",
  "music-generation",
  "3d-modeling",
  "legal-tech",
  "hr-recruitment",
  "real-estate",
  "agriculture",
  "fitness-health",
  "travel-planning",
  "personal-assistant",
  "note-taking",
  "project-management",
  "collaboration",
  "document-processing",
  "transcription",
  "lead-generation",
  "content-moderation",
  "image-editing",
  "video-editing",
  "animation",
  "predictive-analytics",
  "recommendation-systems"
]);

// AI Tools table
export const aiTools = pgTable("ai_tools", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  websiteUrl: varchar("website_url", { length: 500 }).notNull(),
  logoUrl: varchar("logo_url", { length: 500 }),
  category: categoryEnum("category").notNull(),
  pricingModel: pricingModelEnum("pricing_model").notNull(),
  country: varchar("country", { length: 100 }),
  launchDate: timestamp("launch_date"),
  hasApi: boolean("has_api").default(false),
  hasFreeVersion: boolean("has_free_version").default(false),
  features: text("features").array(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Ratings table - Simplified to 3 categories
export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  toolId: integer("tool_id").notNull().references(() => aiTools.id),
  overallExperience: integer("overall_experience").notNull(), // 1-5
  valueForMoney: integer("value_for_money").notNull(), // 1-5
  qualityOfOutput: integer("quality_of_output").notNull(), // 1-5
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reviews table - No title field, direct content only
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  toolId: integer("tool_id").notNull().references(() => aiTools.id),
  content: text("content").notNull(),
  helpfulCount: integer("helpful_count").default(0),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Favorites table
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  toolId: integer("tool_id").notNull().references(() => aiTools.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Review helpfulness votes
export const reviewHelpfulness = pgTable("review_helpfulness", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  reviewId: integer("review_id").notNull().references(() => reviews.id),
  isHelpful: boolean("is_helpful").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Newsletter subscriptions
export const newsletterSubscriptions = pgTable("newsletter_subscriptions", {
  id: serial("id").primaryKey(),
  email: varchar("email").notNull().unique(),
  status: varchar("status").notNull().default("active"), // active, unsubscribed
  source: varchar("source").default("website"), // website, landing, community, etc.
  subscribedAt: timestamp("subscribed_at").defaultNow(),
  unsubscribedAt: timestamp("unsubscribed_at"),
});

// Community members table for user registration
export const communityMembers = pgTable("community_members", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  company: varchar("company", { length: 200 }),
  jobTitle: varchar("job_title", { length: 200 }),
  interests: text("interests").array(), // AI categories they're interested in
  experience: varchar("experience", { length: 50 }), // beginner, intermediate, expert
  joinedAt: timestamp("joined_at").defaultNow(),
  isActive: boolean("is_active").default(true),
  bio: text("bio"), // optional bio
  linkedinUrl: varchar("linkedin_url", { length: 500 }),
  twitterUrl: varchar("twitter_url", { length: 500 }),
});

// Messages/contact system for users to message admin
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderEmail: varchar("sender_email", { length: 255 }).notNull(),
  senderName: varchar("sender_name", { length: 200 }).notNull(),
  subject: varchar("subject", { length: 500 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false),
  isReplied: boolean("is_replied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  priority: varchar("priority", { length: 20 }).default("normal"), // low, normal, high, urgent
  category: varchar("category", { length: 100 }).default("general"), // general, feature-request, bug-report, partnership
});

// Enhanced reviews with community member details
export const communityReviews = pgTable("community_reviews", {
  id: serial("id").primaryKey(),
  toolId: integer("tool_id").references(() => aiTools.id).notNull(),
  reviewerEmail: varchar("reviewer_email", { length: 255 }).notNull(),
  reviewerName: varchar("reviewer_name", { length: 200 }).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(), // 1-5 stars
  useCases: text("use_cases").array(), // what they used the tool for
  pros: text("pros").array(), // positive aspects
  cons: text("cons").array(), // negative aspects
  recommendedFor: text("recommended_for"), // who should use this tool
  isVerified: boolean("is_verified").default(false), // admin can verify reviews
  isApproved: boolean("is_approved").default(true),
  helpfulCount: integer("helpful_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Analytics tables
export const toolViews = pgTable("tool_views", {
  id: serial("id").primaryKey(),
  toolId: integer("tool_id").references(() => aiTools.id).notNull(),
  userSessionId: varchar("user_session_id"),
  userAgent: text("user_agent"),
  referrer: text("referrer"),
  viewedAt: timestamp("viewed_at").defaultNow(),
});

export const searchQueries = pgTable("search_queries", {
  id: serial("id").primaryKey(),
  query: varchar("query").notNull(),
  category: varchar("category"),
  resultsCount: integer("results_count"),
  userSessionId: varchar("user_session_id"),
  searchedAt: timestamp("searched_at").defaultNow(),
});

export const userSessions = pgTable("user_sessions", {
  id: varchar("id").primaryKey(),
  firstVisit: timestamp("first_visit").defaultNow(),
  lastVisit: timestamp("last_visit").defaultNow(),
  totalViews: integer("total_views").default(1),
  referrer: text("referrer"),
  userAgent: text("user_agent"),
});

// Tool integrations mapping
export const toolIntegrations = pgTable("tool_integrations", {
  id: serial("id").primaryKey(),
  toolId: integer("tool_id").references(() => aiTools.id).notNull(),
  integratesWith: integer("integrates_with").references(() => aiTools.id).notNull(),
  integrationType: varchar("integration_type").notNull(), // "api", "zapier", "direct", "webhook"
  integrationName: varchar("integration_name").notNull(),
  description: text("description"),
  isVerified: boolean("is_verified").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// User preferences for recommendations
export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userSessionId: varchar("user_session_id").notNull(),
  preferredCategories: text("preferred_categories").array(),
  preferredPricingModels: text("preferred_pricing_models").array(),
  viewedTools: integer("viewed_tools").array(),
  favoriteTools: integer("favorite_tools").array(),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  ratings: many(ratings),
  reviews: many(reviews),
  favorites: many(favorites),
  reviewHelpfulness: many(reviewHelpfulness),
}));

export const aiToolsRelations = relations(aiTools, ({ many }) => ({
  ratings: many(ratings),
  reviews: many(reviews),
  favorites: many(favorites),
}));

export const ratingsRelations = relations(ratings, ({ one }) => ({
  user: one(users, {
    fields: [ratings.userId],
    references: [users.id],
  }),
  tool: one(aiTools, {
    fields: [ratings.toolId],
    references: [aiTools.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one, many }) => ({
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
  tool: one(aiTools, {
    fields: [reviews.toolId],
    references: [aiTools.id],
  }),
  helpfulness: many(reviewHelpfulness),
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, {
    fields: [favorites.userId],
    references: [users.id],
  }),
  tool: one(aiTools, {
    fields: [favorites.toolId],
    references: [aiTools.id],
  }),
}));

export const reviewHelpfulnessRelations = relations(reviewHelpfulness, ({ one }) => ({
  user: one(users, {
    fields: [reviewHelpfulness.userId],
    references: [users.id],
  }),
  review: one(reviews, {
    fields: [reviewHelpfulness.reviewId],
    references: [reviews.id],
  }),
}));

// Schema types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertAiTool = typeof aiTools.$inferInsert;
export type AiTool = typeof aiTools.$inferSelect;

export type InsertRating = typeof ratings.$inferInsert;
export type Rating = typeof ratings.$inferSelect;

export type InsertReview = typeof reviews.$inferInsert;
export type Review = typeof reviews.$inferSelect;

export type InsertFavorite = typeof favorites.$inferInsert;
export type Favorite = typeof favorites.$inferSelect;

export type InsertReviewHelpfulness = typeof reviewHelpfulness.$inferInsert;
export type ReviewHelpfulness = typeof reviewHelpfulness.$inferSelect;

export type InsertNewsletterSubscription = typeof newsletterSubscriptions.$inferInsert;
export type NewsletterSubscription = typeof newsletterSubscriptions.$inferSelect;

export type InsertCommunityMember = typeof communityMembers.$inferInsert;
export type CommunityMember = typeof communityMembers.$inferSelect;

export type InsertMessage = typeof messages.$inferInsert;
export type Message = typeof messages.$inferSelect;

export type InsertCommunityReview = typeof communityReviews.$inferInsert;
export type CommunityReview = typeof communityReviews.$inferSelect;

// Zod schemas
export const insertAiToolSchema = createInsertSchema(aiTools).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  helpfulCount: true,
  isVerified: true,
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

export const insertCommunityMemberSchema = createInsertSchema(communityMembers).omit({
  id: true,
  joinedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  isRead: true,
  isReplied: true,
});

export const insertCommunityReviewSchema = createInsertSchema(communityReviews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  helpfulCount: true,
  isVerified: true,
  isApproved: true,
});

// Analytics type definitions
export type InsertToolView = typeof toolViews.$inferInsert;
export type ToolView = typeof toolViews.$inferSelect;

export type InsertSearchQuery = typeof searchQueries.$inferInsert;
export type SearchQuery = typeof searchQueries.$inferSelect;

export type InsertUserSession = typeof userSessions.$inferInsert;
export type UserSession = typeof userSessions.$inferSelect;

export type InsertToolIntegration = typeof toolIntegrations.$inferInsert;
export type ToolIntegration = typeof toolIntegrations.$inferSelect;

export type InsertUserPreference = typeof userPreferences.$inferInsert;
export type UserPreference = typeof userPreferences.$inferSelect;
