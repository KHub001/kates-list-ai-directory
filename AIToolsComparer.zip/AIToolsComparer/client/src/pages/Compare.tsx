import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import StarRating from "@/components/StarRating";
import { Search, Plus, X, Filter, TrendingUp, Zap } from "lucide-react";

export default function Compare() {
  const [selectedTools, setSelectedTools] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedPricing, setSelectedPricing] = useState("all");
  const [hasApiFilter, setHasApiFilter] = useState(false);
  const [hasFreeFilter, setHasFreeFilter] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [comparisonMode, setComparisonMode] = useState<"basic" | "detailed">("basic");

  const { data: toolsData } = useQuery({
    queryKey: ["/api/tools", { 
      search: searchQuery, 
      category: selectedCategory !== "all" ? selectedCategory : undefined,
      pricingModel: selectedPricing !== "all" ? selectedPricing : undefined,
      hasApi: hasApiFilter ? "true" : undefined,
      hasFreeVersion: hasFreeFilter ? "true" : undefined,
      limit: 50 
    }],
  });

  const { data: categoriesData } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Filter tools based on local filters (for additional client-side filtering)
  const filteredTools = toolsData?.tools?.filter((tool: any) => {
    if (hasApiFilter && !tool.hasApi) return false;
    if (hasFreeFilter && !tool.hasFreeVersion) return false;
    return true;
  }) || [];

  const addToolToComparison = (tool: any) => {
    if (selectedTools.length < 4 && !selectedTools.find(t => t.id === tool.id)) {
      setSelectedTools([...selectedTools, tool]);
    }
  };

  const removeToolFromComparison = (toolId: number) => {
    setSelectedTools(selectedTools.filter(t => t.id !== toolId));
  };

  const categoryDisplayNames: { [key: string]: string } = {
    "text-generation": "Text Generation",
    "image-generation": "Image Generation",
    "code-assistance": "Code Assistance",
    "video-creation": "Video Creation",
    "audio-processing": "Audio Processing",
    "chatbots": "Chatbots",
    "data-analysis": "Data Analysis",
    "design-creative": "Design & Creative",
    "productivity": "Productivity",
    "research-academic": "Research & Academic",
    "developer-tools": "Developer Tools",
    "marketing-content": "Marketing & Content",
    "translation": "Translation",
    "voice-speech": "Voice & Speech",
    "computer-vision": "Computer Vision",
    "machine-learning": "Machine Learning",
    "no-code": "No-Code",
    "writing-assistants": "Writing Assistants",
    "education": "Education",
    "healthcare": "Healthcare",
    "finance": "Finance",
  };

  const pricingDisplayNames: { [key: string]: string } = {
    "free": "Free",
    "freemium": "Freemium",
    "paid": "Paid",
    "enterprise": "Enterprise",
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Compare AI Tools</h1>
          <p className="text-slate-600 mb-6">
            Compare up to 4 AI tools side by side to find the perfect solution for your needs.
          </p>
          
          {/* Search and Filter Controls */}
          <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative max-w-md">
                <Input
                  type="text"
                  placeholder="Search tools to compare..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
                <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              </div>
              
              <Button 
                variant="outline" 
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                Filters
              </Button>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-600">View:</span>
              <Select value={comparisonMode} onValueChange={(value: "basic" | "detailed") => setComparisonMode(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic</SelectItem>
                  <SelectItem value="detailed">Detailed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <Card className="mt-4">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium text-slate-700 mb-2 block">Category</label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="All categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {categoriesData?.map((category: any) => (
                          <SelectItem key={category.category} value={category.category}>
                            {categoryDisplayNames[category.category] || category.category} ({category.count})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-700 mb-2 block">Pricing Model</label>
                    <Select value={selectedPricing} onValueChange={setSelectedPricing}>
                      <SelectTrigger>
                        <SelectValue placeholder="All pricing" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Pricing</SelectItem>
                        <SelectItem value="free">Free</SelectItem>
                        <SelectItem value="freemium">Freemium</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="enterprise">Enterprise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-700 block">Features</label>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="hasApi"
                        checked={hasApiFilter}
                        onCheckedChange={setHasApiFilter}
                      />
                      <label htmlFor="hasApi" className="text-sm text-slate-600">Has API</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="hasFree"
                        checked={hasFreeFilter}
                        onCheckedChange={setHasFreeFilter}
                      />
                      <label htmlFor="hasFree" className="text-sm text-slate-600">Free Version</label>
                    </div>
                  </div>
                  
                  <div className="flex items-end">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setSelectedCategory("all");
                        setSelectedPricing("all");
                        setHasApiFilter(false);
                        setHasFreeFilter(false);
                        setSearchQuery("");
                      }}
                      className="w-full"
                    >
                      Clear All
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Comparison Table */}
        {selectedTools.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Tool Comparison ({selectedTools.length}/4)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Tool</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4 min-w-64">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center space-x-3">
                              {tool.logoUrl && (
                                <img
                                  src={tool.logoUrl}
                                  alt={tool.name}
                                  className="w-8 h-8 rounded object-cover"
                                />
                              )}
                              <div>
                                <h3 className="font-semibold text-slate-900">{tool.name}</h3>
                                <Badge variant="secondary" className="text-xs">
                                  {categoryDisplayNames[tool.category] || tool.category}
                                </Badge>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeToolFromComparison(tool.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Description</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4 text-sm text-slate-600">
                          {tool.description.length > 150 
                            ? `${tool.description.substring(0, 150)}...` 
                            : tool.description}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Pricing</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4">
                          <Badge variant="outline">
                            {pricingDisplayNames[tool.pricingModel] || tool.pricingModel}
                          </Badge>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Rating</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4">
                          <div className="flex items-center space-x-2">
                            <StarRating rating={tool.ratings?.overall || 0} readonly size="sm" />
                            <span className="text-sm text-slate-600">
                              {tool.ratings?.overall ? tool.ratings.overall.toFixed(1) : "0.0"}
                            </span>
                          </div>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">API Available</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4">
                          <span className={tool.hasApi ? "text-green-600" : "text-slate-400"}>
                            {tool.hasApi ? "Yes" : "No"}
                          </span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Free Version</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4">
                          <span className={tool.hasFreeVersion ? "text-green-600" : "text-slate-400"}>
                            {tool.hasFreeVersion ? "Yes" : "No"}
                          </span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Country</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4 text-sm text-slate-600">
                          {tool.country || "Not specified"}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-4 font-medium text-slate-900">Actions</td>
                      {selectedTools.map((tool) => (
                        <td key={tool.id} className="p-4">
                          <div className="space-y-2">
                            <Button size="sm" className="w-full" asChild>
                              <a href={tool.websiteUrl} target="_blank" rel="noopener noreferrer">
                                Visit Website
                              </a>
                            </Button>
                            <Button size="sm" variant="outline" className="w-full" asChild>
                              <a href={`/tool/${tool.id}`}>
                                View Details
                              </a>
                            </Button>
                          </div>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tool Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Select Tools to Compare</CardTitle>
            <p className="text-slate-600">Choose up to 4 tools to compare side by side</p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {toolsData?.tools?.map((tool: any) => (
                <div
                  key={tool.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedTools.find(t => t.id === tool.id)
                      ? "border-primary bg-primary/5"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                  onClick={() => addToolToComparison(tool)}
                >
                  <div className="flex items-center space-x-3 mb-3">
                    {tool.logoUrl ? (
                      <img
                        src={tool.logoUrl}
                        alt={tool.name}
                        className="w-10 h-10 rounded object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                        <i className="fas fa-robot text-primary text-sm"></i>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-slate-900 truncate">{tool.name}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {categoryDisplayNames[tool.category] || tool.category}
                      </Badge>
                    </div>
                    {selectedTools.find(t => t.id === tool.id) ? (
                      <div className="text-primary">
                        <i className="fas fa-check text-sm"></i>
                      </div>
                    ) : selectedTools.length < 4 ? (
                      <Plus className="h-4 w-4 text-slate-400" />
                    ) : (
                      <div className="text-slate-300">
                        <i className="fas fa-ban text-sm"></i>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2">{tool.description}</p>
                </div>
              ))}
            </div>
            
            {(!toolsData?.tools || toolsData.tools.length === 0) && (
              <div className="text-center py-8 text-slate-600">
                <p>No tools found. Try adjusting your search query.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}