import express, { type Request, Response, NextFunction } from "express";
import { createServer } from "http";
import path from "path";
import fs from "fs";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Global error handler
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  console.error('Server error:', {
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method
  });
  res.status(500).json({ error: 'Internal Server Error' });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'production'
  });
});

// Initialize storage with error handling
let storage: any = null;

async function initStorage() {
  try {
    if (process.env.DATABASE_URL) {
      const storageModule = await import("./storage");
      storage = storageModule.storage;
      console.log("Database storage initialized");
      return true;
    }
    console.log("No database URL, using fallback data");
    return false;
  } catch (error) {
    console.error("Storage initialization failed:", error);
    return false;
  }
}

// API endpoints
app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', async (req, res) => {
  try {
    if (storage) {
      const categories = await storage.getCategories();
      res.json(categories);
    } else {
      res.json([
        { category: "ai-writing", count: 25 },
        { category: "image-generation", count: 18 },
        { category: "code-generation", count: 15 },
        { category: "chatbots", count: 12 }
      ]);
    }
  } catch (error) {
    console.error('Categories error:', error);
    res.json([]);
  }
});

app.get('/api/tools', async (req, res) => {
  try {
    if (storage) {
      const sortBy = req.query.sortBy as "popularity" | "rating" | "recent" | "alphabetical" || 'popularity';
      const limit = parseInt(req.query.limit as string) || 16;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const result = await storage.getAllTools({ sortBy, limit, offset });
      res.json(result);
    } else {
      res.json({
        tools: [{
          id: 1,
          name: "ChatGPT",
          description: "Advanced AI chatbot for conversations and assistance",
          websiteUrl: "https://chatgpt.com",
          logoUrl: "/api/logo/openai.com",
          category: "chatbots",
          pricingModel: "freemium",
          hasApi: true,
          hasFreeVersion: true,
          features: ["conversation", "writing", "coding"],
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
        }],
        total: 1
      });
    }
  } catch (error) {
    console.error('Tools error:', error);
    res.json({ tools: [], total: 0 });
  }
});

app.get('/api/tools/featured', async (req, res) => {
  try {
    if (storage) {
      const featured = await storage.getFeaturedTool();
      res.json(featured);
    } else {
      res.json({
        id: 1,
        name: "ChatGPT",
        description: "Advanced AI chatbot for conversations and assistance",
        websiteUrl: "https://chatgpt.com",
        logoUrl: "/api/logo/openai.com",
        category: "chatbots",
        pricingModel: "freemium",
        hasApi: true,
        hasFreeVersion: true,
        features: ["conversation", "writing", "coding"],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
      });
    }
  } catch (error) {
    console.error('Featured tool error:', error);
    res.json(null);
  }
});

app.get('/api/logo/:domain', (req, res) => {
  res.redirect(`https://logo.clearbit.com/${req.params.domain}`);
});

// Serve static files
const distPath = path.join(process.cwd(), 'client', 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
} else {
  app.get('*', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Kate's List - AI Directory Platform</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
            h1 { color: #333; }
            .status { background: #f0f8ff; padding: 15px; border-radius: 8px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <h1>Kate's List - AI Directory</h1>
          <div class="status">
            <p>Platform is initializing...</p>
            <p>Loading AI tools database and community features.</p>
          </div>
          <script>
            setTimeout(() => location.reload(), 3000);
          </script>
        </body>
      </html>
    `);
  });
}

(async () => {
  try {
    console.log("Starting production server...");
    await initStorage();
    
    const port = parseInt(process.env.PORT || '5000');
    const server = createServer(app);
    
    server.listen(port, '0.0.0.0', () => {
      console.log(`Production server running on port ${port}`);
    });

  } catch (error) {
    console.error("Production server error:", error);
  }
})();