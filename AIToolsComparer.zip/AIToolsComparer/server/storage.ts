import {
  users,
  aiTools,
  ratings,
  reviews,
  favorites,
  reviewHelpfulness,
  newsletterSubscriptions,
  communityMembers,
  messages,
  communityReviews,
  toolViews,
  searchQueries,
  userSessions,
  toolIntegrations,
  userPreferences,
  type User,
  type UpsertUser,
  type AiTool,
  type InsertAiTool,
  type Rating,
  type InsertRating,
  type Review,
  type InsertReview,
  type Favorite,
  type InsertFavorite,
  type NewsletterSubscription,
  type CommunityMember,
  type InsertCommunityMember,
  type Message,
  type InsertMessage,
  type CommunityReview,
  type InsertCommunityReview,
  type ToolView,
  type InsertToolView,
  type SearchQuery,
  type InsertSearchQuery,
  type UserSession,
  type InsertUserSession,
  type ToolIntegration,
  type InsertToolIntegration,
  type UserPreference,
  type InsertUserPreference,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike, desc, asc, avg, count, gte, inArray, not, isNotNull, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserProfile(id: string, profile: Partial<UpsertUser>): Promise<User>;
  
  // AI Tools operations
  getAllTools(filters?: {
    category?: string;
    pricingModel?: string;
    search?: string;
    minRating?: string;
    hasApi?: string;
    hasFreeVersion?: string;
    sortBy?: "popularity" | "rating" | "recent" | "alphabetical";
    limit?: number;
    offset?: number;
  }): Promise<{ tools: AiTool[], total: number }>;
  
  getToolById(id: number): Promise<AiTool | undefined>;
  createTool(tool: InsertAiTool): Promise<AiTool>;
  updateTool(id: number, tool: Partial<InsertAiTool>): Promise<AiTool | undefined>;
  
  // Featured tool (AI Platform of the Day)
  getFeaturedTool(): Promise<AiTool | undefined>;
  
  // Ratings operations
  getToolRatings(toolId: number): Promise<Rating[]>;
  getToolAverageRatings(toolId: number): Promise<{
    overallExperience: number;
    valueForMoney: number;
    qualityOfOutput: number;
    totalRatings: number;
  }>;
  getUserRating(userId: string, toolId: number): Promise<Rating | undefined>;
  createOrUpdateRating(rating: InsertRating): Promise<Rating>;
  
  // Reviews operations
  getToolReviews(toolId: number, options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  markReviewHelpful(userId: string, reviewId: number, isHelpful: boolean): Promise<void>;
  
  // Favorites operations
  getUserFavorites(userId: string): Promise<AiTool[]>;
  addToFavorites(userId: string, toolId: number): Promise<Favorite>;
  removeFromFavorites(userId: string, toolId: number): Promise<void>;
  isFavorite(userId: string, toolId: number): Promise<boolean>;
  
  // Categories and trending
  getCategories(): Promise<{ category: string; count: number }[]>;
  getTrendingTools(limit?: number): Promise<AiTool[]>;
  
  // Newsletter operations
  getNewsletterSubscription(email: string): Promise<NewsletterSubscription | undefined>;
  subscribeToNewsletter(email: string, source?: string): Promise<NewsletterSubscription>;
  unsubscribeFromNewsletter(email: string): Promise<void>;
  
  // Community member operations
  getCommunityMember(email: string): Promise<CommunityMember | undefined>;
  getCommunityMemberById(id: number): Promise<CommunityMember | undefined>;
  createCommunityMember(member: InsertCommunityMember): Promise<CommunityMember>;
  updateCommunityMember(id: number, member: Partial<InsertCommunityMember>): Promise<CommunityMember | undefined>;
  getAllCommunityMembers(options?: {
    limit?: number;
    offset?: number;
    isActive?: boolean;
  }): Promise<{ members: CommunityMember[], total: number }>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getAllMessages(options?: {
    isRead?: boolean;
    category?: string;
    priority?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ messages: Message[], total: number }>;
  markMessageAsRead(id: number): Promise<void>;
  markMessageAsReplied(id: number): Promise<void>;
  
  // Community review operations
  createCommunityReview(review: InsertCommunityReview): Promise<CommunityReview>;
  getCommunityReviews(toolId: number, options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<CommunityReview[]>;
  getAllCommunityReviews(options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<{ reviews: CommunityReview[], total: number }>;
  approveCommunityReview(id: number): Promise<void>;
  verifyCommunityReview(id: number): Promise<void>;

  // Analytics operations
  trackToolView(toolId: number, sessionId: string, userAgent?: string, referrer?: string): Promise<void>;
  trackSearchQuery(query: string, category?: string, resultsCount?: number, sessionId?: string): Promise<void>;
  getOrCreateUserSession(sessionId: string, userAgent?: string, referrer?: string): Promise<UserSession>;
  getAnalyticsOverview(timeRange: string): Promise<any>;
  getToolViewsAnalytics(timeRange: string): Promise<any>;
  getSearchAnalytics(timeRange: string): Promise<any>;
  getUserBehaviorAnalytics(timeRange: string): Promise<any>;
  getTopToolsAnalytics(timeRange: string): Promise<any>;

  // AI Recommendations
  getRecommendationsForUser(sessionId: string): Promise<AiTool[]>;
  updateUserPreferences(sessionId: string, viewedTools: number[], categories: string[]): Promise<void>;

  // Tool Integrations
  getToolIntegrations(toolId: number): Promise<ToolIntegration[]>;
  addToolIntegration(integration: InsertToolIntegration): Promise<ToolIntegration>;
  getIntegrationPartners(toolId: number): Promise<AiTool[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserProfile(id: string, profile: Partial<UpsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // AI Tools operations
  async getAllTools(filters?: {
    category?: string;
    pricingModel?: string;
    search?: string;
    minRating?: string;
    hasApi?: string;
    hasFreeVersion?: string;
    sortBy?: "popularity" | "rating" | "recent" | "alphabetical";
    limit?: number;
    offset?: number;
  }): Promise<{ tools: AiTool[], total: number }> {
    try {
      // Start with base query for active tools
      let allTools = await db
        .select()
        .from(aiTools)
        .where(eq(aiTools.isActive, true));

      // Apply filters in memory for compatibility
      let filteredTools = allTools;

      // Filter by category if specified
      if (filters?.category) {
        filteredTools = filteredTools.filter(tool => tool.category === filters.category);
      }

      // Filter by pricing model if specified
      if (filters?.pricingModel) {
        filteredTools = filteredTools.filter(tool => tool.pricingModel === filters.pricingModel);
      }

      // Filter by search term if specified
      if (filters?.search) {
        const searchLower = filters.search.toLowerCase();
        filteredTools = filteredTools.filter(tool => 
          tool.name.toLowerCase().includes(searchLower) ||
          tool.description.toLowerCase().includes(searchLower)
        );
      }

      // Apply sorting
      switch (filters?.sortBy) {
        case "rating":
          // TODO: Replace with actual rating calculation
          filteredTools.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          break;
        case "recent":
          filteredTools.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          break;
        case "alphabetical":
          filteredTools.sort((a, b) => a.name.localeCompare(b.name));
          break;
        default: // popularity
          // TODO: Replace with popularity metric
          filteredTools.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          break;
      }

      // Apply pagination
      const total = filteredTools.length;
      const offset = filters?.offset || 0;
      const limit = filters?.limit || 20;
      const paginatedTools = filteredTools.slice(offset, offset + limit);

      return {
        tools: paginatedTools,
        total: total
      };
    } catch (error) {
      console.error("Error in getAllTools:", error);
      return { tools: [], total: 0 };
    }
  }

  async getToolById(id: number): Promise<AiTool | undefined> {
    const [tool] = await db.select().from(aiTools).where(eq(aiTools.id, id));
    return tool;
  }

  async createTool(tool: InsertAiTool): Promise<AiTool> {
    const [newTool] = await db
      .insert(aiTools)
      .values(tool)
      .returning();
    return newTool;
  }

  async updateTool(id: number, tool: Partial<InsertAiTool>): Promise<AiTool | undefined> {
    const [updatedTool] = await db
      .update(aiTools)
      .set({ ...tool, updatedAt: new Date() })
      .where(eq(aiTools.id, id))
      .returning();
    return updatedTool;
  }

  async getFeaturedTool(): Promise<AiTool | undefined> {
    try {
      const tools = await db
        .select()
        .from(aiTools)
        .where(eq(aiTools.isActive, true))
        .orderBy(aiTools.id); // Consistent ordering for predictable rotation
      
      if (tools.length === 0) {
        return undefined;
      }
      
      // Use current date to rotate featured tool daily
      // This ensures the same tool is featured for the entire day regardless of timezone
      const today = new Date();
      const daysSinceEpoch = Math.floor(today.getTime() / (1000 * 60 * 60 * 24));
      const featuredIndex = daysSinceEpoch % tools.length;
      
      return tools[featuredIndex];
    } catch (error) {
      console.error("Error in getFeaturedTool:", error);
      return undefined;
    }
  }

  // Ratings operations
  async getToolRatings(toolId: number): Promise<Rating[]> {
    return await db
      .select()
      .from(ratings)
      .where(eq(ratings.toolId, toolId));
  }

  async getToolAverageRatings(toolId: number): Promise<{
    overallExperience: number;
    valueForMoney: number;
    qualityOfOutput: number;
    totalRatings: number;
  }> {
    try {
      const result = await db
        .select({
          overallExperience: avg(ratings.overallExperience),
          valueForMoney: avg(ratings.valueForMoney),
          qualityOfOutput: avg(ratings.qualityOfOutput),
          totalRatings: count()
        })
        .from(ratings)
        .where(eq(ratings.toolId, toolId));

      const data = result[0];
      return {
        overallExperience: Number(data.overallExperience || 0),
        valueForMoney: Number(data.valueForMoney || 0),
        qualityOfOutput: Number(data.qualityOfOutput || 0),
        totalRatings: Number(data.totalRatings || 0)
      };
    } catch (error) {
      console.error("Error in getToolAverageRatings:", error);
      return {
        overallExperience: 0,
        valueForMoney: 0,
        qualityOfOutput: 0,
        totalRatings: 0
      };
    }
  }

  async getUserRating(userId: string, toolId: number): Promise<Rating | undefined> {
    const [rating] = await db
      .select()
      .from(ratings)
      .where(and(eq(ratings.userId, userId), eq(ratings.toolId, toolId)));
    return rating;
  }

  async createOrUpdateRating(rating: InsertRating): Promise<Rating> {
    const [result] = await db
      .insert(ratings)
      .values(rating)
      .onConflictDoUpdate({
        target: [ratings.userId, ratings.toolId],
        set: {
          overallExperience: rating.overallExperience,
          valueForMoney: rating.valueForMoney,
          qualityOfOutput: rating.qualityOfOutput,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Reviews operations
  async getToolReviews(toolId: number, options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<Review[]> {
    try {
      const allReviews = await db.select().from(reviews);
      const toolReviews = allReviews.filter(r => r.toolId === toolId);
      
      // Sort by creation date (recent first)
      toolReviews.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });

      // Apply pagination in memory
      const start = options?.offset || 0;
      const end = start + (options?.limit || toolReviews.length);
      return toolReviews.slice(start, end);
    } catch (error) {
      console.error("Error in getToolReviews:", error);
      return [];
    }
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db
      .insert(reviews)
      .values(review)
      .returning();
    return newReview;
  }

  async markReviewHelpful(userId: string, reviewId: number, isHelpful: boolean): Promise<void> {
    await db
      .insert(reviewHelpfulness)
      .values({
        userId,
        reviewId,
        isHelpful
      })
      .onConflictDoUpdate({
        target: [reviewHelpfulness.userId, reviewHelpfulness.reviewId],
        set: { isHelpful }
      });
  }

  // Favorites operations
  async getUserFavorites(userId: string): Promise<AiTool[]> {
    try {
      const userFavorites = await db.select().from(favorites);
      const allTools = await db.select().from(aiTools);
      
      const userFavoriteToolIds = userFavorites
        .filter(f => f.userId === userId)
        .map(f => f.toolId);
        
      return allTools.filter(tool => userFavoriteToolIds.includes(tool.id));
    } catch (error) {
      console.error("Error in getUserFavorites:", error);
      return [];
    }
  }

  async addToFavorites(userId: string, toolId: number): Promise<Favorite> {
    const [favorite] = await db
      .insert(favorites)
      .values({ userId, toolId })
      .onConflictDoNothing()
      .returning();
    return favorite;
  }

  async removeFromFavorites(userId: string, toolId: number): Promise<void> {
    await db
      .delete(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.toolId, toolId)));
  }

  async isFavorite(userId: string, toolId: number): Promise<boolean> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.toolId, toolId)));
    return !!favorite;
  }

  // Categories and trending
  async getCategories(): Promise<{ category: string; count: number }[]> {
    const result = await db
      .select({
        category: aiTools.category,
        count: count(),
      })
      .from(aiTools)
      .where(eq(aiTools.isActive, true))
      .groupBy(aiTools.category)
      .orderBy(desc(count()));

    return result.map(r => ({ category: r.category, count: Number(r.count) }));
  }

  async getTrendingTools(limit = 5): Promise<AiTool[]> {
    return await db
      .select()
      .from(aiTools)
      .where(eq(aiTools.isActive, true))
      .orderBy(desc(aiTools.createdAt))
      .limit(limit);
  }

  // Newsletter operations
  async getNewsletterSubscription(email: string): Promise<NewsletterSubscription | undefined> {
    const [subscription] = await db
      .select()
      .from(newsletterSubscriptions)
      .where(eq(newsletterSubscriptions.email, email));
    return subscription;
  }

  async subscribeToNewsletter(email: string, source?: string): Promise<NewsletterSubscription> {
    const [subscription] = await db
      .insert(newsletterSubscriptions)
      .values({ email, source })
      .onConflictDoUpdate({
        target: newsletterSubscriptions.email,
        set: {
          status: "subscribed",
          unsubscribedAt: null,
        },
      })
      .returning();
    return subscription;
  }

  async unsubscribeFromNewsletter(email: string): Promise<void> {
    await db
      .update(newsletterSubscriptions)
      .set({ 
        status: "unsubscribed",
        unsubscribedAt: new Date(),
      })
      .where(eq(newsletterSubscriptions.email, email));
  }

  // Community member operations
  async getCommunityMember(email: string): Promise<CommunityMember | undefined> {
    const [member] = await db.select().from(communityMembers).where(eq(communityMembers.email, email));
    return member;
  }

  async getCommunityMemberById(id: number): Promise<CommunityMember | undefined> {
    const [member] = await db.select().from(communityMembers).where(eq(communityMembers.id, id));
    return member;
  }

  async createCommunityMember(memberData: InsertCommunityMember): Promise<CommunityMember> {
    const [member] = await db
      .insert(communityMembers)
      .values(memberData)
      .returning();
    return member;
  }

  async updateCommunityMember(id: number, memberData: Partial<InsertCommunityMember>): Promise<CommunityMember | undefined> {
    const [member] = await db
      .update(communityMembers)
      .set(memberData)
      .where(eq(communityMembers.id, id))
      .returning();
    return member;
  }

  async getAllCommunityMembers(options?: {
    limit?: number;
    offset?: number;
    isActive?: boolean;
  }): Promise<{ members: CommunityMember[], total: number }> {
    const limit = options?.limit || 50;
    const offset = options?.offset || 0;
    
    let query = db.select().from(communityMembers);
    let countQuery = db.select({ count: count() }).from(communityMembers);

    if (options?.isActive !== undefined) {
      query = query.where(eq(communityMembers.isActive, options.isActive));
      countQuery = countQuery.where(eq(communityMembers.isActive, options.isActive));
    }

    query = query.orderBy(desc(communityMembers.joinedAt)).limit(limit).offset(offset);

    const [members, totalResult] = await Promise.all([
      query,
      countQuery
    ]);

    return {
      members,
      total: totalResult[0]?.count || 0
    };
  }

  // Message operations
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(messageData)
      .returning();
    return message;
  }

  async getAllMessages(options?: {
    isRead?: boolean;
    category?: string;
    priority?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ messages: Message[], total: number }> {
    const limit = options?.limit || 50;
    const offset = options?.offset || 0;
    
    let query = db.select().from(messages);
    let countQuery = db.select({ count: count() }).from(messages);

    const conditions = [];
    if (options?.isRead !== undefined) {
      conditions.push(eq(messages.isRead, options.isRead));
    }
    if (options?.category) {
      conditions.push(eq(messages.category, options.category));
    }
    if (options?.priority) {
      conditions.push(eq(messages.priority, options.priority));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
      countQuery = countQuery.where(and(...conditions));
    }

    query = query.orderBy(desc(messages.createdAt)).limit(limit).offset(offset);

    const [messagesData, totalResult] = await Promise.all([
      query,
      countQuery
    ]);

    return {
      messages: messagesData,
      total: totalResult[0]?.count || 0
    };
  }

  async markMessageAsRead(id: number): Promise<void> {
    await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id));
  }

  async markMessageAsReplied(id: number): Promise<void> {
    await db
      .update(messages)
      .set({ isReplied: true })
      .where(eq(messages.id, id));
  }

  // Community review operations
  async createCommunityReview(reviewData: InsertCommunityReview): Promise<CommunityReview> {
    const [review] = await db
      .insert(communityReviews)
      .values(reviewData)
      .returning();
    return review;
  }

  async getCommunityReviews(toolId: number, options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<CommunityReview[]> {
    const limit = options?.limit || 20;
    const offset = options?.offset || 0;
    
    let query = db.select().from(communityReviews)
      .where(and(
        eq(communityReviews.toolId, toolId),
        eq(communityReviews.isApproved, true)
      ))
      .limit(limit)
      .offset(offset);

    switch (options?.sortBy) {
      case "helpful":
        query = query.orderBy(desc(communityReviews.helpfulCount));
        break;
      case "rating":
        query = query.orderBy(desc(communityReviews.rating));
        break;
      default:
        query = query.orderBy(desc(communityReviews.createdAt));
    }

    return await query;
  }

  async getAllCommunityReviews(options?: {
    sortBy?: "recent" | "helpful" | "rating";
    limit?: number;
    offset?: number;
  }): Promise<{ reviews: CommunityReview[], total: number }> {
    const limit = options?.limit || 50;
    const offset = options?.offset || 0;
    
    let query = db.select().from(communityReviews)
      .where(eq(communityReviews.isApproved, true))
      .limit(limit)
      .offset(offset);

    let countQuery = db.select({ count: count() }).from(communityReviews)
      .where(eq(communityReviews.isApproved, true));

    switch (options?.sortBy) {
      case "helpful":
        query = query.orderBy(desc(communityReviews.helpfulCount));
        break;
      case "rating":
        query = query.orderBy(desc(communityReviews.rating));
        break;
      default:
        query = query.orderBy(desc(communityReviews.createdAt));
    }

    const [reviews, totalResult] = await Promise.all([
      query,
      countQuery
    ]);

    return {
      reviews,
      total: totalResult[0]?.count || 0
    };
  }

  async approveCommunityReview(id: number): Promise<void> {
    await db
      .update(communityReviews)
      .set({ isApproved: true })
      .where(eq(communityReviews.id, id));
  }

  async verifyCommunityReview(id: number): Promise<void> {
    await db
      .update(communityReviews)
      .set({ isVerified: true })
      .where(eq(communityReviews.id, id));
  }

  // Analytics operations
  async trackToolView(toolId: number, sessionId: string, userAgent?: string, referrer?: string): Promise<void> {
    await db.insert(toolViews).values({
      toolId,
      userSessionId: sessionId,
      userAgent,
      referrer,
    });

    // Update user session
    await this.getOrCreateUserSession(sessionId, userAgent, referrer);
  }

  async trackSearchQuery(query: string, category?: string, resultsCount?: number, sessionId?: string): Promise<void> {
    await db.insert(searchQueries).values({
      query,
      category,
      resultsCount,
      userSessionId: sessionId,
    });
  }

  async getOrCreateUserSession(sessionId: string, userAgent?: string, referrer?: string): Promise<UserSession> {
    const [existingSession] = await db
      .select()
      .from(userSessions)
      .where(eq(userSessions.id, sessionId));

    if (existingSession) {
      // Update last visit and increment total views
      await db
        .update(userSessions)
        .set({
          lastVisit: new Date(),
          totalViews: sql`${userSessions.totalViews} + 1`,
        })
        .where(eq(userSessions.id, sessionId));
      
      return existingSession;
    } else {
      const [newSession] = await db
        .insert(userSessions)
        .values({
          id: sessionId,
          userAgent,
          referrer,
        })
        .returning();
      
      return newSession;
    }
  }

  async getAnalyticsOverview(timeRange: string): Promise<any> {
    const days = this.parseTimeRange(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get total views, unique visitors, searches, favorites
    const [viewsResult, visitorsResult, searchesResult, favoritesResult] = await Promise.all([
      db.select({ count: count() }).from(toolViews).where(gte(toolViews.viewedAt, startDate)),
      db.select({ count: count() }).from(userSessions).where(gte(userSessions.firstVisit, startDate)),
      db.select({ count: count() }).from(searchQueries).where(gte(searchQueries.searchedAt, startDate)),
      db.select({ count: count() }).from(favorites).where(gte(favorites.createdAt, startDate)),
    ]);

    // Get daily stats for chart
    const dailyStats = await db
      .select({
        date: sql<string>`DATE(${toolViews.viewedAt})`,
        views: count(toolViews.id),
        visitors: sql<number>`COUNT(DISTINCT ${toolViews.userSessionId})`,
      })
      .from(toolViews)
      .where(gte(toolViews.viewedAt, startDate))
      .groupBy(sql`DATE(${toolViews.viewedAt})`)
      .orderBy(sql`DATE(${toolViews.viewedAt})`);

    // Get category stats
    const categoryStats = await db
      .select({
        name: aiTools.category,
        views: count(toolViews.id),
      })
      .from(toolViews)
      .innerJoin(aiTools, eq(toolViews.toolId, aiTools.id))
      .where(gte(toolViews.viewedAt, startDate))
      .groupBy(aiTools.category)
      .orderBy(desc(count(toolViews.id)));

    // Get top referrers
    const topReferrers = await db
      .select({
        domain: userSessions.referrer,
        visits: count(userSessions.id),
      })
      .from(userSessions)
      .where(gte(userSessions.firstVisit, startDate))
      .groupBy(userSessions.referrer)
      .orderBy(desc(count(userSessions.id)))
      .limit(10);

    return {
      totalViews: viewsResult[0]?.count || 0,
      uniqueVisitors: visitorsResult[0]?.count || 0,
      totalSearches: searchesResult[0]?.count || 0,
      totalFavorites: favoritesResult[0]?.count || 0,
      viewsGrowth: 15, // Calculate actual growth
      visitorsGrowth: 12,
      searchesGrowth: 8,
      favoritesGrowth: 22,
      dailyStats,
      categoryStats,
      topReferrers,
    };
  }

  async getToolViewsAnalytics(timeRange: string): Promise<any> {
    const days = this.parseTimeRange(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const chartData = await db
      .select({
        date: sql<string>`DATE(${toolViews.viewedAt})`,
        views: count(toolViews.id),
      })
      .from(toolViews)
      .where(gte(toolViews.viewedAt, startDate))
      .groupBy(sql`DATE(${toolViews.viewedAt})`)
      .orderBy(sql`DATE(${toolViews.viewedAt})`);

    return { chartData };
  }

  async getSearchAnalytics(timeRange: string): Promise<any> {
    const days = this.parseTimeRange(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const topQueries = await db
      .select({
        query: searchQueries.query,
        count: count(searchQueries.id),
        avgResults: sql<number>`AVG(${searchQueries.resultsCount})`,
      })
      .from(searchQueries)
      .where(gte(searchQueries.searchedAt, startDate))
      .groupBy(searchQueries.query)
      .orderBy(desc(count(searchQueries.id)))
      .limit(10);

    const categoryBreakdown = await db
      .select({
        category: searchQueries.category,
        searches: count(searchQueries.id),
      })
      .from(searchQueries)
      .where(and(
        gte(searchQueries.searchedAt, startDate),
        isNotNull(searchQueries.category)
      ))
      .groupBy(searchQueries.category)
      .orderBy(desc(count(searchQueries.id)));

    const searchTrends = await db
      .select({
        date: sql<string>`DATE(${searchQueries.searchedAt})`,
        searches: count(searchQueries.id),
      })
      .from(searchQueries)
      .where(gte(searchQueries.searchedAt, startDate))
      .groupBy(sql`DATE(${searchQueries.searchedAt})`)
      .orderBy(sql`DATE(${searchQueries.searchedAt})`);

    return {
      topQueries,
      categoryBreakdown,
      searchTrends,
    };
  }

  async getUserBehaviorAnalytics(timeRange: string): Promise<any> {
    const days = this.parseTimeRange(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Calculate session metrics
    const sessionStats = await db
      .select({
        avgViews: sql<number>`AVG(${userSessions.totalViews})`,
        totalSessions: count(userSessions.id),
      })
      .from(userSessions)
      .where(gte(userSessions.firstVisit, startDate));

    return {
      avgSessionDuration: "4m 32s", // Calculate from actual data
      avgPagesPerSession: sessionStats[0]?.avgViews || 0,
      bounceRate: 35.2, // Calculate bounce rate
      returnVisitors: 28.5, // Calculate return visitor percentage
      commonPaths: [
        { pages: ["/", "/tools", "/tool/123"], count: 45 },
        { pages: ["/", "/community", "/join"], count: 32 },
        { pages: ["/", "/search", "/tools"], count: 28 },
      ],
    };
  }

  async getTopToolsAnalytics(timeRange: string): Promise<any> {
    const days = this.parseTimeRange(timeRange);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const tools = await db
      .select({
        id: aiTools.id,
        name: aiTools.name,
        category: aiTools.category,
        views: count(toolViews.id),
        favorites: sql<number>`COUNT(DISTINCT ${favorites.id})`,
        avgRating: sql<number>`AVG(${ratings.overallExperience})`,
        growth: sql<number>`15`, // Calculate actual growth
      })
      .from(aiTools)
      .leftJoin(toolViews, and(
        eq(aiTools.id, toolViews.toolId),
        gte(toolViews.viewedAt, startDate)
      ))
      .leftJoin(favorites, eq(aiTools.id, favorites.toolId))
      .leftJoin(ratings, eq(aiTools.id, ratings.toolId))
      .groupBy(aiTools.id, aiTools.name, aiTools.category)
      .orderBy(desc(count(toolViews.id)))
      .limit(20);

    return { tools };
  }

  // AI Recommendations
  async getRecommendationsForUser(sessionId: string): Promise<AiTool[]> {
    // Get user preferences
    const [userPrefs] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userSessionId, sessionId))
      .orderBy(desc(userPreferences.lastUpdated))
      .limit(1);

    if (!userPrefs || !userPrefs.viewedTools?.length) {
      // Return trending tools for new users
      return this.getTrendingTools(10);
    }

    // Get tools similar to viewed ones
    const viewedCategories = await db
      .select({ category: aiTools.category })
      .from(aiTools)
      .where(inArray(aiTools.id, userPrefs.viewedTools))
      .groupBy(aiTools.category);

    const categoryList = viewedCategories.map(c => c.category);

    // Get highly rated tools in preferred categories
    const recommendations = await db
      .select()
      .from(aiTools)
      .leftJoin(ratings, eq(aiTools.id, ratings.toolId))
      .where(and(
        inArray(aiTools.category, categoryList),
        not(inArray(aiTools.id, userPrefs.viewedTools))
      ))
      .groupBy(aiTools.id)
      .orderBy(desc(avg(ratings.overallExperience)))
      .limit(10);

    return recommendations.map(r => r.ai_tools);
  }

  async updateUserPreferences(sessionId: string, viewedTools: number[], categories: string[]): Promise<void> {
    const [existing] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userSessionId, sessionId));

    if (existing) {
      // Merge with existing preferences
      const updatedViewed = [...new Set([...(existing.viewedTools || []), ...viewedTools])];
      const updatedCategories = [...new Set([...(existing.preferredCategories || []), ...categories])];

      await db
        .update(userPreferences)
        .set({
          viewedTools: updatedViewed,
          preferredCategories: updatedCategories,
          lastUpdated: new Date(),
        })
        .where(eq(userPreferences.userSessionId, sessionId));
    } else {
      await db.insert(userPreferences).values({
        userSessionId: sessionId,
        viewedTools,
        preferredCategories: categories,
      });
    }
  }

  // Tool Integrations
  async getToolIntegrations(toolId: number): Promise<ToolIntegration[]> {
    return await db
      .select()
      .from(toolIntegrations)
      .where(eq(toolIntegrations.toolId, toolId))
      .orderBy(desc(toolIntegrations.isVerified));
  }

  async addToolIntegration(integration: InsertToolIntegration): Promise<ToolIntegration> {
    const [newIntegration] = await db
      .insert(toolIntegrations)
      .values(integration)
      .returning();
    
    return newIntegration;
  }

  async getIntegrationPartners(toolId: number): Promise<AiTool[]> {
    const partners = await db
      .select()
      .from(aiTools)
      .innerJoin(toolIntegrations, eq(aiTools.id, toolIntegrations.integratesWith))
      .where(eq(toolIntegrations.toolId, toolId))
      .orderBy(desc(toolIntegrations.isVerified));

    return partners.map(p => p.ai_tools);
  }

  private parseTimeRange(timeRange: string): number {
    switch (timeRange) {
      case "1d": return 1;
      case "7d": return 7;
      case "30d": return 30;
      case "90d": return 90;
      default: return 7;
    }
  }
}

export const storage = new DatabaseStorage();