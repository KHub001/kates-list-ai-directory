import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, Clock } from "lucide-react";

export default function Blog() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const blogPosts = [
    {
      id: 1,
      title: "The Rise of AI-Powered Content Creation Tools in 2025",
      excerpt: "Exploring how AI is revolutionizing content creation across industries, from copywriting to video production.",
      author: "Sarah Chen",
      date: "2025-06-01",
      readTime: "5 min read",
      category: "Industry Trends",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=250&fit=crop"
    },
    {
      id: 2,
      title: "Comparing OpenAI GPT-4 vs Claude 3: Which AI Assistant is Right for You?",
      excerpt: "A comprehensive comparison of the leading AI language models and their best use cases.",
      author: "Michael Rodriguez",
      date: "2025-05-28",
      readTime: "8 min read",
      category: "Tool Reviews",
      image: "https://images.unsplash.com/photo-1676299081847-824916de030a?w=400&h=250&fit=crop"
    },
    {
      id: 3,
      title: "10 Free AI Tools Every Small Business Should Know About",
      excerpt: "Budget-friendly AI solutions that can help small businesses automate tasks and boost productivity.",
      author: "Emma Thompson",
      date: "2025-05-25",
      readTime: "6 min read",
      category: "Small Business",
      image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=250&fit=crop"
    },
    {
      id: 4,
      title: "Ethics in AI: What to Consider When Choosing AI Tools",
      excerpt: "Important ethical considerations and best practices when implementing AI tools in your workflow.",
      author: "Dr. James Liu",
      date: "2025-05-22",
      readTime: "7 min read",
      category: "Ethics",
      image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=400&h=250&fit=crop"
    },
    {
      id: 5,
      title: "AI in Education: Tools Transforming Learning and Teaching",
      excerpt: "How educators are leveraging AI tools to enhance student learning and streamline administrative tasks.",
      author: "Lisa Park",
      date: "2025-05-20",
      readTime: "9 min read",
      category: "Education",
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=250&fit=crop"
    },
    {
      id: 6,
      title: "The Future of AI Video Generation: Beyond Deepfakes",
      excerpt: "Exploring legitimate applications of AI video generation technology and what's coming next.",
      author: "Alex Kim",
      date: "2025-05-18",
      readTime: "4 min read",
      category: "Technology",
      image: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=250&fit=crop"
    }
  ];

  const categories = ["All", "Industry Trends", "Tool Reviews", "Small Business", "Ethics", "Education", "Technology"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            AI Tools <span className="text-purple-600">Blog</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Stay updated with the latest insights, reviews, and trends in the AI tools ecosystem. 
            Expert analysis and practical guides to help you make informed decisions.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-8 justify-center">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={category === "All" ? "default" : "outline"}
              className="cursor-pointer hover:bg-purple-100 px-4 py-2"
            >
              {category}
            </Badge>
          ))}
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="aspect-video overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="text-xs">
                    {post.category}
                  </Badge>
                  <div className="flex items-center text-xs text-slate-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="text-lg line-clamp-2 hover:text-purple-600 transition-colors">
                  {post.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-slate-600 text-sm line-clamp-3 mb-4">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center">
                    <User className="h-3 w-3 mr-1" />
                    {post.author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {new Date(post.date).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter Signup */}
        <Card className="mt-16 bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Never Miss an Update</h3>
            <p className="text-purple-100 mb-6 max-w-2xl mx-auto">
              Get our weekly newsletter with the latest AI tool reviews, industry insights, 
              and practical guides delivered straight to your inbox.
            </p>
            <div className="flex max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-l-lg text-slate-900 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-300"
              />
              <button className="px-6 py-3 bg-white text-purple-600 rounded-r-lg hover:bg-purple-50 transition-colors font-medium">
                Subscribe
              </button>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}