import { useEffect } from 'react';
import { useLocation } from 'wouter';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string[];
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'product';
  siteName?: string;
}

export default function SEO({
  title = "Kate's List - Discover AI Tools Together",
  description = "Join our community of AI enthusiasts. Discover, review, and compare 175+ verified AI tools. Find the perfect AI solution for your needs with expert community insights.",
  keywords = ['AI tools', 'artificial intelligence', 'AI directory', 'machine learning', 'AI community', 'AI reviews'],
  image = '/og-image.png',
  url,
  type = 'website',
  siteName = "Kate's List"
}: SEOProps) {
  const [location] = useLocation();
  
  useEffect(() => {
    // Update document title
    document.title = title;
    
    // Get current URL
    const currentUrl = url || `${window.location.origin}${location}`;
    
    // Update meta tags
    updateMetaTag('description', description);
    updateMetaTag('keywords', keywords.join(', '));
    
    // Open Graph tags
    updateMetaTag('og:title', title, 'property');
    updateMetaTag('og:description', description, 'property');
    updateMetaTag('og:image', `${window.location.origin}${image}`, 'property');
    updateMetaTag('og:url', currentUrl, 'property');
    updateMetaTag('og:type', type, 'property');
    updateMetaTag('og:site_name', siteName, 'property');
    
    // Twitter Card tags
    updateMetaTag('twitter:card', 'summary_large_image', 'name');
    updateMetaTag('twitter:title', title, 'name');
    updateMetaTag('twitter:description', description, 'name');
    updateMetaTag('twitter:image', `${window.location.origin}${image}`, 'name');
    
    // Canonical URL
    updateCanonicalUrl(currentUrl);
    
    // JSON-LD structured data
    updateStructuredData({
      '@context': 'https://schema.org',
      '@type': type === 'website' ? 'WebSite' : 'WebPage',
      name: title,
      description: description,
      url: currentUrl,
      image: `${window.location.origin}${image}`,
      publisher: {
        '@type': 'Organization',
        name: siteName,
        logo: `${window.location.origin}/logo.png`
      }
    });
    
  }, [title, description, keywords, image, url, type, siteName, location]);

  return null;
}

function updateMetaTag(name: string, content: string, attribute: 'name' | 'property' = 'name') {
  let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
  
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }
  
  element.content = content;
}

function updateCanonicalUrl(url: string) {
  let element = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
  
  if (!element) {
    element = document.createElement('link');
    element.rel = 'canonical';
    document.head.appendChild(element);
  }
  
  element.href = url;
}

function updateStructuredData(data: any) {
  let element = document.querySelector('script[type="application/ld+json"]') as HTMLScriptElement;
  
  if (!element) {
    element = document.createElement('script');
    element.type = 'application/ld+json';
    document.head.appendChild(element);
  }
  
  element.textContent = JSON.stringify(data);
}

// SEO utility functions for different page types
export function getToolPageSEO(tool: any) {
  return {
    title: `${tool.name} - AI Tool Review & Pricing | Kate's List`,
    description: `${tool.description.slice(0, 150)}... Read community reviews, compare pricing, and find alternatives. Join Kate's List AI community.`,
    keywords: [tool.name, tool.category, 'AI tool', 'review', 'pricing', 'alternatives'],
    type: 'product' as const,
    image: tool.logoUrl || '/default-tool-image.png'
  };
}

export function getCategoryPageSEO(category: string, toolCount: number) {
  const categoryNames: { [key: string]: string } = {
    'text-generation': 'Text Generation',
    'image-generation': 'Image Generation', 
    'video-creation': 'Video Creation',
    'audio-processing': 'Audio Processing',
    'data-analysis': 'Data Analysis',
    'automation': 'Automation',
    'chatbots': 'Chatbots',
    'productivity': 'Productivity'
  };
  
  const displayName = categoryNames[category] || category;
  
  return {
    title: `Best ${displayName} AI Tools 2024 - Reviews & Comparisons | Kate's List`,
    description: `Discover ${toolCount}+ verified ${displayName.toLowerCase()} AI tools. Read community reviews, compare features and pricing. Find the perfect AI solution for your needs.`,
    keywords: [displayName, 'AI tools', category, 'reviews', 'comparison', 'best AI tools 2024'],
    type: 'website' as const
  };
}

export function getSearchPageSEO(query: string, resultCount: number) {
  return {
    title: `"${query}" AI Tools - Search Results | Kate's List`,
    description: `Found ${resultCount} AI tools matching "${query}". Compare features, read reviews, and find the perfect AI solution for your needs.`,
    keywords: [query, 'AI tools', 'search', 'reviews', 'comparison'],
    type: 'website' as const
  };
}