import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, RefreshCw, Database, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);

  // Check sync status
  const { data: syncStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/admin/sync-status"],
    enabled: isAuthenticated,
  });

  // Update tools mutation
  const updateToolsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/admin/update-tools");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "AI tools database updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/tools"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/sync-status"] });
      setIsUpdating(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsUpdating(false);
    },
  });

  const handleUpdateTools = () => {
    setIsUpdating(true);
    updateToolsMutation.mutate();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle>Admin Access Required</CardTitle>
            <CardDescription>Please log in to access the admin dashboard</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage AI tools data and monitor system status</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Relevance AI Status */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Relevance AI Status</CardTitle>
              <Database className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Active
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Automated data sync every 24 hours
              </p>
            </CardContent>
          </Card>

          {/* Total Tools */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total AI Tools</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statusLoading ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  syncStatus?.totalTools || 0
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Tools in database
              </p>
            </CardContent>
          </Card>

          {/* Last Updated */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last Updated</CardTitle>
              <RefreshCw className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {statusLoading ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  syncStatus?.lastUpdated ? 
                    new Date(syncStatus.lastUpdated).toLocaleDateString() : 
                    "Never"
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Database last sync
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Actions */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>
                Manually trigger data updates from Relevance AI
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h3 className="font-medium">Update AI Tools Database</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Fetch the latest AI tools from Relevance AI and update the database
                  </p>
                </div>
                <Button
                  onClick={handleUpdateTools}
                  disabled={isUpdating || updateToolsMutation.isPending}
                  className="ml-4"
                >
                  {(isUpdating || updateToolsMutation.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Update Now
                    </>
                  )}
                </Button>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900">Automatic Updates</h4>
                <p className="text-sm text-blue-700 mt-1">
                  The system automatically fetches new AI tools every 24 hours. Manual updates are useful for immediate data refresh.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}