import express from 'express';
import { createServer } from 'http';

const app = express();
app.use(express.json());

// Health endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Database storage variable
let storage: any = null;

// Initialize database connection safely
async function initDB() {
  try {
    if (process.env.DATABASE_URL) {
      const { storage: dbStorage } = await import("./storage");
      storage = dbStorage;
      console.log("Database connected");
      return true;
    }
    return false;
  } catch (error) {
    console.error("Database error:", error);
    return false;
  }
}

// API endpoints with database integration
app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', async (req, res) => {
  try {
    if (storage) {
      const categories = await storage.getCategories();
      res.json(categories);
    } else {
      res.json([]);
    }
  } catch (error) {
    console.error('Categories error:', error);
    res.json([]);
  }
});

app.get('/api/tools', async (req, res) => {
  try {
    if (storage) {
      const sortBy = (req.query.sortBy as "popularity" | "rating" | "recent" | "alphabetical") || 'popularity';
      const limit = parseInt(req.query.limit as string) || 16;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const result = await storage.getAllTools({ sortBy, limit, offset });
      res.json(result);
    } else {
      res.json({ tools: [], total: 0 });
    }
  } catch (error) {
    console.error('Tools error:', error);
    res.json({ tools: [], total: 0 });
  }
});

app.get('/api/tools/featured', async (req, res) => {
  try {
    if (storage) {
      const featured = await storage.getFeaturedTool();
      res.json(featured);
    } else {
      res.json(null);
    }
  } catch (error) {
    console.error('Featured error:', error);
    res.json(null);
  }
});

app.get('/api/logo/:domain', (req, res) => {
  res.redirect(`https://logo.clearbit.com/${req.params.domain}`);
});

// Setup Vite for development, static files for production
async function setupFrontend() {
  try {
    const { setupVite } = await import("./vite");
    const server = createServer(app);
    await setupVite(app, server);
    return server;
  } catch (error) {
    console.error("Vite setup failed:", error);
    return createServer(app);
  }
}

// Server initialization
(async () => {
  console.log("Initializing Kate's List server...");
  
  // Initialize database
  await initDB();
  
  // Setup server
  const server = await setupFrontend();
  const port = parseInt(process.env.PORT || '5000');
  
  server.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
})();