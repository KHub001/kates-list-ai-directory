import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Mail, CheckCircle } from "lucide-react";

interface NewsletterSignupProps {
  variant?: "inline" | "card" | "minimal";
  title?: string;
  description?: string;
  className?: string;
}

export default function NewsletterSignup({ 
  variant = "card", 
  title = "Stay Updated with AI Tools",
  description = "Get weekly insights on the latest AI tools and trends",
  className = ""
}: NewsletterSignupProps) {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const { toast } = useToast();

  const subscribeMutation = useMutation({
    mutationFn: async (email: string) => {
      const res = await apiRequest("POST", "/api/newsletter/subscribe", { email });
      return res.json();
    },
    onSuccess: () => {
      setIsSubscribed(true);
      setEmail("");
      toast({
        title: "Successfully subscribed!",
        description: "You'll receive our weekly AI tools newsletter.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Subscription failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    subscribeMutation.mutate(email);
  };

  if (isSubscribed) {
    return (
      <div className={`flex items-center space-x-2 text-green-600 ${className}`}>
        <CheckCircle className="h-5 w-5" />
        <span className="text-sm font-medium">Thanks for subscribing!</span>
      </div>
    );
  }

  const formContent = (
    <form onSubmit={handleSubmit} className="flex space-x-2">
      <Input
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="flex-1"
        disabled={subscribeMutation.isPending}
      />
      <Button 
        type="submit" 
        disabled={subscribeMutation.isPending || !email.trim()}
        className="whitespace-nowrap"
      >
        {subscribeMutation.isPending ? "Subscribing..." : "Subscribe"}
      </Button>
    </form>
  );

  if (variant === "minimal") {
    return (
      <div className={className}>
        {formContent}
      </div>
    );
  }

  if (variant === "inline") {
    return (
      <div className={`bg-slate-50 dark:bg-slate-800 p-6 rounded-lg ${className}`}>
        <div className="flex items-center space-x-3 mb-4">
          <Mail className="h-6 w-6 text-blue-600" />
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">{description}</p>
          </div>
        </div>
        {formContent}
      </div>
    );
  }

  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Mail className="h-8 w-8 text-blue-600" />
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">{description}</p>
          </div>
        </div>
        {formContent}
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-3">
          No spam. Unsubscribe at any time.
        </p>
      </CardContent>
    </Card>
  );
}