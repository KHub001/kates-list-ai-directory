import express from "express";
import { createServer } from "http";
import path from "path";
import fs from "fs";

const app = express();

// Basic middleware
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

// Health check - always works
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Basic API endpoints that always work
app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', (req, res) => {
  res.json([
    { category: "ai-writing", count: 25 },
    { category: "image-generation", count: 18 },
    { category: "code-generation", count: 15 },
    { category: "chatbots", count: 12 }
  ]);
});

app.get('/api/tools', (req, res) => {
  res.json({
    tools: [
      {
        id: 1,
        name: "ChatGPT",
        description: "Advanced AI chatbot for conversations and assistance",
        websiteUrl: "https://chatgpt.com",
        logoUrl: "/api/logo/openai.com",
        category: "chatbots",
        pricingModel: "freemium",
        hasApi: true,
        hasFreeVersion: true,
        features: ["conversation", "writing", "coding"],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
      },
      {
        id: 2,
        name: "Claude",
        description: "AI assistant for analysis, writing, and coding",
        websiteUrl: "https://claude.ai",
        logoUrl: "/api/logo/claude.ai",
        category: "chatbots",
        pricingModel: "freemium",
        hasApi: true,
        hasFreeVersion: true,
        features: ["analysis", "writing", "coding"],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ratings: { overallExperience: 4.6, valueForMoney: 4.3, qualityOfOutput: 4.8, totalRatings: 980 }
      }
    ],
    total: 2
  });
});

app.get('/api/tools/featured', (req, res) => {
  res.json({
    id: 1,
    name: "ChatGPT",
    description: "Advanced AI chatbot for conversations and assistance",
    websiteUrl: "https://chatgpt.com",
    logoUrl: "/api/logo/openai.com",
    category: "chatbots",
    pricingModel: "freemium",
    hasApi: true,
    hasFreeVersion: true,
    features: ["conversation", "writing", "coding"],
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ratings: { overallExperience: 4.5, valueForMoney: 4.2, qualityOfOutput: 4.7, totalRatings: 1250 }
  });
});

app.get('/api/logo/:domain', (req, res) => {
  res.redirect(`https://logo.clearbit.com/${req.params.domain}`);
});

// Simple HTML fallback
app.get('*', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Kate's List - AI Directory</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; color: #1e293b; }
          .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 40px; }
          .logo { font-size: 2.5rem; font-weight: bold; color: #3b82f6; margin-bottom: 10px; }
          .tagline { font-size: 1.2rem; color: #64748b; }
          .tools-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 40px; }
          .tool-card { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
          .tool-name { font-size: 1.3rem; font-weight: 600; margin-bottom: 8px; }
          .tool-desc { color: #64748b; margin-bottom: 16px; }
          .tool-features { display: flex; flex-wrap: wrap; gap: 8px; }
          .feature-tag { background: #e0f2fe; color: #0369a1; padding: 4px 8px; border-radius: 6px; font-size: 0.8rem; }
          .loading { text-align: center; margin: 40px 0; color: #64748b; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">Kate's List</div>
            <div class="tagline">Discover AI Tools, Together</div>
          </div>
          
          <div class="loading">Loading AI tools...</div>
          
          <div id="tools-container" class="tools-grid" style="display: none;"></div>
        </div>
        
        <script>
          fetch('/api/tools')
            .then(response => response.json())
            .then(data => {
              document.querySelector('.loading').style.display = 'none';
              const container = document.getElementById('tools-container');
              container.style.display = 'grid';
              
              data.tools.forEach(tool => {
                const card = document.createElement('div');
                card.className = 'tool-card';
                card.innerHTML = \`
                  <div class="tool-name">\${tool.name}</div>
                  <div class="tool-desc">\${tool.description}</div>
                  <div class="tool-features">
                    \${tool.features.map(f => \`<span class="feature-tag">\${f}</span>\`).join('')}
                  </div>
                \`;
                container.appendChild(card);
              });
            })
            .catch(error => {
              document.querySelector('.loading').textContent = 'Welcome to Kate\\'s List - AI Directory Platform';
            });
        </script>
      </body>
    </html>
  `);
});

// Global error handler
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Error:', err);
  res.status(500).send('Service temporarily unavailable');
});

const port = parseInt(process.env.PORT || '5000');
const server = createServer(app);

server.listen(port, '0.0.0.0', () => {
  console.log(`Bulletproof server running on port ${port}`);
});