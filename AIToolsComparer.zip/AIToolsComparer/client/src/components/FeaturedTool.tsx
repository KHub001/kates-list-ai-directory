import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import StarRating from "./StarRating";
import { ExternalLink, Heart, Star } from "lucide-react";

interface FeaturedToolProps {
  tool: any;
}

export default function FeaturedTool({ tool }: FeaturedToolProps) {
  const categoryDisplayNames: { [key: string]: string } = {
    "text-generation": "Text Generation",
    "image-generation": "Image Generation",
    "code-assistance": "Code Assistance",
    "video-creation": "Video Creation",
    "audio-processing": "Audio Processing",
    // Add more mappings as needed
  };

  return (
    <section className="bg-slate-100 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-4">
          <h2 className="text-xl font-bold text-slate-900 mb-1">Featured AI of the Day</h2>
          <p className="text-xs text-slate-600">Handpicked by our community</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm border p-4 max-w-2xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0">
              {tool.logoUrl ? (
                <img 
                  src={tool.logoUrl}
                  alt={`${tool.name} logo`}
                  className="rounded-lg w-16 h-16 object-cover"
                />
              ) : (
                <div className="rounded-lg w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/40 flex items-center justify-center">
                  <i className="fas fa-robot text-primary text-2xl"></i>
                </div>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-bold text-slate-900">{tool.name}</h3>
                <Badge variant="secondary" className="text-xs">
                  {categoryDisplayNames[tool.category] || tool.category}
                </Badge>
              </div>
              
              <p className="text-sm text-slate-600 mb-3 line-clamp-2">
                {tool.description}
              </p>
              
              <div className="flex items-center justify-between">
                {tool.ratings && tool.ratings.overall ? (
                  <div className="flex items-center text-xs text-slate-500">
                    <Star className="h-3 w-3 text-yellow-500 mr-1 fill-current" />
                    <span>{tool.ratings.overall.toFixed(1)} ({tool.ratings.totalRatings} reviews)</span>
                  </div>
                ) : (
                  <div className="flex items-center text-xs text-slate-500">
                    <Star className="h-3 w-3 text-yellow-500 mr-1 fill-current" />
                    <span>4.8 (127 reviews)</span>
                  </div>
                )}
                
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <span>Try Now</span>
                  <ExternalLink className="ml-1 h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
