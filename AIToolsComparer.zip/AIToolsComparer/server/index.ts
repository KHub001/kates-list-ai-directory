import express from 'express';
import { createServer } from 'http';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Database storage
let storage: any = null;

// Initialize database connection
(async () => {
  try {
    if (process.env.DATABASE_URL) {
      const { storage: dbStorage } = await import("./storage");
      storage = dbStorage;
      console.log("Database connected successfully");
    }
  } catch (error) {
    console.error("Database connection failed:", error);
  }
})();

// API endpoints
app.get('/api/user', (req, res) => {
  res.status(401).json({ message: "Not authenticated" });
});

app.get('/api/categories', async (req, res) => {
  try {
    if (storage) {
      const categories = await storage.getCategories();
      res.json(categories);
    } else {
      res.json([]);
    }
  } catch (error) {
    console.error('Categories API error:', error);
    res.json([]);
  }
});

app.get('/api/tools', async (req, res) => {
  try {
    if (storage) {
      const sortBy = (req.query.sortBy as "popularity" | "rating" | "recent" | "alphabetical") || 'popularity';
      const limit = parseInt(req.query.limit as string) || 16;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const result = await storage.getAllTools({ sortBy, limit, offset });
      res.json(result);
    } else {
      res.json({ tools: [], total: 0 });
    }
  } catch (error) {
    console.error('Tools API error:', error);
    res.json({ tools: [], total: 0 });
  }
});

app.get('/api/tools/featured', async (req, res) => {
  try {
    if (storage) {
      const featured = await storage.getFeaturedTool();
      res.json(featured);
    } else {
      res.json(null);
    }
  } catch (error) {
    console.error('Featured tool API error:', error);
    res.json(null);
  }
});

app.get('/api/logo/:domain', (req, res) => {
  res.redirect(`https://logo.clearbit.com/${req.params.domain}`);
});

// Frontend setup
async function setupFrontend() {
  try {
    const { setupVite } = await import("./vite");
    const server = createServer(app);
    await setupVite(app, server);
    return server;
  } catch (error) {
    console.error("Frontend setup failed:", error);
    return createServer(app);
  }
}

// Server initialization
(async () => {
  try {
    console.log("Starting server...");
    console.log("Environment:", process.env.NODE_ENV);
    console.log("Database URL present:", !!process.env.DATABASE_URL);
    
    const server = await setupFrontend();
    const port = parseInt(process.env.PORT || '5000');
    
    server.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

  } catch (error) {
    console.error("Server startup error:", error);
    process.exit(1);
  }
})();
