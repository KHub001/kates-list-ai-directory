import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import StarRating from "./StarRating";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";

const reviewSchema = z.object({
  content: z.string().min(20, "Review must be at least 20 characters"),
  overallExperience: z.number().min(1).max(5),
  valueForMoney: z.number().min(1).max(5),
  qualityOfOutput: z.number().min(1).max(5),
});

type ReviewForm = z.infer<typeof reviewSchema>;

interface ReviewFormProps {
  toolId: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function ReviewForm({ toolId, onSuccess, onCancel }: ReviewFormProps) {
  const { toast } = useToast();

  const form = useForm<ReviewForm>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      content: "",
      overallExperience: 5,
      valueForMoney: 5,
      qualityOfOutput: 5,
    },
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: ReviewForm) => {
      // Create review
      await apiRequest("POST", `/api/tools/${toolId}/reviews`, {
        content: data.content,
      });
      
      // Create rating
      await apiRequest("POST", `/api/tools/${toolId}/ratings`, {
        overallExperience: data.overallExperience,
        valueForMoney: data.valueForMoney,
        qualityOfOutput: data.qualityOfOutput,
      });
    },
    onSuccess: () => {
      toast({
        title: "Review submitted",
        description: "Thank you for your review!",
      });
      onSuccess();
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to submit review",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ReviewForm) => {
    reviewMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Write a Review</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Review</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Share your detailed experience with this AI tool..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Rating Fields */}
            <div className="space-y-4">
              <h4 className="font-semibold text-slate-900">Rate this tool</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="overallExperience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Overall Experience</FormLabel>
                      <FormControl>
                        <StarRating 
                          rating={field.value}
                          onRatingChange={field.onChange}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="valueForMoney"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Value for Money</FormLabel>
                      <FormControl>
                        <StarRating 
                          rating={field.value}
                          onRatingChange={field.onChange}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="qualityOfOutput"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quality of Output</FormLabel>
                      <FormControl>
                        <StarRating 
                          rating={field.value}
                          onRatingChange={field.onChange}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={reviewMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={reviewMutation.isPending}
              >
                {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}