import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, CheckCircle } from "lucide-react";

export default function SubmitTool() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const categories = [
    "text-generation", "image-generation", "video-creation", "audio-processing",
    "code-assistance", "data-analysis", "productivity", "marketing", "design",
    "chatbots", "research", "education", "e-commerce", "healthcare", "finance"
  ];

  const pricingModels = ["free", "freemium", "paid", "enterprise"];

  const onSubmit = (data: any) => {
    console.log('Tool submission:', data);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
        <Header />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Card className="text-center p-8">
            <CardContent className="p-0">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-slate-900 mb-4">
                Submission Received!
              </h1>
              <p className="text-slate-600 mb-6">
                Thank you for submitting your AI tool. Our team will review it within 2-3 business days 
                and contact you if we need any additional information.
              </p>
              <Button onClick={() => window.location.href = '/'}>
                Back to Home
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Submit Your <span className="text-purple-600">AI Tool</span>
          </h1>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Share your AI tool with our community of 25,000+ users. Our platform helps AI tools 
            get discovered by the right audience and receive valuable feedback.
          </p>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Plus className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Increased Visibility</h3>
              <p className="text-slate-600 text-sm">
                Get your tool discovered by thousands of potential users actively searching for AI solutions.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Quality Reviews</h3>
              <p className="text-slate-600 text-sm">
                Receive honest feedback and detailed reviews from real users in your target market.
              </p>
            </CardContent>
          </Card>
          
          <Card className="text-center p-6">
            <CardContent className="p-0">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Plus className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Free Listing</h3>
              <p className="text-slate-600 text-sm">
                Basic listings are completely free. No hidden fees or commission on sign-ups.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Submission Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Tool Information</CardTitle>
            <p className="text-slate-600">
              Please provide accurate information about your AI tool. All fields marked with * are required.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Basic Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Tool Name *
                  </label>
                  <Input
                    {...register("name", { required: "Tool name is required" })}
                    placeholder="e.g. ChatGPT, Midjourney"
                    className={errors.name ? "border-red-300" : ""}
                  />
                  {errors.name && (
                    <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Website URL *
                  </label>
                  <Input
                    {...register("websiteUrl", { 
                      required: "Website URL is required",
                      pattern: {
                        value: /^https?:\/\/.+/,
                        message: "Please enter a valid URL"
                      }
                    })}
                    placeholder="https://your-tool.com"
                    className={errors.websiteUrl ? "border-red-300" : ""}
                  />
                  {errors.websiteUrl && (
                    <p className="text-red-500 text-sm mt-1">{errors.websiteUrl.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Description *
                </label>
                <Textarea
                  {...register("description", { required: "Description is required" })}
                  placeholder="Describe what your AI tool does, its main features, and what problems it solves..."
                  rows={4}
                  className={errors.description ? "border-red-300" : ""}
                />
                {errors.description && (
                  <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Category *
                  </label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.split('-').map(word => 
                            word.charAt(0).toUpperCase() + word.slice(1)
                          ).join(' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Pricing Model *
                  </label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select pricing model" />
                    </SelectTrigger>
                    <SelectContent>
                      {pricingModels.map((model) => (
                        <SelectItem key={model} value={model}>
                          {model.charAt(0).toUpperCase() + model.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Key Features
                </label>
                <Textarea
                  {...register("features")}
                  placeholder="List the main features of your tool (one per line)"
                  rows={3}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Your Name *
                  </label>
                  <Input
                    {...register("submitterName", { required: "Your name is required" })}
                    placeholder="John Doe"
                    className={errors.submitterName ? "border-red-300" : ""}
                  />
                  {errors.submitterName && (
                    <p className="text-red-500 text-sm mt-1">{errors.submitterName.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Contact Email *
                  </label>
                  <Input
                    type="email"
                    {...register("email", { 
                      required: "Email is required",
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                        message: "Please enter a valid email"
                      }
                    })}
                    placeholder="john@example.com"
                    className={errors.email ? "border-red-300" : ""}
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Additional Notes
                </label>
                <Textarea
                  {...register("notes")}
                  placeholder="Any additional information you'd like us to know about your tool..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end space-x-4">
                <Button type="button" variant="outline">
                  Save Draft
                </Button>
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  Submit for Review
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Review Process */}
        <Card className="mt-8 bg-slate-50">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">What happens next?</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <Badge className="mb-2">Step 1</Badge>
                <h4 className="font-medium mb-2">Review</h4>
                <p className="text-sm text-slate-600">
                  Our team reviews your submission within 2-3 business days
                </p>
              </div>
              <div className="text-center">
                <Badge className="mb-2">Step 2</Badge>
                <h4 className="font-medium mb-2">Approval</h4>
                <p className="text-sm text-slate-600">
                  If approved, your tool goes live on our platform
                </p>
              </div>
              <div className="text-center">
                <Badge className="mb-2">Step 3</Badge>
                <h4 className="font-medium mb-2">Promotion</h4>
                <p className="text-sm text-slate-600">
                  We help promote your tool to our community
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <Footer />
    </div>
  );
}