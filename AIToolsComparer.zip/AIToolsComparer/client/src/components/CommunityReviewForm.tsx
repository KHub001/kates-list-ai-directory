import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Star, Plus, X, Send } from "lucide-react";
import StarRating from "./StarRating";

const communityReviewSchema = z.object({
  reviewerName: z.string().min(2, "Name must be at least 2 characters"),
  reviewerEmail: z.string().email("Please enter a valid email address"),
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Review must be at least 20 characters"),
  rating: z.number().min(1, "Please provide a rating").max(5),
  useCases: z.array(z.string()).optional(),
  pros: z.array(z.string()).optional(),
  cons: z.array(z.string()).optional(),
  recommendedFor: z.string().optional(),
});

type CommunityReviewForm = z.infer<typeof communityReviewSchema>;

interface CommunityReviewFormProps {
  toolId: number;
  toolName: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function CommunityReviewForm({ 
  toolId, 
  toolName, 
  onSuccess, 
  onCancel 
}: CommunityReviewFormProps) {
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [useCases, setUseCases] = useState<string[]>([]);
  const [pros, setPros] = useState<string[]>([]);
  const [cons, setCons] = useState<string[]>([]);
  const [newUseCase, setNewUseCase] = useState("");
  const [newPro, setNewPro] = useState("");
  const [newCon, setNewCon] = useState("");

  const form = useForm<CommunityReviewForm>({
    resolver: zodResolver(communityReviewSchema),
    defaultValues: {
      reviewerName: "",
      reviewerEmail: "",
      title: "",
      content: "",
      rating: 0,
      useCases: [],
      pros: [],
      cons: [],
      recommendedFor: "",
    },
  });

  const reviewMutation = useMutation({
    mutationFn: async (data: CommunityReviewForm) => {
      return await apiRequest(`/api/tools/${toolId}/community-reviews`, {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      toast({
        title: "Review submitted successfully!",
        description: "Thank you for sharing your experience with the community.",
      });
      form.reset();
      setRating(0);
      setUseCases([]);
      setPros([]);
      setCons([]);
      onSuccess?.();
    },
    onError: () => {
      toast({
        title: "Failed to submit review",
        description: "There was an error submitting your review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CommunityReviewForm) => {
    reviewMutation.mutate({
      ...data,
      rating,
      useCases,
      pros,
      cons,
    });
  };

  const addItem = (value: string, setter: (items: string[]) => void, items: string[]) => {
    if (value.trim() && !items.includes(value.trim())) {
      setter([...items, value.trim()]);
    }
  };

  const removeItem = (index: number, setter: (items: string[]) => void, items: string[]) => {
    setter(items.filter((_, i) => i !== index));
  };

  const ItemList = ({ 
    items, 
    setter, 
    newValue, 
    setNewValue, 
    placeholder, 
    label 
  }: {
    items: string[];
    setter: (items: string[]) => void;
    newValue: string;
    setNewValue: (value: string) => void;
    placeholder: string;
    label: string;
  }) => (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      <div className="flex gap-2">
        <Input
          value={newValue}
          onChange={(e) => setNewValue(e.target.value)}
          placeholder={placeholder}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              addItem(newValue, setter, items);
              setNewValue("");
            }
          }}
        />
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => {
            addItem(newValue, setter, items);
            setNewValue("");
          }}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      {items.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {items.map((item, index) => (
            <Badge key={index} variant="secondary" className="flex items-center gap-1">
              {item}
              <X
                className="h-3 w-3 cursor-pointer"
                onClick={() => removeItem(index, setter, items)}
              />
            </Badge>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Star className="h-5 w-5 text-yellow-500" />
          Review {toolName}
        </CardTitle>
        <CardDescription>
          Share your honest experience to help others make informed decisions
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="reviewerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="reviewerEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input placeholder="john@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-2">
              <FormLabel>Overall Rating</FormLabel>
              <StarRating
                rating={rating}
                onRatingChange={setRating}
                size="lg"
              />
              {form.formState.errors.rating && (
                <p className="text-sm font-medium text-destructive">
                  {form.formState.errors.rating.message}
                </p>
              )}
            </div>

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Review Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Summarize your experience in a few words..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Review</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Share your detailed experience, what you liked, what could be improved..."
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <ItemList
                items={pros}
                setter={setPros}
                newValue={newPro}
                setNewValue={setNewPro}
                placeholder="What did you like?"
                label="Pros"
              />

              <ItemList
                items={cons}
                setter={setCons}
                newValue={newCon}
                setNewValue={setNewCon}
                placeholder="What could be improved?"
                label="Cons"
              />
            </div>

            <ItemList
              items={useCases}
              setter={setUseCases}
              newValue={newUseCase}
              setNewValue={setNewUseCase}
              placeholder="How did you use this tool?"
              label="Use Cases"
            />

            <FormField
              control={form.control}
              name="recommendedFor"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recommended For (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Who would benefit most from this tool? (e.g., beginners, developers, content creators...)"
                      className="min-h-[80px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex gap-3 pt-4">
              <Button 
                type="submit" 
                disabled={reviewMutation.isPending}
                className="flex-1"
              >
                {reviewMutation.isPending ? (
                  <>
                    <Send className="mr-2 h-4 w-4 animate-pulse" />
                    Submitting Review...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Submit Review
                  </>
                )}
              </Button>
              {onCancel && (
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={onCancel}
                  className="flex-1"
                >
                  Cancel
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}